<!DOCTYPE html>
<html lang="fr-FR" class="" data-skin="light">
  <!-- Mirrored from demo.themewinter.com/wp/courselog/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Apr 2021 16:46:34 GMT -->
  <!-- Added by HTTrack --><meta
    http-equiv="content-type"
    content="text/html;charset=UTF-8"
  /><!-- /Added by HTTrack -->
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Bienvenue </title>
    <link rel="icon" href="assets/img/gsa.png">
    

    <!--style slider-->
    <style>
      /*liens header*/
      ul li{font-family: Arial, Helvetica, sans-serif;}
      /*slider*/
      .test{ margin: 10px;}
      .test i {font-size: 30px;
     /* padding-right: 10px;*/}
      .test button{ padding: 0px;
     height: 85px;
      width: 140px;
      font-size: 18px;
      text-transform: lowercase; }

      .test button{opacity: 0.8;
      padding: 5px;
      margin: 15px}
      .test button p {
        line-height: 18px;
      }

    </style>




    <style id="rocket-critical-css">
      .elementor-column-gap-default
        > .elementor-row
        > .elementor-column
        > .elementor-element-populated {
        padding: 10px;
      }
      @media (max-width: 767px) {
        .elementor-column {
          width: 100%;
        }
      }
      .elementor-screen-only {
        position: absolute;
        top: -10000em;
        width: 1px;
        height: 1px;
        margin: -1px;
        padding: 0;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0;
      }
      .elementor-clearfix:after {
        content: "";
        display: block;
        clear: both;
        width: 0;
        height: 0;
      }
      .elementor {
        -webkit-hyphens: manual;
        -ms-hyphens: manual;
        hyphens: manual;
      }
      .elementor *,
      .elementor :after,
      .elementor :before {
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
      }
      .elementor a {
        -webkit-box-shadow: none;
        box-shadow: none;
        text-decoration: none;
      }
      .elementor img {
        height: auto;
        max-width: 100%;
        border: none;
        -webkit-border-radius: 0;
        border-radius: 0;
        -webkit-box-shadow: none;
        box-shadow: none;
      }
      .elementor .elementor-background-overlay {
        height: 100%;
        width: 100%;
        top: 0;
        left: 0;
        position: absolute;
      }
      .elementor-widget-wrap > .elementor-element.elementor-absolute {
        position: absolute;
      }
      .elementor-widget-wrap .elementor-element.elementor-widget__width-auto {
        max-width: 100%;
      }
      .elementor-element.elementor-absolute {
        z-index: 1;
      }
      .elementor-invisible {
        visibility: hidden;
      }
      :root {
        --page-title-display: block;
      }
      .elementor-section {
        position: relative;
      }
      .elementor-section .elementor-container {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        margin-right: auto;
        margin-left: auto;
        position: relative;
      }
      @media (max-width: 1024px) {
        .elementor-section .elementor-container {
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
        }
      }
      .elementor-section.elementor-section-boxed > .elementor-container {
        max-width: 1140px;
      }
      .elementor-row {
        width: 100%;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
      }
      @media (max-width: 1024px) {
        .elementor-row {
          -ms-flex-wrap: wrap;
          flex-wrap: wrap;
        }
      }
      .elementor-widget-wrap {
        position: relative;
        width: 100%;
        -ms-flex-wrap: wrap;
        flex-wrap: wrap;
        -ms-flex-line-pack: start;
        align-content: flex-start;
      }
      .elementor:not(.elementor-bc-flex-widget) .elementor-widget-wrap {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
      }
      .elementor-widget-wrap > .elementor-element {
        width: 100%;
      }
      .elementor-widget {
        position: relative;
      }
      .elementor-widget:not(:last-child) {
        margin-bottom: 20px;
      }
      .elementor-widget:not(:last-child).elementor-absolute,
      .elementor-widget:not(:last-child).elementor-widget__width-auto {
        margin-bottom: 0;
      }
      .elementor-column {
        min-height: 1px;
      }
      .elementor-column,
      .elementor-column-wrap {
        position: relative;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
      }
      .elementor-column-wrap {
        width: 100%;
      }
      .elementor-inner-section
        .elementor-column-gap-no
        .elementor-element-populated {
        padding: 0;
      }
      @media (min-width: 768px) {
        .elementor-column.elementor-col-25 {
          width: 25%;
        }
        .elementor-column.elementor-col-50 {
          width: 50%;
        }
        .elementor-column.elementor-col-100 {
          width: 100%;
        }
      }
      @media (max-width: 767px) {
        .elementor-column {
          width: 100%;
        }
      }
      @media (min-width: 1025px) {
        #elementor-device-mode:after {
          content: "desktop";
        }
      }
      @media (min-width: 768px) and (max-width: 1024px) {
        #elementor-device-mode:after {
          content: "tablet";
        }
      }
      @media (max-width: 767px) {
        #elementor-device-mode:after {
          content: "mobile";
        }
      }
      .elementor-icon {
        display: inline-block;
        line-height: 1;
        color: #818a91;
        font-size: 50px;
        text-align: center;
      }
      .elementor-icon i,
      .elementor-icon svg {
        width: 1em;
        height: 1em;
        position: relative;
        display: block;
      }
      .elementor-icon i:before,
      .elementor-icon svg:before {
        position: absolute;
        left: 50%;
        -webkit-transform: translateX(-50%);
        -ms-transform: translateX(-50%);
        transform: translateX(-50%);
      }
      @media (min-width: 768px) {
        .elementor-widget-icon-box.elementor-vertical-align-middle
          .elementor-icon-box-wrapper {
          -webkit-box-align: center;
          -ms-flex-align: center;
          align-items: center;
        }
      }
      .elementor-widget-icon-box .elementor-icon-box-wrapper {
        text-align: center;
      }
      .elementor-widget-icon-box .elementor-icon-box-content {
        -webkit-box-flex: 1;
        -ms-flex-positive: 1;
        flex-grow: 1;
      }
      .elementor-widget-icon-box .elementor-icon-box-description {
        margin: 0;
      }
      .elementor-widget .elementor-icon-list-items {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }
      .elementor-widget .elementor-icon-list-item {
        margin: 0;
        padding: 0;
        position: relative;
      }
      .elementor-widget .elementor-icon-list-item:after {
        position: absolute;
        bottom: 0;
        width: 100%;
      }
      .elementor-widget .elementor-icon-list-item,
      .elementor-widget .elementor-icon-list-item a {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
      }
      .elementor-widget .elementor-icon-list-icon + .elementor-icon-list-text {
        -ms-flex-item-align: center;
        align-self: center;
        padding-left: 5px;
      }
      .elementor-widget .elementor-icon-list-icon {
        -ms-flex-negative: 0;
        flex-shrink: 0;
      }
      .elementor-widget .elementor-icon-list-icon i {
        width: 1.25em;
      }
      .elementor-widget:not(.elementor-align-right)
        .elementor-icon-list-item:after {
        left: 0;
      }
      .elementor-widget:not(.elementor-align-left)
        .elementor-icon-list-item:after {
        right: 0;
      }
      @media (max-width: 1024px) {
        .elementor-widget:not(.elementor-tablet-align-right)
          .elementor-icon-list-item:after {
          left: 0;
        }
        .elementor-widget:not(.elementor-tablet-align-left)
          .elementor-icon-list-item:after {
          right: 0;
        }
      }
      @media (max-width: 767px) {
        .elementor-widget:not(.elementor-mobile-align-right)
          .elementor-icon-list-item:after {
          left: 0;
        }
        .elementor-widget:not(.elementor-mobile-align-left)
          .elementor-icon-list-item:after {
          right: 0;
        }
      }
      .elementor-widget-image {
        text-align: center;
      }
      .elementor-widget-image .elementor-image img {
        vertical-align: middle;
        display: inline-block;
      }
      .elementor .elementor-element ul.elementor-icon-list-items {
        padding: 0;
      }
      @media (max-width: 767px) {
        .elementor .elementor-hidden-phone {
          display: none;
        }
      }
      @media (min-width: 768px) and (max-width: 1024px) {
        .elementor .elementor-hidden-tablet {
          display: none;
        }
      }
      .elementor-138
        .elementor-element.elementor-element-8ba937a:not(.elementor-motion-effects-element-type-background) {
        background-color: #120f2d;
      }
      .elementor-138 .elementor-element.elementor-element-8ba937a {
        padding: 5px 0px 5px 0px;
        overflow: visible;
      }
      .elementor-138
        .elementor-element.elementor-element-a5fcde8.elementor-column.elementor-element[data-element_type="column"]
        > .elementor-column-wrap.elementor-element-populated
        > .elementor-widget-wrap {
        align-content: center;
        align-items: center;
      }
      .elementor-138
        .elementor-element.elementor-element-a5fcde8
        > .elementor-element-populated {
        margin: 0px 0px 0px 0px;
        padding: 0px 0px 0px 60px;
      }
      .elementor-138 .elementor-element.elementor-element-6b930f1 {
        color: #ffffff;
        font-size: 14px;
        font-weight: 400;
        line-height: 23px;
        letter-spacing: 0.3px;
      }
      .elementor-138
        .elementor-element.elementor-element-6b930f1
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-361bc0b.elementor-column.elementor-element[data-element_type="column"]
        > .elementor-column-wrap.elementor-element-populated
        > .elementor-widget-wrap {
        align-content: center;
        align-items: center;
      }
      .elementor-138
        .elementor-element.elementor-element-361bc0b.elementor-column
        > .elementor-column-wrap
        > .elementor-widget-wrap {
        justify-content: flex-end;
      }
      .elementor-138
        .elementor-element.elementor-element-361bc0b
        > .elementor-element-populated {
        padding: 0px 0px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .ekit_social_media {
        text-align: right;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .elementor-repeater-item-0745300
        > a {
        color: #ffffff;
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #ffffff33;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .elementor-repeater-item-b5cd8a5
        > a {
        color: #ffffff;
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #ffffff33;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .elementor-repeater-item-091b604
        > a {
        color: #ffffff;
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #ffffff33;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .elementor-repeater-item-9cd60b5
        > a {
        color: #ffffff;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .ekit_social_media
        > li {
        display: inline-block;
        margin: 0px 10px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-31a3327
        .ekit_social_media
        > li
        > a {
        text-decoration: none;
        border-radius: 0% 0% 0% 0%;
        padding: 0px 40px 0px 10px;
        font-size: 14px;
        font-weight: 700;
        width: 30px;
        height: 30px;
        line-height: 28px;
      }
      .elementor-138
        .elementor-element.elementor-element-db3f74d:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-138 .elementor-element.elementor-element-db3f74d {
        box-shadow: 0px 6px 15px 0px rgba(0, 0, 0, 0.04);
        padding: 15px 25px 15px 40px;
        overflow: visible;
      }
      .elementor-138
        .elementor-element.elementor-element-3189300.elementor-column.elementor-element[data-element_type="column"]
        > .elementor-column-wrap.elementor-element-populated
        > .elementor-widget-wrap {
        align-content: center;
        align-items: center;
      }
      .elementor-138
        .elementor-element.elementor-element-3189300
        > .elementor-element-populated {
        padding: 0px 0px 0px 15px;
      }
      .elementor-138
        .elementor-element.elementor-element-43eeffd
        .courselog-widget-logo
        img {
        max-width: 191px;
      }
      .elementor-138
        .elementor-element.elementor-element-43eeffd
        > .elementor-widget-container {
        margin: 0px 40px 0px 0px;
      }
      .elementor-138 .elementor-element.elementor-element-43eeffd {
        width: auto;
        max-width: auto;
        align-self: flex-start;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8
        .ekit-vertical-menu-tigger {
        font-family: "Manrope", Sans-serif;
        font-size: 16px;
        font-weight: 600;
        line-height: 23px;
        color: #2878eb;
        background-color: #02010100;
        padding: 14px 20px 14px 20px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8
        .ekit-vertical-navbar-nav {
        box-shadow: 0px 0px 0px 0px rgba(0, 0, 0, 0.5);
        border-radius: 0px 0px 0px 12px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8
        .ekit-vertical-navbar-nav
        > li
        > a {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 700;
        line-height: 28px;
        color: #120f2d;
        padding: 15px 25px 15px 25px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8
        .ekit-vertical-navbar-nav
        > li
        > a
        .ekit-menu-icon {
        margin: 0px 20px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8
        .ekit-vertical-navbar-nav
        > li {
        border-style: solid;
        border-width: 0px 0px 0px 0px;
      }
      .elementor-138 .elementor-element.elementor-element-edfb3f8 {
        width: auto;
        max-width: auto;
      }
      .elementor-138
        .elementor-element.elementor-element-9483a54
        .search-course-input {
        color: #6c6c7f;
        background: #f5f8fb;
        border-style: solid;
        border-width: 0px 0px 0px 0px;
        border-radius: 5px 5px 5px 5px;
        padding: 12px 20px 12px 20px;
      }
      .elementor-138
        .elementor-element.elementor-element-9483a54
        .courselog-search-course-form
        .search-course-button {
        color: #2878eb;
        background: #ffffff00;
        width: 20px;
        height: 50px !important;
        margin: 0px 20px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-9483a54
        > .elementor-widget-container {
        margin: 0px 0px 0px 10px;
      }
      .elementor-138 .elementor-element.elementor-element-9483a54 {
        width: auto;
        max-width: auto;
      }
      .elementor-138
        .elementor-element.elementor-element-ac77f67.elementor-column.elementor-element[data-element_type="column"]
        > .elementor-column-wrap.elementor-element-populated
        > .elementor-widget-wrap {
        align-content: center;
        align-items: center;
      }
      .elementor-138
        .elementor-element.elementor-element-ac77f67.elementor-column
        > .elementor-column-wrap
        > .elementor-widget-wrap {
        justify-content: flex-end;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-menu-container {
        height: 40px;
        background-color: #ffffff;
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li
        > a {
        font-size: 16px;
        font-weight: 700;
        line-height: 28px;
        color: #120f2d;
        padding: 0px 8px 0px 8px;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li.current-menu-item
        > a {
        color: #2878eb;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li.current-menu-ancestor
        > a {
        color: #2878eb;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li.current-menu-ancestor
        > a
        .elementskit-submenu-indicator {
        color: #2878eb;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li
        > a
        .elementskit-submenu-indicator {
        color: #120f2d;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav-default
        .elementskit-dropdown-has
        > a
        .elementskit-submenu-indicator {
        margin: 4px 0px 0px 7px;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        .elementskit-submenu-panel
        > li
        > a {
        font-family: "Manrope", Sans-serif;
        font-size: 16px;
        font-weight: 700;
        text-transform: capitalize;
        letter-spacing: 0px;
        padding: 15px 30px 15px 30px;
        color: #333333;
        background-color: rgba(255, 255, 255, 0);
        border-style: solid;
        border-width: 0px 0px 1px 0px;
        border-color: #f0f0f0;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        .elementskit-submenu-panel
        > li.current-menu-item
        > a {
        color: #3478f6 !important;
        background-color: rgba(255, 255, 255, 0);
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        .elementskit-submenu-panel
        > li:last-child
        > a {
        border-style: solid;
        border-width: 0px 0px 0px 0px;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        .elementskit-submenu-panel {
        border-style: solid;
        border-width: 0px 0px 0px 0px;
        background-color: #ffffff;
        border-radius: 0px 0px 5px 5px;
        min-width: 200px;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-menu-hamburger {
        float: right;
        border-style: solid;
        border-color: #fa4142;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-menu-hamburger
        > .ekit-menu-icon {
        color: #f14d5d;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-menu-close {
        color: #fa4142;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        > .elementor-widget-container {
        margin: 0px 10px 0px 0px;
      }
      .elementor-138 .elementor-element.elementor-element-de707fc {
        width: auto;
        max-width: auto;
      }
      .elementor-138
        .elementor-element.elementor-element-5011564
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-138
        .elementor-element.elementor-element-5011564
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-weight: 600;
        background-color: #f14d5d;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      .elementor-138
        .elementor-element.elementor-element-5011564
        .elementskit-btn
        > i {
        margin-left: 5px;
      }
      .elementor-138
        .elementor-element.elementor-element-5011564
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-138 .elementor-element.elementor-element-5011564 {
        width: auto;
        max-width: auto;
      }
      .elementor-138
        .elementor-element.elementor-element-3ba9b96
        > .elementor-widget-container {
        margin: 0px 0px 0px 20px;
      }
      .elementor-138 .elementor-element.elementor-element-3ba9b96 {
        width: auto;
        max-width: auto;
      }
      @media (min-width: 768px) {
        .elementor-138 .elementor-element.elementor-element-a5fcde8 {
          width: 70%;
        }
        .elementor-138 .elementor-element.elementor-element-361bc0b {
          width: 30%;
        }
        .elementor-138 .elementor-element.elementor-element-3189300 {
          width: 56%;
        }
        .elementor-138 .elementor-element.elementor-element-ac77f67 {
          width: 44%;
        }
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-138 .elementor-element.elementor-element-a5fcde8 {
          width: 50%;
        }
        .elementor-138 .elementor-element.elementor-element-361bc0b {
          width: 50%;
        }
        .elementor-138 .elementor-element.elementor-element-3189300 {
          width: 70%;
        }
        .elementor-138 .elementor-element.elementor-element-ac77f67 {
          width: 30%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-138 .elementor-element.elementor-element-8ba937a {
          padding: 10px 0px 10px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-a5fcde8
          > .elementor-element-populated {
          padding: 0px 15px 0px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-6b930f1
          > .elementor-widget-container {
          padding: 0px 0px 0px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-361bc0b.elementor-column.elementor-element[data-element_type="column"]
          > .elementor-column-wrap.elementor-element-populated
          > .elementor-widget-wrap {
          align-content: center;
          align-items: center;
        }
        .elementor-138 .elementor-element.elementor-element-db3f74d {
          padding: 20px 0px 20px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-3189300
          > .elementor-element-populated {
          padding: 0px 15px 0px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-edfb3f8
          .ekit-vertical-navbar-nav
          > li {
          border-width: 0px 0px 0px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-ac77f67.elementor-column.elementor-element[data-element_type="column"]
          > .elementor-column-wrap.elementor-element-populated
          > .elementor-widget-wrap {
          align-content: center;
          align-items: center;
        }
        .elementor-138
          .elementor-element.elementor-element-ac77f67.elementor-column
          > .elementor-column-wrap
          > .elementor-widget-wrap {
          justify-content: flex-end;
        }
        .elementor-138
          .elementor-element.elementor-element-ac77f67
          > .elementor-element-populated {
          padding: 0px 15px 0px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-nav-identity-panel {
          padding: 10px 0px 10px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-menu-container {
          max-width: 350px;
          border-radius: 0px 0px 0px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-navbar-nav
          > li
          > a {
          color: #000000;
          padding: 10px 15px 10px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-navbar-nav
          .elementskit-submenu-panel
          > li
          > a {
          padding: 15px 15px 15px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-submenu-panel {
          padding: 0px 0px 0px 20px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-navbar-nav
          .elementskit-submenu-panel {
          border-radius: 0px 0px 0px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-menu-hamburger {
          padding: 10px 0px 10px 0px;
          width: 45px;
          border-radius: 0px;
          border-width: 1px 1px 1px 1px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-menu-hamburger
          > .ekit-menu-icon {
          font-size: 18px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-menu-close {
          padding: 8px 8px 8px 8px;
          margin: 12px 12px 12px 12px;
          width: 45px;
          border-radius: 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-nav-logo
          > img {
          max-width: 160px;
          max-height: 60px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-nav-logo {
          margin: 5px 0px 5px 0px;
          padding: 5px 5px 5px 5px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          > .elementor-widget-container {
          margin: 0px 0px 0px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-3ba9b96
          > .elementor-widget-container {
          margin: 0px 0px 0px 15px;
        }
      }
      @media (max-width: 767px) {
        .elementor-138
          .elementor-element.elementor-element-a5fcde8
          > .elementor-element-populated {
          margin: 0px 0px 10px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-6b930f1
          .elementor-text-editor {
          text-align: center;
        }
        .elementor-138
          .elementor-element.elementor-element-6b930f1
          > .elementor-widget-container {
          padding: 15px 0px 15px 0px;
        }
        .elementor-138
          .elementor-element.elementor-element-361bc0b.elementor-column
          > .elementor-column-wrap
          > .elementor-widget-wrap {
          justify-content: center;
        }
        .elementor-138
          .elementor-element.elementor-element-361bc0b
          > .elementor-element-populated {
          margin: 0px 0px 0px 0px;
          padding: 0px 0px 20px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-31a3327
          .ekit_social_media {
          text-align: center;
        }
        .elementor-138 .elementor-element.elementor-element-db3f74d {
          padding: 20px 0px 20px 0px;
        }
        .elementor-138 .elementor-element.elementor-element-3189300 {
          width: 60%;
        }
        .elementor-138
          .elementor-element.elementor-element-3189300
          > .elementor-element-populated {
          padding: 0px 15px 0px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-edfb3f8
          .ekit-vertical-navbar-nav
          > li
          > a {
          font-size: 16px;
          padding: 0px 40px 15px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-edfb3f8
          .ekit-vertical-navbar-nav
          > li {
          border-width: 0px 0px 0px 0px;
        }
        .elementor-138 .elementor-element.elementor-element-ac77f67 {
          width: 40%;
        }
        .elementor-138
          .elementor-element.elementor-element-ac77f67.elementor-column
          > .elementor-column-wrap
          > .elementor-widget-wrap {
          justify-content: flex-end;
        }
        .elementor-138
          .elementor-element.elementor-element-ac77f67
          > .elementor-element-populated {
          padding: 0px 15px 0px 15px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-navbar-nav
          > li
          > a {
          padding: 12px 0px 12px 12px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-menu-hamburger {
          border-width: 1px 1px 1px 1px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-nav-logo
          > img {
          max-width: 160px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-nav-logo {
          padding: 15px 15px 15px 25px;
        }
        .elementor-138
          .elementor-element.elementor-element-de707fc
          > .elementor-widget-container {
          margin: 0px 0px 0px 0px;
        }
      }
      .top-header-text .focus-title {
        color: #f5ac00;
        border-bottom: 1px solid #f5ac00;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8.category-mega-menu
        .ekit-vertical-menu-container {
        min-width: 370px;
        margin-top: 18px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8.category-mega-menu
        .ekit-vertical-main-menu-on-click
        .ekit-vertical-menu-container {
        display: none;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8.category-mega-menu
        .ekit_menu_label {
        position: relative;
        top: -3px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8.category-mega-menu
        .ekit-menu-icon {
        background: rgba(40, 120, 235, 0.1);
        padding-top: 15px;
        border-radius: 6px;
        height: 52px;
        width: 52px;
        text-align: center;
        font-size: 20px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8.category-mega-menu
        .elementskit-submenu-indicator {
        font-size: 14px;
      }
      .elementor-138
        .elementor-element.elementor-element-edfb3f8.category-mega-menu
        .vertical-menu-icon {
        margin-left: 10px;
        margin-top: 5px;
      }
      @media (max-width: 1400px) {
        .elementor-138
          .elementor-element.elementor-element-edfb3f8.category-mega-menu
          ul.elementskit-megamenu-panel {
          width: 500px !important;
        }
        .elementor-138
          .elementor-element.elementor-element-edfb3f8.category-mega-menu
          .ekit-vertical-menu-tigger {
          padding: 18px 0;
        }
        .elementor-138
          .elementor-element.elementor-element-edfb3f8.category-mega-menu
          .ekit-vertical-menu-container {
          margin-top: 15px;
        }
      }
      @media (max-width: 1175px) {
        .elementor-138
          .elementor-element.elementor-element-edfb3f8.category-mega-menu {
          display: none !important;
        }
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-dropdown
        li:first-child {
        margin-top: 0;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-dropdown
        li:last-child {
        margin-bottom: 0;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .ekit-wid-con
        .dropdown-item.active {
        background: rgba(255, 255, 255, 0.5);
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li {
        margin: 0px 13px;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li
        > a {
        position: relative;
      }
      .elementor-138
        .elementor-element.elementor-element-de707fc
        .elementskit-navbar-nav
        > li
        > a::after {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        margin: 0 auto;
        content: "";
        height: 2px;
        width: 0%;
        background-color: #3478f6;
      }
      @media (min-width: 1025px) and (max-width: 1340px) {
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-navbar-nav
          .elementskit-submenu-panel {
          min-width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-138
          .elementor-element.elementor-element-de707fc
          .elementskit-navbar-nav
          > li
          > a {
          border-bottom: 1px solid #eaeaea;
        }
      }
      @media (min-width: 1025px) and (max-width: 1345px) {
        .elementor-138
          .elementor-element.elementor-element-5011564.elementor-widget__width-auto {
          display: none;
        }
      }
      .fa,
      .fas {
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        display: inline-block;
        font-style: normal;
        font-variant: normal;
        text-rendering: auto;
        line-height: 1;
      }
      .fa-arrow-left:before {
        content: "\f060";
      }
      .fa-arrow-right:before {
        content: "\f061";
      }
      .fa-bolt:before {
        content: "\f0e7";
      }
      .fa-check:before {
        content: "\f00c";
      }
      .fa-chevron-down:before {
        content: "\f078";
      }
      .fa-clipboard-list:before {
        content: "\f46d";
      }
      .fa-database:before {
        content: "\f1c0";
      }
      .fa-info:before {
        content: "\f129";
      }
      .fa-user-alt:before {
        content: "\f406";
      }
      .fa,
      .fas {
        font-family: "Font Awesome 5 Free";
      }
      .fa,
      .fas {
        font-weight: 900;
      }
      :root {
        --woocommerce: #a46497;
        --wc-green: #7ad03a;
        --wc-red: #a00;
        --wc-orange: #ffba00;
        --wc-blue: #2ea2cc;
        --wc-primary: #a46497;
        --wc-primary-text: white;
        --wc-secondary: #ebe9eb;
        --wc-secondary-text: #515151;
        --wc-highlight: #77a464;
        --wc-highligh-text: white;
        --wc-content-bg: #fff;
        --wc-subtext: #767676;
      }
      :root {
        --woocommerce: #a46497;
        --wc-green: #7ad03a;
        --wc-red: #a00;
        --wc-orange: #ffba00;
        --wc-blue: #2ea2cc;
        --wc-primary: #a46497;
        --wc-primary-text: white;
        --wc-secondary: #ebe9eb;
        --wc-secondary-text: #515151;
        --wc-highlight: #77a464;
        --wc-highligh-text: white;
        --wc-content-bg: #fff;
        --wc-subtext: #767676;
      }
      @-ms-viewport {
        width: device-width;
      }
      .xs-review-rattting .screen-rattting-text {
        display: none;
      }
      :root {
        --size: 100px;
        --bord: 15px;
      }
      a {
        color: #0073aa;
      }
      .ekit-wid-con .icon,
      .ekit-wid-con .icon::before,
      .icon,
      .icon::before {
        font-family: elementskit !important;
        speak: none;
        font-style: normal;
        font-weight: 400;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      .ekit-wid-con .icon.icon-dice::before,
      .icon.icon-dice::before {
        content: "\e812";
      }
      .ekit-wid-con .icon.icon-down-arrow1::before,
      .icon.icon-down-arrow1::before {
        content: "\e994";
      }
      .ekit-wid-con .icon.icon-cheese::before,
      .icon.icon-cheese::before {
        content: "\e950";
      }
      .icon.icon-check::before {
        content: "\eaaf";
      }
      .ekit-wid-con .icon.icon-list-2::before,
      .icon.icon-list-2::before {
        content: "\eb25";
      }
      .ekit-wid-con .icon.icon-menu-9::before,
      .icon.icon-menu-9::before {
        content: "\eb27";
      }
      .icon.icon-search11::before {
        content: "\eb28";
      }
      .ekit-wid-con .icon.icon-facebook::before,
      .icon.icon-facebook::before {
        content: "\eb43";
      }
      .ekit-wid-con .icon.icon-twitter::before,
      .icon.icon-twitter::before {
        content: "\eb44";
      }
      .ekit-wid-con .icon.icon-linkedin::before,
      .icon.icon-linkedin::before {
        content: "\eb45";
      }
      .ekit-wid-con .icon.icon-instagram-1::before,
      .icon.icon-instagram-1::before {
        content: "\eb6c";
      }
      .ekit-wid-con .icon.icon-youtube-1::before,
      .icon.icon-youtube-1::before {
        content: "\eb71";
      }
      .ekit-wid-con .icon.icon-Computer::before,
      .icon.icon-Computer::before {
        content: "\ebb1";
      }
      .ekit-section-parallax-layer {
        position: absolute;
      }
      .ekit-section-parallax-layer .elementskit-parallax-graphic {
        width: 100%;
        height: auto;
        overflow: visible;
      }
      @-webkit-keyframes ekit-zoom {
        0% {
          -webkit-transform: scale(1);
          transform: scale(1);
        }
        100% {
          -webkit-transform: scale(0.5);
          transform: scale(0.5);
        }
      }
      @keyframes ekit-zoom {
        0% {
          -webkit-transform: scale(1);
          transform: scale(1);
        }
        100% {
          -webkit-transform: scale(0.5);
          transform: scale(0.5);
        }
      }
      .elementor-kit-573 {
        --e-global-color-primary: #6ec1e4;
        --e-global-color-secondary: #54595f;
        --e-global-color-text: #7a7a7a;
        --e-global-color-accent: #61ce70;
        --e-global-color-490f399d: #4054b2;
        --e-global-color-4f4e5b83: #23a455;
        --e-global-color-239ceecc: #000;
        --e-global-color-6b317634: #fff;
        --e-global-color-61d72d46: #020101;
        --e-global-typography-primary-font-family: "Manrope";
        --e-global-typography-primary-font-weight: 700;
        --e-global-typography-secondary-font-family: "Manrope";
        --e-global-typography-secondary-font-weight: 400;
        --e-global-typography-text-font-family: "Manrope";
        --e-global-typography-text-font-weight: 400;
        --e-global-typography-accent-font-family: "Manrope";
        --e-global-typography-accent-font-weight: 500;
      }
      .elementor-section.elementor-section-boxed > .elementor-container {
        max-width: 1140px;
      }
      @media (max-width: 1024px) {
        .elementor-section.elementor-section-boxed > .elementor-container {
          max-width: 1025px;
        }
      }
      @media (max-width: 767px) {
        .elementor-section.elementor-section-boxed > .elementor-container {
          max-width: 768px;
        }
      }
      .elementor-widget-text-editor {
        color: var(--e-global-color-text);
        font-family: var(--e-global-typography-text-font-family), Sans-serif;
        font-weight: var(--e-global-typography-text-font-weight);
      }
      .elementor-widget-icon.elementor-view-default .elementor-icon {
        color: var(--e-global-color-primary);
        border-color: var(--e-global-color-primary);
      }
      .elementor-widget-icon.elementor-view-default .elementor-icon svg {
        fill: var(--e-global-color-primary);
      }
      .elementor-widget-icon-box
        .elementor-icon-box-content
        .elementor-icon-box-title {
        color: var(--e-global-color-primary);
      }
      .elementor-widget-icon-box
        .elementor-icon-box-content
        .elementor-icon-box-title {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-icon-box
        .elementor-icon-box-content
        .elementor-icon-box-description {
        color: var(--e-global-color-text);
        font-family: var(--e-global-typography-text-font-family), Sans-serif;
        font-weight: var(--e-global-typography-text-font-weight);
      }
      .elementor-widget-icon-list
        .elementor-icon-list-item:not(:last-child):after {
        border-color: var(--e-global-color-text);
      }
      .elementor-widget-icon-list .elementor-icon-list-icon i {
        color: var(--e-global-color-primary);
      }
      .elementor-widget-icon-list .elementor-icon-list-text {
        color: var(--e-global-color-secondary);
      }
      .elementor-widget-icon-list .elementor-icon-list-item {
        font-family: var(--e-global-typography-text-font-family), Sans-serif;
        font-weight: var(--e-global-typography-text-font-weight);
      }
      .elementor-widget-courselog-userlogin .login-user a {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-ekit-vertical-menu .ekit-vertical-menu-tigger {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-ekit-vertical-menu .ekit-vertical-navbar-nav > li > a {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-elementskit-social-media .ekit_social_media > li > a {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-elementskit-page-list
        .elementor-icon-list-item:not(:last-child):after {
        border-color: var(--e-global-color-text);
      }
      .elementor-widget-elementskit-page-list .elementor-icon-list-text {
        color: var(--e-global-color-secondary);
      }
      .elementor-widget-elementskit-page-list .elementor-icon-list-item {
        font-family: var(--e-global-typography-text-font-family), Sans-serif;
        font-weight: var(--e-global-typography-text-font-weight);
      }
      .elementor-widget-elementskit-page-list .ekit_menu_label {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-ekit-nav-menu .elementskit-navbar-nav > li > a {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-ekit-nav-menu
        .elementskit-navbar-nav
        .elementskit-submenu-panel
        > li
        > a {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
      }
      .elementor-widget-ekit-nav-menu .elementskit-menu-close {
        font-family: var(--e-global-typography-primary-font-family), Sans-serif;
        font-weight: var(--e-global-typography-primary-font-weight);
        color: var(--e-global-color-primary);
      }
      .elementor-5 .elementor-element.elementor-element-40111c3 {
        overflow: visible;
        padding: 90px 0px 86px 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-40111c3:not(.elementor-motion-effects-element-type-background) {
        background-image: url("wp-content/uploads/2020/12/hero_area_image.png");
        background-position: center center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      .elementor-5
        .elementor-element.elementor-element-40111c3
        > .elementor-background-overlay {
        background-color: transparent;
        background-image: linear-gradient(90deg, #f8f8fc 50%, #ffffff00 70%);
        opacity: 0.9;
      }
      .elementor-5
        .elementor-element.elementor-element-ed1f2dc
        > .elementor-element-populated {
        padding: 0px 70px 0px 15px;
      }
      .elementor-5
        .elementor-element.elementor-element-9edfd86
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #120f2d;
        margin: 0px 0px 15px 0px;
        font-size: 49px;
        font-weight: 800;
        line-height: 60px;
      }
      .elementor-5
        .elementor-element.elementor-element-9edfd86
        .elementskit-section-title-wraper
        .elementskit-section-subtitle {
        color: #f14d5d;
        font-size: 18px;
        font-weight: 600;
        line-height: 23px;
        margin: 0px 0px 13px 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-9edfd86
        .elementskit-section-title-wraper
        p {
        color: #58566b;
        font-size: 18px;
        font-weight: 400;
        line-height: 28px;
      }
      .elementor-5
        .elementor-element.elementor-element-aa9c61b
        .search-course-input {
        font-size: 16px;
        font-weight: 600;
        line-height: 23px;
        border-style: solid;
        border-width: 2px 2px 2px 2px;
        border-color: #f14d5d;
        border-radius: 5px 5px 5px 5px;
        height: 60px;
        padding: 0px 0px 0px 20px;
      }
      .elementor-5
        .elementor-element.elementor-element-aa9c61b
        .courselog-search-course-form
        .search-course-button {
        background: #f14d5d;
        width: 60px;
        height: 60px !important;
      }
      .elementor-5
        .elementor-element.elementor-element-aa9c61b
        > .elementor-widget-container {
        margin: 0px 0px 10px 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-733eca8
        .elementor-icon-list-items:not(.elementor-inline-items)
        .elementor-icon-list-item:not(:last-child) {
        padding-bottom: calc(12px / 2);
      }
      .elementor-5
        .elementor-element.elementor-element-733eca8
        .elementor-icon-list-items:not(.elementor-inline-items)
        .elementor-icon-list-item:not(:first-child) {
        margin-top: calc(12px / 2);
      }
      .elementor-5
        .elementor-element.elementor-element-733eca8
        .elementor-icon-list-icon
        i {
        color: #1dc295;
        font-size: 14px;
      }
      .elementor-5
        .elementor-element.elementor-element-733eca8
        .elementor-icon-list-text {
        color: #54595f;
      }
      .elementor-5
        .elementor-element.elementor-element-733eca8
        .elementor-icon-list-item {
        font-size: 15px;
        font-weight: 400;
        line-height: 23px;
      }
      .elementor-5
        .elementor-element.elementor-element-f499e65
        > .elementor-element-populated {
        margin: 30px 0px 0px 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-8595084
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-8595084.elementor-view-default
        .elementor-icon {
        color: #ffffff;
        border-color: #ffffff;
      }
      .elementor-5
        .elementor-element.elementor-element-8595084
        .elementor-icon {
        font-size: 18px;
      }
      .elementor-5
        .elementor-element.elementor-element-8595084
        .elementor-icon
        i {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-8595084
        > .elementor-widget-container {
        padding: 10px 12px 7px 15px;
        background-color: #2878eb;
        border-radius: 50px 50px 50px 50px;
      }
      .elementor-5 .elementor-element.elementor-element-8595084 {
        width: auto;
        max-width: auto;
        top: -20px;
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-8595084 {
        left: 166px;
      }
      .elementor-5
        .elementor-element.elementor-element-4127d58
        > .elementor-container {
        max-width: 300px;
      }
      .elementor-5 .elementor-element.elementor-element-4127d58 {
        overflow: visible;
      }
      .elementor-5
        .elementor-element.elementor-element-c167b0d
        .elementor-icon-box-wrapper {
        text-align: left;
      }
      .elementor-5
        .elementor-element.elementor-element-c167b0d
        .elementor-icon-box-title {
        margin-bottom: 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-c167b0d
        .elementor-icon-box-content
        .elementor-icon-box-title {
        color: #2878eb;
      }
      .elementor-5
        .elementor-element.elementor-element-c167b0d
        .elementor-icon-box-content
        .elementor-icon-box-title {
        font-size: 18px;
        font-weight: 700;
        line-height: 23px;
      }
      .elementor-5
        .elementor-element.elementor-element-c167b0d
        .elementor-icon-box-content
        .elementor-icon-box-description {
        color: #a09fab;
        font-size: 14px;
        font-weight: 400;
        line-height: 26px;
        letter-spacing: 0.2px;
      }
      .elementor-5
        .elementor-element.elementor-element-c167b0d
        > .elementor-widget-container {
        padding: 25px 30px 25px 30px;
        background-color: transparent;
        background-image: linear-gradient(180deg, #ffffffcc 0%, #ffffffcc 42%);
        border-style: solid;
        border-width: 2px 2px 2px 2px;
        border-color: #2878eb;
        border-radius: 6px 6px 6px 6px;
      }
      .elementor-5
        .elementor-element.elementor-element-2c47320
        > .elementor-widget-container {
        margin: 20px 0px 0px 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-08e025c
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-08e025c
        .elementor-icon {
        font-size: 25px;
      }
      .elementor-5
        .elementor-element.elementor-element-08e025c
        .elementor-icon
        svg {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-08e025c
        .elementor-widget-container {
        animation-name: ekit-zoom;
        animation-duration: 1.5s;
        animation-iteration-count: infinite;
        animation-direction: alternate;
        -ms-transform: translate(0px, 0px);
        -webkit-transform: translate(0px, 0px);
        transform: translate(0px, 0px);
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-08e025c {
        left: -130.988px;
      }
      .elementor-5 .elementor-element.elementor-element-08e025c {
        top: -39.99px;
      }
      .elementor-5
        .elementor-element.elementor-element-3d9fe8c
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-3d9fe8c
        .elementor-icon {
        font-size: 20px;
      }
      .elementor-5
        .elementor-element.elementor-element-3d9fe8c
        .elementor-icon
        svg {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-3d9fe8c
        .elementor-widget-container {
        animation-name: ekit-zoom;
        animation-duration: 1s;
        animation-iteration-count: infinite;
        animation-direction: alternate;
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-3d9fe8c {
        left: -178px;
      }
      .elementor-5 .elementor-element.elementor-element-3d9fe8c {
        top: -22px;
      }
      .elementor-5
        .elementor-element.elementor-element-83dfb0e
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-83dfb0e
        .elementor-icon {
        font-size: 25px;
      }
      .elementor-5
        .elementor-element.elementor-element-83dfb0e
        .elementor-icon
        svg {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-83dfb0e
        .elementor-widget-container {
        animation-name: ekit-zoom;
        animation-duration: 2s;
        animation-iteration-count: infinite;
        animation-direction: alternate;
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-83dfb0e {
        left: -173px;
      }
      .elementor-5 .elementor-element.elementor-element-83dfb0e {
        top: 16px;
      }
      .elementor-5 .elementor-element.elementor-element-686d9db {
        overflow: visible;
        padding: 115px 0px 0px 0px;
      }
      .elementor-5
        .elementor-element.elementor-element-faeda6c
        .elementor-repeater-item-440fef8
        .elementskit-parallax-graphic {
        transform: rotate(0deg);
        filter: blur(0px);
      }
      .elementor-5
        .elementor-element.elementor-element-faeda6c
        .elementor-repeater-item-440fef8.ekit-section-parallax-layer {
        left: 0%;
        top: 0%;
      }
      .elementor-5
        .elementor-element.elementor-element-faeda6c
        .elementor-repeater-item-440fef8 {
        opacity: 1;
        z-index: 2;
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-fd97d5c
        .elementskit-parallax-graphic {
        transform: rotate(0deg);
        filter: blur(0px);
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-fd97d5c.ekit-section-parallax-layer {
        left: 2%;
        top: 7%;
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-fd97d5c {
        opacity: 1;
        z-index: 2;
      }
      .elementor-5
        .elementor-element.elementor-element-6862dc6
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-6862dc6
        .elementor-icon {
        font-size: 25px;
      }
      .elementor-5
        .elementor-element.elementor-element-6862dc6
        .elementor-icon
        svg {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-6862dc6
        .elementor-widget-container {
        animation-name: ekit-zoom;
        animation-duration: 1s;
        animation-iteration-count: infinite;
        animation-direction: alternate;
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-6862dc6 {
        left: 189.931px;
      }
      .elementor-5 .elementor-element.elementor-element-6862dc6 {
        top: 124.936px;
      }
      .elementor-5
        .elementor-element.elementor-element-6b86888
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-6b86888
        .elementor-icon {
        font-size: 35px;
      }
      .elementor-5
        .elementor-element.elementor-element-6b86888
        .elementor-icon
        svg {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-6b86888
        .elementor-widget-container {
        animation-name: ekit-zoom;
        animation-duration: 1.5s;
        animation-iteration-count: infinite;
        animation-direction: alternate;
        -ms-transform: translate(0px, 0px);
        -webkit-transform: translate(0px, 0px);
        transform: translate(0px, 0px);
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-6b86888 {
        left: 143.955px;
      }
      .elementor-5 .elementor-element.elementor-element-6b86888 {
        top: 132.952px;
      }
      .elementor-5
        .elementor-element.elementor-element-e030cbc
        .elementor-icon-wrapper {
        text-align: center;
      }
      .elementor-5
        .elementor-element.elementor-element-e030cbc
        .elementor-icon {
        font-size: 30px;
      }
      .elementor-5
        .elementor-element.elementor-element-e030cbc
        .elementor-icon
        svg {
        transform: rotate(0deg);
      }
      .elementor-5
        .elementor-element.elementor-element-e030cbc
        .elementor-widget-container {
        animation-name: ekit-zoom;
        animation-duration: 2s;
        animation-iteration-count: infinite;
        animation-direction: alternate;
      }
      body:not(.rtl) .elementor-5 .elementor-element.elementor-element-e030cbc {
        left: 190.943px;
      }
      .elementor-5 .elementor-element.elementor-element-e030cbc {
        top: 80.959px;
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-d7c0da7
        .elementskit-parallax-graphic {
        transform: rotate(0deg);
        filter: blur(0px);
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-d7c0da7.ekit-section-parallax-layer {
        left: 12%;
        top: 63%;
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-d7c0da7 {
        opacity: 1;
        z-index: 2;
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-e4708c0
        .elementskit-parallax-graphic {
        transform: rotate(0deg);
        filter: blur(0px);
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-e4708c0.ekit-section-parallax-layer {
        left: 90%;
        top: -40%;
      }
      .elementor-5
        .elementor-element.elementor-element-862cc1f
        .elementor-repeater-item-e4708c0 {
        opacity: 1;
        z-index: 2;
      }
      .elementor-5
        .elementor-element.elementor-element-7228e16
        .elementor-repeater-item-2680513
        .elementskit-parallax-graphic {
        transform: rotate(0deg);
        filter: blur(0px);
      }
      .elementor-5
        .elementor-element.elementor-element-7228e16
        .elementor-repeater-item-2680513.ekit-section-parallax-layer {
        left: 95%;
        top: -45%;
      }
      .elementor-5
        .elementor-element.elementor-element-7228e16
        .elementor-repeater-item-2680513 {
        opacity: 1;
        z-index: 2;
      }
      @media (max-width: 1024px) {
        .elementor-5
          .elementor-element.elementor-element-40111c3:not(.elementor-motion-effects-element-type-background) {
          background-position: center center;
          background-repeat: no-repeat;
          background-size: cover;
        }
        .elementor-5
          .elementor-element.elementor-element-ed1f2dc
          > .elementor-element-populated {
          margin: 0px 0px 10px 0px;
          padding: 0px 140px 0px 15px;
        }
        .elementor-5
          .elementor-element.elementor-element-9edfd86
          .elementskit-section-title-wraper
          .elementskit-section-title {
          font-size: 42px;
          line-height: 50px;
        }
        body:not(.rtl)
          .elementor-5
          .elementor-element.elementor-element-8595084 {
          left: 252px;
        }
        .elementor-5 .elementor-element.elementor-element-8595084 {
          top: -21px;
        }
        .elementor-5
          .elementor-element.elementor-element-ee604eb.elementor-column
          > .elementor-column-wrap
          > .elementor-widget-wrap {
          justify-content: flex-start;
        }
        .elementor-5
          .elementor-element.elementor-element-08e025c
          .elementor-widget-container {
          -ms-transform: translate(0px, 0px);
          -webkit-transform: translate(0px, 0px);
          transform: translate(0px, 0px);
        }
        .elementor-5 .elementor-element.elementor-element-686d9db {
          padding: 90px 0px 0px 0px;
        }
        .elementor-5
          .elementor-element.elementor-element-6b86888
          .elementor-widget-container {
          -ms-transform: translate(0px, 0px);
          -webkit-transform: translate(0px, 0px);
          transform: translate(0px, 0px);
        }
      }
      @media (max-width: 767px) {
        .elementor-5 .elementor-element.elementor-element-40111c3 {
          padding: 70px 0px 50px 0px;
        }
        .elementor-5
          .elementor-element.elementor-element-ed1f2dc
          > .elementor-element-populated {
          padding: 0px 15px 0px 15px;
        }
        .elementor-5
          .elementor-element.elementor-element-9edfd86
          .elementskit-section-title-wraper
          .elementskit-section-title {
          margin: 0px 0px 0px 0px;
          font-size: 32px;
          line-height: 42px;
        }
        body:not(.rtl)
          .elementor-5
          .elementor-element.elementor-element-8595084 {
          left: 72px;
        }
        .elementor-5 .elementor-element.elementor-element-8595084 {
          top: -17px;
        }
        .elementor-5
          .elementor-element.elementor-element-08e025c
          .elementor-widget-container {
          -ms-transform: translate(0px, 0px);
          -webkit-transform: translate(0px, 0px);
          transform: translate(0px, 0px);
        }
        .elementor-5 .elementor-element.elementor-element-686d9db {
          padding: 80px 0px 0px 0px;
        }
        .elementor-5
          .elementor-element.elementor-element-6b86888
          .elementor-widget-container {
          -ms-transform: translate(0px, 0px);
          -webkit-transform: translate(0px, 0px);
          transform: translate(0px, 0px);
        }
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-5 .elementor-element.elementor-element-ed1f2dc {
          width: 100%;
        }
        .elementor-5 .elementor-element.elementor-element-f499e65 {
          width: 100%;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      @media (max-width: 1500px) {
        .parallax-star {
          display: none;
        }
      }
      :root {
        --blue: #007bff;
        --indigo: #6610f2;
        --purple: #6f42c1;
        --pink: #e83e8c;
        --red: #dc3545;
        --orange: #fd7e14;
        --yellow: #ffc107;
        --green: #28a745;
        --teal: #20c997;
        --cyan: #17a2b8;
        --white: #fff;
        --gray: #6c757d;
        --gray-dark: #343a40;
        --primary: #007bff;
        --secondary: #6c757d;
        --success: #28a745;
        --info: #17a2b8;
        --warning: #ffc107;
        --danger: #dc3545;
        --light: #f8f9fa;
        --dark: #343a40;
        --breakpoint-xs: 0;
        --breakpoint-sm: 576px;
        --breakpoint-md: 768px;
        --breakpoint-lg: 992px;
        --breakpoint-xl: 1200px;
        --font-family-sans-serif: -apple-system, BlinkMacSystemFont, "Segoe UI",
          Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji",
          "Segoe UI Emoji", "Segoe UI Symbol";
        --font-family-monospace: SFMono-Regular, Menlo, Monaco, Consolas,
          "Liberation Mono", "Courier New", monospace;
      }
      *,
      ::after,
      ::before {
        box-sizing: border-box;
      }
      html {
        font-family: sans-serif;
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
        -ms-text-size-adjust: 100%;
        -ms-overflow-style: scrollbar;
      }
      @-ms-viewport {
        width: device-width;
      }
      section {
        display: block;
      }
      body {
        margin: 0;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
          "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji",
          "Segoe UI Emoji", "Segoe UI Symbol";
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #212529;
        text-align: left;
        background-color: #fff;
      }
      h2,
      h3 {
        margin-top: 0;
        margin-bottom: 0.5rem;
      }
      p {
        margin-top: 0;
        margin-bottom: 1rem;
      }
      ul {
        margin-top: 0;
        margin-bottom: 1rem;
      }
      ul ul {
        margin-bottom: 0;
      }
      a {
        color: #007bff;
        text-decoration: none;
        background-color: transparent;
        -webkit-text-decoration-skip: objects;
      }
      img {
        vertical-align: middle;
        border-style: none;
      }
      svg:not(:root) {
        overflow: hidden;
      }
      button {
        border-radius: 0;
      }
      button,
      input {
        margin: 0;
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
      }
      button,
      input {
        overflow: visible;
      }
      button {
        text-transform: none;
      }
      button,
      html [type="button"] {
        -webkit-appearance: button;
      }
      [type="button"]::-moz-focus-inner,
      button::-moz-focus-inner {
        padding: 0;
        border-style: none;
      }
      ::-webkit-file-upload-button {
        font: inherit;
        -webkit-appearance: button;
      }
      h2,
      h3 {
        margin-bottom: 0.5rem;
        font-family: inherit;
        font-weight: 500;
        line-height: 1.2;
        color: inherit;
      }
      h2 {
        font-size: 2rem;
      }
      h3 {
        font-size: 1.75rem;
      }
      .dropdown-item {
        display: block;
        width: 100%;
        padding: 0.25rem 1.5rem;
        clear: both;
        font-weight: 400;
        color: #212529;
        text-align: inherit;
        white-space: nowrap;
        background-color: transparent;
        border: 0;
      }
      .dropdown-item.active {
        color: #fff;
        text-decoration: none;
        background-color: #007bff;
      }
      .media {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
      }
      .text-left {
        text-align: left !important;
      }
      .text-center {
        text-align: center !important;
      }
      [class*=" tsicon-"],
      i.tsicon {
        font-family: "iconfont" !important;
        speak: none;
        font-style: normal;
        font-weight: normal;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      .tsicon-search1:before {
        content: "\e94f";
      }
      :focus {
        outline: 0;
      }
      button::-moz-focus-inner {
        padding: 0;
        border: 0;
      }
      .owl-carousel .owl-dots.disabled {
        display: none;
      }
      body {
        overflow-x: hidden;
        color: #525252;
      }
      img:not([draggable]) {
        max-width: 100%;
        height: auto;
      }
      svg {
        fill: currentColor;
      }
      h2,
      h3 {
        word-break: break-word;
      }
      body {
        font-family: "Manrope", sans-serif;
        line-height: 28px;
        font-size: 16px;
        color: #58566b;
        font-weight: 400;
        border: 0;
        margin: 0;
        padding: 0;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      h2,
      h3 {
        color: #120f2d;
        font-family: "Manrope", sans-serif;
        font-weight: 700;
      }
      h2 {
        font-size: 36px;
        line-height: 42px;
      }
      h3 {
        font-size: 30px;
        margin-bottom: 20px;
      }
      input {
        -moz-outline: none;
        outline: none;
      }
      a:visited {
        text-decoration: none;
        outline: 0;
      }
      a {
        color: #120f2d;
      }
      .owl-carousel .owl-dots {
        text-align: center;
      }
      .owl-carousel .owl-nav .owl-prev,
      .owl-carousel .owl-nav .owl-next {
        position: absolute;
        top: 50%;
        -webkit-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
        transform: translateY(-50%);
        font-size: 48px;
        color: #666666;
      }
      .owl-carousel .owl-nav .owl-prev,
      .owl-carousel .owl-nav .owl-next {
        height: 50px;
        width: 50px;
        border-radius: 50%;
        -webkit-border-radius: 50%;
        -ms-border-radius: 50%;
        border: 1px solid #dedfe2;
        color: #120f2d;
        display: inline-block;
        text-align: center;
        font-size: 16px;
        line-height: 50px;
      }
      .owl-carousel .owl-nav .owl-prev {
        left: 30px;
      }
      .owl-carousel .owl-nav .owl-next {
        right: 30px;
      }
      .header-course-search .courselog-search-course-form {
        margin-bottom: 0;
      }
      .login-user {
        position: relative;
      }
      .login-user i {
        width: 35px;
        height: 35px;
        border-radius: 50%;
        -webkit-border-radius: 50%;
        -ms-border-radius: 50%;
        border: 1px solid #e3e3e8;
        text-align: center;
        line-height: 30px;
        position: relative;
        display: inline-block;
        font-size: 12px;
      }
      .login-user > a {
        color: #120f2d;
      }
      .ts-course-category.category-slider .owl-nav .owl-prev,
      .ts-course-category.category-slider .owl-nav .owl-next {
        left: -80px;
      }
      @media (max-width: 1300px) {
        .ts-course-category.category-slider .owl-nav .owl-prev,
        .ts-course-category.category-slider .owl-nav .owl-next {
          display: none;
        }
      }
      .ts-course-category.category-slider .owl-nav .owl-next {
        right: -80px;
        left: auto;
      }
      .courselog-search-course-form .search-course-input {
        width: 100%;
        border: 1px dashed #dedfe2;
        border-radius: 6px;
        -webkit-border-radius: 6px;
        -ms-border-radius: 6px;
      }
      .courselog-search-course-form .search-course-button {
        border: none;
        background-color: #f14d5d;
        color: #fff;
        height: 100% !important;
        right: 0 !important;
        top: 0 !important;
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px;
      }
      .cl-main-header {
        -webkit-box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.03);
        box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.03);
      }
      @media (max-width: 1600px) {
        .ekit-section-parallax-layer {
          display: none;
        }
      }
      .cl-main-header {
        -webkit-box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.03);
        box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.03);
      }
      @media (max-width: 1600px) {
        .ekit-section-parallax-layer {
          display: none;
        }
      }
      @media (max-width: 768px) {
        .elementskit-navbar-nav-default
          .elementskit-dropdown-has
          > a
          .elementskit-submenu-indicator {
          margin-left: auto !important;
          border-color: transparent;
        }
      }
      img {
        -ms-interpolation-mode: bicubic;
        border: 0;
        height: auto;
        max-width: 100%;
        vertical-align: middle;
        border-radius: 6px;
      }
      p {
        margin: 0 0 25px;
      }
      @media (min-width: 992px) {
        :root {
          --data-max-height: 302px;
        }
      }
      :focus {
        outline: 0;
      }
      button::-moz-focus-inner {
        padding: 0;
        border: 0;
      }
      .elementskit-menu-container {
        z-index: 10000;
      }
      .elementskit-dropdown li {
        position: relative;
      }
      .elementskit-navbar-nav-default .elementskit-navbar-nav {
        padding-left: 0;
        margin-bottom: 0;
        list-style: none;
        margin-left: 0;
      }
      .elementskit-navbar-nav-default .elementskit-navbar-nav > li {
        position: relative;
      }
      .elementskit-navbar-nav-default .elementskit-navbar-nav > li > a {
        height: 100%;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        text-decoration: none;
      }
      .elementskit-navbar-nav-default
        .elementskit-navbar-nav
        > li.elementskit-megamenu-has {
        position: static;
      }
      .elementskit-navbar-nav-default .elementskit-navbar-nav > li > a {
        text-transform: none;
        font-weight: 500;
        letter-spacing: normal;
      }
      .elementskit-navbar-nav-default .elementskit-dropdown {
        border-top: 1px solid #dadada;
        border-left: 1px solid #dadada;
        border-bottom: 1px solid #dadada;
        border-right: 1px solid #dadada;
        background-color: #f4f4f4;
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
        border-top-right-radius: 0;
        border-top-left-radius: 0;
        padding-left: 0;
        list-style: none;
        opacity: 0;
        visibility: hidden;
      }
      .elementskit-navbar-nav-default .elementskit-submenu-panel > li > a {
        display: block;
        padding-top: 15px;
        padding-left: 10px;
        padding-bottom: 15px;
        padding-right: 10px;
        color: #000;
        font-weight: 400;
        font-size: 14px;
      }
      .elementskit-navbar-nav-default .elementskit-megamenu-panel {
        width: 100%;
      }
      .elementskit-navbar-nav-default .elementskit-nav-identity-panel {
        display: none;
      }
      .elementskit-navbar-nav-default .elementskit-menu-close {
        border: 1px solid rgba(0, 0, 0, 0.5);
        color: rgba(51, 51, 51, 0.5);
        float: right;
        margin-top: 20px;
        margin-left: 20px;
        margin-right: 20px;
        margin-bottom: 20px;
      }
      .elementskit-navbar-nav-default .elementskit-dropdown-has > a {
        position: relative;
      }
      .elementskit-navbar-nav-default
        .elementskit-dropdown-has
        > a
        .elementskit-submenu-indicator {
        margin-left: 6px;
        display: block;
        float: right;
        position: relative;
        font-weight: 900;
        font-style: normal;
        font-size: 11px;
      }
      @media (max-width: 1024px) {
        .elementskit-navbar-nav-default
          .elementskit-dropdown-has
          > a
          .elementskit-submenu-indicator {
          padding: 4px 15px;
        }
      }
      .elementskit-navbar-nav-default.elementskit_line_arrow
        .elementskit-submenu-indicator {
        font-style: normal;
      }
      .elementskit-navbar-nav-default.elementskit-menu-container {
        background: rgba(255, 255, 255, 0);
        background: -webkit-gradient(
          linear,
          left bottom,
          left top,
          from(rgba(255, 255, 255, 0)),
          to(rgba(255, 255, 255, 0))
        );
        background: linear-gradient(
          0deg,
          rgba(255, 255, 255, 0) 0,
          rgba(255, 255, 255, 0) 100%
        );
        border-bottom-right-radius: 0;
        border-bottom-left-radius: 0;
        border-top-right-radius: 0;
        border-top-left-radius: 0;
        position: relative;
        height: 100px;
        z-index: 90000;
      }
      .elementskit-navbar-nav-default .elementskit-dropdown {
        min-width: 250px;
        margin-left: 0;
      }
      .elementskit-navbar-nav-default .elementskit-navbar-nav {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        height: 100%;
        -webkit-box-pack: start;
        -ms-flex-pack: start;
        justify-content: flex-start;
      }
      .elementskit-navbar-nav-default .elementskit-navbar-nav > li > a {
        font-size: 15px;
        color: #000;
        padding-left: 15px;
        padding-right: 15px;
      }
      @media (min-width: 1025px) {
        .elementskit-navbar-nav-default .elementskit-dropdown {
          -webkit-box-shadow: 0 10px 30px 0 rgba(45, 45, 45, 0.2);
          box-shadow: 0 10px 30px 0 rgba(45, 45, 45, 0.2);
          position: absolute;
          top: 100%;
          left: 0;
          -webkit-transform: translateY(-10px);
          transform: translateY(-10px);
          max-height: none;
        }
        .elementskit-navbar-nav-default .elementskit-megamenu-panel {
          -webkit-transform: translateY(-10px);
          transform: translateY(-10px);
          opacity: 0;
          visibility: hidden;
          margin-left: 0;
          position: absolute;
          left: 0;
          top: 100%;
          display: block;
        }
      }
      .elementskit-navbar-nav-default
        .elementskit-megamenu-has
        .elementskit-dropdown {
        display: none;
      }
      @media (max-width: 1024px) {
        .elementskit-navbar-nav-default.elementskit-menu-offcanvas-elements {
          background-color: #f7f7f7;
          width: 100%;
          position: fixed;
          top: 0;
          left: -110%;
          height: 100%;
          -webkit-box-shadow: 0 10px 30px 0 rgba(255, 165, 0, 0);
          box-shadow: 0 10px 30px 0 rgba(255, 165, 0, 0);
          overflow-y: auto;
          overflow-x: hidden;
          padding-top: 0;
          padding-left: 0;
          padding-right: 0;
          display: -webkit-box;
          display: -ms-flexbox;
          display: flex;
          -webkit-box-orient: vertical;
          -webkit-box-direction: reverse;
          -ms-flex-direction: column-reverse;
          flex-direction: column-reverse;
          -webkit-box-pack: end;
          -ms-flex-pack: end;
          justify-content: flex-end;
        }
        .elementskit-navbar-nav-default .elementskit-nav-identity-panel {
          display: block;
          position: relative;
          z-index: 5;
          width: 100%;
        }
        .elementskit-navbar-nav-default
          .elementskit-nav-identity-panel
          .elementskit-site-title {
          float: left;
        }
        .elementskit-navbar-nav-default
          .elementskit-nav-identity-panel
          .elementskit-menu-close {
          float: right;
        }
        .elementskit-navbar-nav-default .elementskit-navbar-nav > li > a {
          color: #000;
          font-size: 12px;
          padding-top: 5px;
          padding-left: 10px;
          padding-right: 5px;
          padding-bottom: 5px;
        }
        .elementskit-navbar-nav-default .elementskit-submenu-panel > li > a {
          color: #000;
          font-size: 12px;
          padding-top: 7px;
          padding-left: 7px;
          padding-right: 7px;
          padding-bottom: 7px;
        }
        .elementskit-navbar-nav-default .elementskit-dropdown {
          display: block;
          border: 0;
          margin-left: 0;
        }
        .elementskit-navbar-nav-default .elementskit-megamenu-panel {
          display: none;
        }
        .elementskit-navbar-nav-default
          .elementskit-navbar-nav
          > .elementskit-dropdown-has
          > .elementskit-dropdown
          li
          a {
          padding-left: 15px;
        }
      }
      @media (min-width: 1025px) {
        .elementskit-dropdown-has .elementskit-dropdown {
          -webkit-box-shadow: 0 10px 30px 0 rgba(45, 45, 45, 0.2);
          box-shadow: 0 10px 30px 0 rgba(45, 45, 45, 0.2);
          position: absolute;
          top: 100%;
          left: 0;
          -webkit-transform: translateY(-10px);
          transform: translateY(-10px);
          max-height: none;
        }
      }
      @media only screen and (max-width: 1024px) and (min-width: 766px) {
        .ekit_menu_responsive_tablet
          .elementskit-megamenu-has.elementskit-mobile-builder-content
          .elementskit-dropdown {
          display: none;
        }
        .ekit_menu_responsive_tablet .elementskit-dropdown {
          display: none;
        }
        .ekit_menu_responsive_tablet
          .elementskit-dropdown
          ~ .elementskit-megamenu-panel {
          display: none;
        }
        .ekit_menu_responsive_tablet .elementskit-navbar-nav {
          overflow-y: auto;
        }
      }
      .elementskit-menu-close,
      .elementskit-menu-hamburger {
        display: none;
      }
      .elementskit-menu-hamburger {
        color: #000;
      }
      @media (max-width: 1024px) {
        .elementskit-menu-overlay {
          display: block;
          position: fixed;
          z-index: 14;
          top: 0;
          left: -110%;
          height: 100%;
          width: 100%;
          background-color: rgba(51, 51, 51, 0.5);
          opacity: 1;
          visibility: visible;
        }
        .elementskit-menu-hamburger {
          border: 1px solid rgba(0, 0, 0, 0.2);
          float: right;
        }
        .elementskit-menu-close,
        .elementskit-menu-hamburger {
          padding: 8px;
          background-color: transparent;
          border-radius: 0.25rem;
          position: relative;
          z-index: 10;
          width: 45px;
        }
      }
      .dropdown-item,
      .ekit-menu-nav-link {
        position: relative;
      }
      .ekit-menu-nav-link > i {
        padding-right: 5px;
      }
      .elementskit-nav-logo {
        display: inline-block;
      }
      @media (max-width: 1024px) {
        .elementor-widget-ekit-nav-menu {
          -webkit-animation: none !important;
          animation: none !important;
        }
        .ekit-wid-con:not(.ekit_menu_responsive_mobile)
          .elementskit-navbar-nav {
          display: block;
        }
      }
      @media (max-width: 1024px) {
        .elementskit-menu-close,
        .elementskit-menu-hamburger {
          display: block;
        }
        .elementskit-menu-container {
          max-width: 350px;
        }
        .elementskit-menu-offcanvas-elements {
          height: 100% !important;
          padding-bottom: 10px;
        }
        .elementskit-dropdown {
          position: relative;
          max-height: 0;
          -webkit-box-shadow: none;
          box-shadow: none;
        }
        .ekit_menu_responsive_tablet
          .elementskit-navbar-nav-default
          .elementskit-dropdown-has
          > a
          .elementskit-submenu-indicator {
          margin-left: auto;
        }
        .ekit_menu_responsive_tablet .elementskit-submenu-indicator {
          -webkit-box-ordinal-group: 3;
          -ms-flex-order: 2;
          order: 2;
          border: 1px solid;
          border-radius: 30px;
        }
      }
      @media (max-width: 767px) {
        .ekit_menu_responsive_tablet
          .elementskit-megamenu-has.elementskit-mobile-builder-content
          .elementskit-dropdown {
          display: none;
        }
        .ekit_menu_responsive_tablet .elementskit-dropdown {
          display: none;
        }
        .ekit_menu_responsive_tablet
          .elementskit-dropdown
          ~ .elementskit-megamenu-panel {
          display: none;
        }
        .ekit_menu_responsive_tablet .elementskit-navbar-nav {
          overflow-y: auto;
        }
      }
      @media (max-width: 767px) {
        .ekit-sticky
          .elementskit-menu-container.elementskit-menu-offcanvas-elements {
          height: 120vh !important;
        }
        .ekit-sticky .elementskit-menu-overlay {
          display: none;
        }
        .ekit-sticky .elementskit-menu-offcanvas-elements::before {
          position: fixed;
          content: "";
          top: 0;
          left: -110%;
          height: 100%;
          width: 100%;
          background-color: rgba(51, 51, 51, 0.5);
        }
        .ekit-sticky .elementskit-menu-offcanvas-elements::after {
          position: absolute;
          content: "";
          top: 0;
          left: 0;
          height: 100%;
          width: 100%;
          background: inherit;
        }
        .ekit-sticky .elementskit-navbar-nav-default .elementskit-navbar-nav {
          position: relative;
          z-index: 5;
        }
      }
      @media (min-width: 1025px) {
        .elementor-widget-ekit-nav-menu
          .elementskit-dropdown-menu-full_width
          .elementskit-megamenu-panel {
          width: 100vw;
        }
        .elementskit-megamenu-panel
          .elementor-section-wrap
          > .elementor-section
          > .elementor-container {
          max-width: none;
        }
      }
      @media (min-width: 1025px) {
        .ekit_menu_responsive_tablet .ekit-nav-menu--overlay {
          display: none;
        }
      }
      .ekit-vertical-menu-tigger {
        display: block;
        background: #ffb25d;
        -webkit-box-shadow: 0 7px 15px rgba(255, 178, 93, 0.3);
        box-shadow: 0 7px 15px rgba(255, 178, 93, 0.3);
        padding-top: 16px;
        padding-bottom: 16px;
        padding-left: 20px;
        padding-right: 16px;
        font-size: 14px;
        color: #fff;
        font-weight: 500;
        line-height: 1;
      }
      .vertical-menu-left-icon {
        float: right;
      }
      .ekit-vertical-navbar-nav {
        padding-left: 0;
        list-style: none;
        -webkit-box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        background-color: #fff;
        margin-left: 0;
        margin-bottom: 0;
        list-style: none;
      }
      .ekit-vertical-navbar-nav .elementskit-megamenu-panel {
        margin-left: 0;
        list-style: none;
        margin-bottom: 0;
      }
      .ekit-vertical-navbar-nav > li:not(:last-child) {
        border-bottom: 1px solid #ededed;
      }
      .ekit-vertical-navbar-nav > li > a {
        font-size: 14px;
        font-weight: 500;
        color: #101010;
        display: block;
        padding-top: 12px;
        padding-bottom: 12px;
        padding-left: 25px;
        padding-right: 19px;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
      }
      .ekit-vertical-navbar-nav > li > a .ekit-menu-icon {
        margin-right: 7px;
        padding-right: 0;
      }
      .ekit-vertical-navbar-nav li.elementskit-dropdown-has {
        position: relative;
      }
      @media (min-width: 1025px) {
        .ekit-vertical-navbar-nav li.elementskit-megamenu-has.top_position {
          position: static;
        }
      }
      @media (max-width: 1024px) {
        .ekit-vertical-navbar-nav .elementskit-megamenu-panel {
          display: none;
          width: auto !important;
        }
      }
      @media (min-width: 1025px) {
        .ekit-vertical-navbar-nav .elementskit-megamenu-panel {
          position: absolute;
          left: 100%;
          top: 0;
          z-index: 100;
          -webkit-transform: translateY(10px);
          transform: translateY(10px);
          opacity: 0;
          visibility: hidden;
          width: 100%;
        }
      }
      .ekit-vertical-navbar-nav .elementskit-submenu-indicator {
        display: block;
        line-height: 1;
        margin-left: auto;
        position: relative;
        font-weight: 900;
        font-style: normal;
        font-family: "Font Awesome 5 Free";
        -webkit-box-ordinal-group: 3;
        -ms-flex-order: 2;
        order: 2;
      }
      .ekit-vertical-navbar-nav .elementskit-submenu-indicator::before {
        content: "\f105";
      }
      .ekit-vertical-main-menu-on-click {
        position: relative;
      }
      .ekit-vertical-main-menu-on-click .ekit-vertical-menu-container {
        position: absolute;
        top: 100%;
        z-index: 1111;
        left: 0;
        width: 100%;
      }
      .ekit-vertical-main-menu-on-click .ekit-vertical-menu-container {
        opacity: 0;
        visibility: hidden;
      }
      .whitespace--normal {
        white-space: normal !important;
      }
      .ekit-wid-con .ekit_social_media {
        margin-left: 0;
        padding-left: 0;
        list-style: none;
      }
      .ekit-wid-con .ekit_social_media > li > a {
        display: block;
      }
      .ekit-wid-con .ekit_social_media > li > a i {
        vertical-align: middle;
        display: inline-block;
      }
      @media (max-width: 1024px) {
        .ekit-wid-con .ekit_social_media > li {
          margin-bottom: 20px;
        }
      }
      .ekit-wid-con .elementor-icon-list-item > a {
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        position: relative;
      }
      .ekit-wid-con .ekit_menu_label {
        border-radius: 3px;
        padding: 2px 5px;
        display: inline-block;
        font-size: 10px;
        color: #fff;
        background-color: #c91765;
        margin-left: 5px;
      }
      .ekit-wid-con .ekit_page_list_content {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
      }
      .ekit-wid-con .ekit-review-card--date,
      .ekit-wid-con .ekit-review-card--desc {
        grid-area: date;
      }
      .ekit-wid-con .ekit-review-card--image {
        width: 60px;
        height: 60px;
        grid-area: thumbnail;
        min-width: 60px;
        border-radius: 50%;
        background-color: #eae9f7;
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        align-items: center;
        padding: 1rem;
        position: relative;
      }
      .ekit-wid-con .ekit-review-card--thumbnail {
        grid-area: thumbnail;
        padding-right: 1rem;
      }
      .ekit-wid-con .ekit-review-card--name {
        grid-area: name;
        font-size: 14px;
        font-weight: 700;
        margin: 0 0 0.25rem 0;
      }
      .ekit-wid-con .ekit-review-card--stars {
        grid-area: stars;
        color: #f4be28;
        font-size: 13px;
        line-height: 20px;
      }
      .ekit-wid-con .ekit-review-card--comment {
        grid-area: comment;
        font-size: 16px;
        line-height: 22px;
        font-weight: 400;
        color: #32323d;
      }
      .ekit-wid-con .ekit-review-card--actions {
        grid-area: actions;
      }
      .ekit-wid-con .ekit-review-card--posted-on {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        grid-area: posted-on;
      }
      .ekit-wid-con img:not([draggable]) {
        max-width: 100%;
        height: auto;
      }
      .ekit-wid-con a {
        text-decoration: none;
        outline: 0;
      }
      .ekit-wid-con a:visited {
        text-decoration: none;
        outline: 0;
      }
      .ekit-wid-con img {
        border: none;
        max-width: 100%;
      }
      .ekit-wid-con li,
      .ekit-wid-con ul {
        margin: 0;
        padding: 0;
      }
      .ekit-wid-con p {
        margin-bottom: 10px;
      }
      .ekit-wid-con .text-left {
        text-align: left !important;
      }
      .ekit-wid-con .text-center {
        text-align: center !important;
      }
      .ekit-wid-con .elementskit-navbar-nav-default.elementskit-menu-container {
        z-index: 1000;
      }
      .ekit-wid-con .elementor-icon-list-item .elementor-icon-list-text {
        display: block;
        margin-bottom: 0;
      }
      .ekit-wid-con .text-left {
        text-align: left !important;
      }
      .ekit-wid-con .text-center {
        text-align: center !important;
      }
      .ekit-wid-con .media {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-align: start;
        -ms-flex-align: start;
        align-items: flex-start;
      }
      @media (max-width: 1024px) {
        .ekit-wid-con .ekit-vertical-navbar-nav .elementskit-submenu-indicator {
          padding: 3px 10px;
          border: 1px solid;
          border-radius: 30px;
        }
      }
      .ekit-template-content-header {
        clear: both;
      }
      .ekit-sticky {
        z-index: 9999;
      }
      .ekit-wid-con .elementskit-infobox {
        padding: 60px 40px;
        border: 1px solid #f5f5f5;
        border-radius: 5px;
        background-color: #fff;
        position: relative;
        overflow: hidden;
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center center;
      }
      .ekit-wid-con .elementskit-infobox.media .elementskit-box-header {
        -webkit-box-flex: 0;
        -ms-flex: 0 0 auto;
        flex: 0 0 auto;
      }
      .ekit-wid-con .elementskit-infobox .elementskit-box-header {
        position: relative;
        z-index: 2;
      }
      .ekit-wid-con
        .elementskit-infobox
        .elementskit-box-header
        .elementskit-info-box-icon {
        display: inline-block;
        margin-bottom: 13px;
      }
      .ekit-wid-con .elementskit-infobox .box-body {
        position: relative;
        z-index: 2;
      }
      .ekit-wid-con .elementskit-infobox.icon-lef-right-aligin {
        padding: 15px;
      }
      .ekit-wid-con .elementskit-infobox.icon-lef-right-aligin {
        padding: 15px 30px;
      }
      .ekit-wid-con .elementskit-info-box-title {
        font-size: 23px;
        margin-top: 0;
      }
      .ekit-wid-con .elementskit-info-box-icon {
        display: inline-block;
      }
      .ekit-wid-con .elementskit-info-box-icon > i {
        color: #000;
        font-size: 64px;
      }
      .ekit-wid-con .elementskit-infobox {
        position: relative;
      }
      .ekit-wid-con .elementskit-btn {
        border-radius: 5px;
        font-size: 15px;
        padding: 15px 30px;
        display: inline-block;
        color: #fff;
        position: relative;
        display: inline-block;
        line-height: 1;
        white-space: nowrap;
        vertical-align: middle;
        text-align: center;
        background-color: #2575fc;
      }
      .ekit-wid-con .elementskit-btn::before {
        position: absolute;
        content: "";
        border-radius: inherit;
        z-index: -1;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        background-size: 102% 102%;
        opacity: 0;
      }
      .ekit-wid-con .elementskit-btn i {
        display: inline-block;
        vertical-align: middle;
      }
      .ekit-wid-con .ekit-heading {
        position: relative;
      }
      .ekit-wid-con .elementskit-section-title {
        margin: 0;
        margin-bottom: 20px;
        font-size: 28px;
      }
      .ekit-wid-con .elementskit-section-subtitle {
        font-size: 18px;
        font-weight: 700;
        color: rgba(0, 0, 0, 0.5);
      }
      .ekit-wid-con .elementskit-section-title {
        font-weight: 500;
      }
      .ekit-wid-con .elementskit-section-title-wraper.text_left {
        text-align: left;
      }
      .ekit-heading__description {
        display: inline-block;
        width: 100%;
        font-size: 16px;
        line-height: 24px;
      }
      .ekit-heading__description > p:first-child {
        margin-top: 10px;
      }
      .fa {
        display: inline-block;
        font: normal normal normal 14px/1 FontAwesome;
        font-size: inherit;
        text-rendering: auto;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      .fa-check:before {
        content: "\f00c";
      }
      .fa-arrow-left:before {
        content: "\f060";
      }
      .fa-arrow-right:before {
        content: "\f061";
      }
      .fa-chevron-down:before {
        content: "\f078";
      }
      .fa-bolt:before {
        content: "\f0e7";
      }
      .fa-info:before {
        content: "\f129";
      }
      .fa-database:before {
        content: "\f1c0";
      }
      input[type="text"] {
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
      }
      form[name="search-course"] {
        margin-bottom: 20px;
        position: relative;
      }
      form[name="search-course"] .search-course-input {
        width: 100%;
        padding: 12px;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
      }
      form[name="search-course"] .search-course-button {
        position: absolute;
        top: 1px;
        right: 1px;
        bottom: 1px;
        padding: 15px;
        height: auto;
        line-height: 1px;
      }
      .fa,
      .fas {
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        display: inline-block;
        font-style: normal;
        font-variant: normal;
        text-rendering: auto;
        line-height: 1;
      }
      .fa-arrow-left:before {
        content: "\f060";
      }
      .fa-arrow-right:before {
        content: "\f061";
      }
      .fa-bolt:before {
        content: "\f0e7";
      }
      .fa-check:before {
        content: "\f00c";
      }
      .fa-chevron-down:before {
        content: "\f078";
      }
      .fa-clipboard-list:before {
        content: "\f46d";
      }
      .fa-database:before {
        content: "\f1c0";
      }
      .fa-info:before {
        content: "\f129";
      }
      .fa-user-alt:before {
        content: "\f406";
      }
      .fa,
      .fas {
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
      }
      .elementor-10408
        .elementor-element.elementor-element-cfe0d9a
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10408 .elementor-element.elementor-element-cfe0d9a {
        overflow: visible;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10408
        .elementor-element.elementor-element-1d873e5b
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e3e3e8;
        margin: 20px 0px 0px 0px;
      }
      .elementor-10408
        .elementor-element.elementor-element-6dc284b9:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10408 .elementor-element.elementor-element-6dc284b9 {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10408 .elementor-element.elementor-element-6dc284b9 {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10408
        .elementor-element.elementor-element-5c230c43
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10408
        .elementor-element.elementor-element-5c230c43
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10408
        .elementor-element.elementor-element-1550ab7e
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10408
        .elementor-element.elementor-element-2a5a82da:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10408
        .elementor-element.elementor-element-2a5a82da
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10408
        .elementor-element.elementor-element-2a5a82da
        > .elementor-element-populated,
      .elementor-10408
        .elementor-element.elementor-element-2a5a82da
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10408
        .elementor-element.elementor-element-2a5a82da
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10408
        .elementor-element.elementor-element-4069be22
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10408
        .elementor-element.elementor-element-2dae1cfa
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10408
        .elementor-element.elementor-element-2dae1cfa
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10408 .elementor-element.elementor-element-5c230c43 {
          width: 100%;
        }
        .elementor-10408 .elementor-element.elementor-element-2a5a82da {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10408 .elementor-element.elementor-element-cfe0d9a {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10408
          .elementor-element.elementor-element-5c230c43
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10408
          .elementor-element.elementor-element-2a5a82da
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10408 .elementor-element.elementor-element-cfe0d9a {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10408 .elementor-element.elementor-element-6dc284b9 {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10408
          .elementor-element.elementor-element-5c230c43
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10408
          .elementor-element.elementor-element-2a5a82da
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10408
        .elementor-element.elementor-element-cfe0d9a.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-10424
        .elementor-element.elementor-element-5ffc43db
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10424 .elementor-element.elementor-element-5ffc43db {
        overflow: visible;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10424
        .elementor-element.elementor-element-744582df
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e3e3e8;
        margin: 20px 0px 0px 0px;
      }
      .elementor-10424
        .elementor-element.elementor-element-102064db:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10424 .elementor-element.elementor-element-102064db {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10424 .elementor-element.elementor-element-102064db {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10424
        .elementor-element.elementor-element-7e0a9ee0
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10424
        .elementor-element.elementor-element-7e0a9ee0
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10424
        .elementor-element.elementor-element-33cb0a69
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10424
        .elementor-element.elementor-element-7446175e:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10424
        .elementor-element.elementor-element-7446175e
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10424
        .elementor-element.elementor-element-7446175e
        > .elementor-element-populated,
      .elementor-10424
        .elementor-element.elementor-element-7446175e
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10424
        .elementor-element.elementor-element-7446175e
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10424
        .elementor-element.elementor-element-5514ad60
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10424
        .elementor-element.elementor-element-7c8bd984
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10424
        .elementor-element.elementor-element-7c8bd984
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10424 .elementor-element.elementor-element-7e0a9ee0 {
          width: 100%;
        }
        .elementor-10424 .elementor-element.elementor-element-7446175e {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10424 .elementor-element.elementor-element-5ffc43db {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10424
          .elementor-element.elementor-element-7e0a9ee0
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10424
          .elementor-element.elementor-element-7446175e
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10424 .elementor-element.elementor-element-5ffc43db {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10424 .elementor-element.elementor-element-102064db {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10424
          .elementor-element.elementor-element-7e0a9ee0
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10424
          .elementor-element.elementor-element-7446175e
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10424
        .elementor-element.elementor-element-5ffc43db.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-10436
        .elementor-element.elementor-element-7a5cc36b
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10436 .elementor-element.elementor-element-7a5cc36b {
        overflow: visible;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10436
        .elementor-element.elementor-element-28351a7a
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e3e3e8;
        margin: 20px 0px 0px 0px;
      }
      .elementor-10436
        .elementor-element.elementor-element-4ff459bc:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10436 .elementor-element.elementor-element-4ff459bc {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10436 .elementor-element.elementor-element-4ff459bc {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10436
        .elementor-element.elementor-element-264fe309
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10436
        .elementor-element.elementor-element-264fe309
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10436
        .elementor-element.elementor-element-7261642a
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10436
        .elementor-element.elementor-element-7453b50:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10436
        .elementor-element.elementor-element-7453b50
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10436
        .elementor-element.elementor-element-7453b50
        > .elementor-element-populated,
      .elementor-10436
        .elementor-element.elementor-element-7453b50
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10436
        .elementor-element.elementor-element-7453b50
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10436
        .elementor-element.elementor-element-4d8515a6
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10436
        .elementor-element.elementor-element-6408313d
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10436
        .elementor-element.elementor-element-6408313d
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10436 .elementor-element.elementor-element-264fe309 {
          width: 100%;
        }
        .elementor-10436 .elementor-element.elementor-element-7453b50 {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10436 .elementor-element.elementor-element-7a5cc36b {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10436
          .elementor-element.elementor-element-264fe309
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10436
          .elementor-element.elementor-element-7453b50
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10436 .elementor-element.elementor-element-7a5cc36b {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10436 .elementor-element.elementor-element-4ff459bc {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10436
          .elementor-element.elementor-element-264fe309
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10436
          .elementor-element.elementor-element-7453b50
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10436
        .elementor-element.elementor-element-7a5cc36b.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-10443
        .elementor-element.elementor-element-1743a22b
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10443 .elementor-element.elementor-element-1743a22b {
        overflow: visible;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10443
        .elementor-element.elementor-element-6e54d559
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e3e3e8;
        margin: 20px 0px 0px 0px;
      }
      .elementor-10443
        .elementor-element.elementor-element-120c32a5:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10443 .elementor-element.elementor-element-120c32a5 {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10443 .elementor-element.elementor-element-120c32a5 {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10443
        .elementor-element.elementor-element-1c3fc29
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10443
        .elementor-element.elementor-element-1c3fc29
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10443
        .elementor-element.elementor-element-7c72395e
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10443
        .elementor-element.elementor-element-3beb95d9:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10443
        .elementor-element.elementor-element-3beb95d9
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10443
        .elementor-element.elementor-element-3beb95d9
        > .elementor-element-populated,
      .elementor-10443
        .elementor-element.elementor-element-3beb95d9
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10443
        .elementor-element.elementor-element-3beb95d9
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10443
        .elementor-element.elementor-element-4ec1017a
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10443
        .elementor-element.elementor-element-4d72843a
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10443
        .elementor-element.elementor-element-4d72843a
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10443 .elementor-element.elementor-element-1c3fc29 {
          width: 100%;
        }
        .elementor-10443 .elementor-element.elementor-element-3beb95d9 {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10443 .elementor-element.elementor-element-1743a22b {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10443
          .elementor-element.elementor-element-1c3fc29
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10443
          .elementor-element.elementor-element-3beb95d9
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10443 .elementor-element.elementor-element-1743a22b {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10443 .elementor-element.elementor-element-120c32a5 {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10443
          .elementor-element.elementor-element-1c3fc29
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10443
          .elementor-element.elementor-element-3beb95d9
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10443
        .elementor-element.elementor-element-1743a22b.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-10447
        .elementor-element.elementor-element-60ca382b
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10447 .elementor-element.elementor-element-60ca382b {
        overflow: visible;
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e5e5e8;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10447
        .elementor-element.elementor-element-3d9b071c
        > .elementor-element-populated {
        margin: 20px 0px 0px 0px;
      }
      .elementor-10447
        .elementor-element.elementor-element-4d89ecb7:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10447 .elementor-element.elementor-element-4d89ecb7 {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10447 .elementor-element.elementor-element-4d89ecb7 {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10447
        .elementor-element.elementor-element-29f6ee29
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10447
        .elementor-element.elementor-element-29f6ee29
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10447
        .elementor-element.elementor-element-5b7f0fdf
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10447
        .elementor-element.elementor-element-7e5952ff:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10447
        .elementor-element.elementor-element-7e5952ff
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10447
        .elementor-element.elementor-element-7e5952ff
        > .elementor-element-populated,
      .elementor-10447
        .elementor-element.elementor-element-7e5952ff
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10447
        .elementor-element.elementor-element-7e5952ff
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10447
        .elementor-element.elementor-element-78ce3026
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10447
        .elementor-element.elementor-element-7922fcf
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10447
        .elementor-element.elementor-element-7922fcf
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10447 .elementor-element.elementor-element-29f6ee29 {
          width: 100%;
        }
        .elementor-10447 .elementor-element.elementor-element-7e5952ff {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10447 .elementor-element.elementor-element-60ca382b {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10447
          .elementor-element.elementor-element-29f6ee29
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10447
          .elementor-element.elementor-element-7e5952ff
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10447 .elementor-element.elementor-element-60ca382b {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10447 .elementor-element.elementor-element-4d89ecb7 {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10447
          .elementor-element.elementor-element-29f6ee29
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10447
          .elementor-element.elementor-element-7e5952ff
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10447
        .elementor-element.elementor-element-60ca382b.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-10451
        .elementor-element.elementor-element-4d66822f
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10451 .elementor-element.elementor-element-4d66822f {
        overflow: visible;
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e5e5e8;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10451
        .elementor-element.elementor-element-51ddf425
        > .elementor-element-populated {
        margin: 20px 0px 0px 0px;
      }
      .elementor-10451
        .elementor-element.elementor-element-46c4e4cd:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10451 .elementor-element.elementor-element-46c4e4cd {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10451 .elementor-element.elementor-element-46c4e4cd {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10451
        .elementor-element.elementor-element-33620f9
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10451
        .elementor-element.elementor-element-33620f9
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10451
        .elementor-element.elementor-element-118c94ca
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10451
        .elementor-element.elementor-element-7b8ea025:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10451
        .elementor-element.elementor-element-7b8ea025
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10451
        .elementor-element.elementor-element-7b8ea025
        > .elementor-element-populated,
      .elementor-10451
        .elementor-element.elementor-element-7b8ea025
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10451
        .elementor-element.elementor-element-7b8ea025
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10451
        .elementor-element.elementor-element-df43f4
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10451
        .elementor-element.elementor-element-1c405d62
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10451
        .elementor-element.elementor-element-1c405d62
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10451 .elementor-element.elementor-element-33620f9 {
          width: 100%;
        }
        .elementor-10451 .elementor-element.elementor-element-7b8ea025 {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10451 .elementor-element.elementor-element-4d66822f {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10451
          .elementor-element.elementor-element-33620f9
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10451
          .elementor-element.elementor-element-7b8ea025
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10451 .elementor-element.elementor-element-4d66822f {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10451 .elementor-element.elementor-element-46c4e4cd {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10451
          .elementor-element.elementor-element-33620f9
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10451
          .elementor-element.elementor-element-7b8ea025
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10451
        .elementor-element.elementor-element-4d66822f.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-10455
        .elementor-element.elementor-element-4ac70707
        > .elementor-container {
        max-width: 700px;
      }
      .elementor-10455 .elementor-element.elementor-element-4ac70707 {
        overflow: hidden;
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #e5e5e8;
        margin-top: -20px;
        margin-bottom: 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-10455
        .elementor-element.elementor-element-64e17297
        > .elementor-element-populated {
        margin: 20px 0px 0px 0px;
      }
      .elementor-10455
        .elementor-element.elementor-element-6f888eef:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-10455 .elementor-element.elementor-element-6f888eef {
        border-radius: 0px 0px 8px 0px;
      }
      .elementor-10455 .elementor-element.elementor-element-6f888eef {
        padding: 0px 0px 98px 0px;
        overflow: visible;
      }
      .elementor-10455
        .elementor-element.elementor-element-57b1b181
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #e3e3e8;
        margin: 0px 30px 0px 0px;
        padding: 20px 0px 0px 30px;
      }
      .elementor-10455
        .elementor-element.elementor-element-57b1b181
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        .elementor-repeater-item-f28fe76
        .ekit_menu_label {
        background-color: #1dc295;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        .elementor-icon-list-item
        > a {
        padding: 0px 0px 0px 0px !important;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        .elementor-icon-list-item {
        font-family: "Manrope", Sans-serif;
        font-size: 18px;
        font-weight: 400;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 12px;
        font-weight: 700;
        line-height: 15px;
        padding: 3px 8px 3px 8px;
        border-radius: 3px 3px 3px 3px;
        align-self: center;
      }
      .elementor-10455
        .elementor-element.elementor-element-6cde0c02
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
      }
      .elementor-10455
        .elementor-element.elementor-element-3bbb09e9:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-10455
        .elementor-element.elementor-element-3bbb09e9
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/03/mega-menu-bg.png");
        background-position: bottom right;
        background-repeat: no-repeat;
        background-size: auto;
        opacity: 1;
      }
      .elementor-10455
        .elementor-element.elementor-element-3bbb09e9
        > .elementor-element-populated,
      .elementor-10455
        .elementor-element.elementor-element-3bbb09e9
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-10455
        .elementor-element.elementor-element-3bbb09e9
        > .elementor-element-populated {
        margin: 20px 30px 0px 10px;
        padding: 45px 30px 16px 30px;
      }
      .elementor-10455
        .elementor-element.elementor-element-7864c246
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-10455
        .elementor-element.elementor-element-2503acc6
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-10455
        .elementor-element.elementor-element-2503acc6
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-size: 16px;
        font-weight: 600;
        background-color: #2878eb;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-10455 .elementor-element.elementor-element-57b1b181 {
          width: 100%;
        }
        .elementor-10455 .elementor-element.elementor-element-3bbb09e9 {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-10455 .elementor-element.elementor-element-4ac70707 {
          padding: 0px 20px 0px 20px;
        }
        .elementor-10455
          .elementor-element.elementor-element-57b1b181
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-10455
          .elementor-element.elementor-element-3bbb09e9
          > .elementor-element-populated {
          margin: 0px 60px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-10455 .elementor-element.elementor-element-4ac70707 {
          padding: 0px 0px 0px 0px;
        }
        .elementor-10455 .elementor-element.elementor-element-6f888eef {
          padding: 0px 0px 30px 0px;
        }
        .elementor-10455
          .elementor-element.elementor-element-57b1b181
          > .elementor-element-populated {
          border-width: 0px 0px 0px 0px;
          padding: 30px 0px 30px 15px;
        }
        .elementor-10455
          .elementor-element.elementor-element-3bbb09e9
          > .elementor-element-populated {
          margin: 0px 15px 0px 15px;
        }
      }
      .mega-menu-item
        .ekit_page_list_content
        .ekit_page_list_title_title:after {
        content: "";
        background: #2878eb;
        height: 1px;
        width: 0;
        position: absolute;
        left: 0;
        bottom: 12px;
        opacity: 0;
      }
      .elementor-10455
        .elementor-element.elementor-element-4ac70707.megamenu-section
        .elementor-container {
        margin-left: 0;
      }
      .elementor-8202 .elementor-element.elementor-element-51987094 {
        margin-top: 0px;
        margin-bottom: 0px;
        padding: 30px 220px 50px 220px;
        overflow: visible;
      }
      .elementor-8202
        .elementor-element.elementor-element-e857c1e:not(.elementor-motion-effects-element-type-background) {
        background-color: #ffffff;
      }
      .elementor-8202 .elementor-element.elementor-element-e857c1e {
        border-radius: 0px 0px 20px 20px;
      }
      .elementor-8202 .elementor-element.elementor-element-e857c1e {
        box-shadow: 0px 35px 35px 0px rgba(0, 0, 0, 0.1);
        overflow: visible;
      }
      .elementor-8202
        .elementor-element.elementor-element-56011e30
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-56011e30
        > .elementor-element-populated {
        padding: 50px 60px 46px 60px;
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        .elementskit-infobox {
        padding: 0px 0px 0px 0px;
        border-style: solid;
        border-width: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        .elementskit-infobox
        .elementskit-info-box-title {
        margin: 2px 0px 0px 0px;
        padding: 0px 0px 0px 10px;
        color: #2878eb;
        font-size: 18px;
        font-weight: 700;
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        .elementkit-infobox-icon {
        color: #f14d5d;
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        .elementskit-infobox
        .elementskit-info-box-icon
        i {
        font-size: 21px;
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        .elementskit-infobox
        .elementskit-box-header
        .elementskit-info-box-icon {
        margin: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        .elementskit-infobox
        .elementskit-info-box-icon {
        transform: rotate(0deg);
      }
      .elementor-8202
        .elementor-element.elementor-element-8f0e9b6
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-18c1e897
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-8202
        .elementor-element.elementor-element-18c1e897
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-3ecb29ae
        > .elementor-element-populated {
        border-style: solid;
        border-width: 0px 1px 0px 0px;
        border-color: #f0f0f0;
        padding: 50px 60px 46px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-3ecb29ae
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-575857d3
        .elementor-repeater-item-ac26393
        .ekit_menu_label {
        background-color: #ff057c;
      }
      .elementor-8202
        .elementor-element.elementor-element-575857d3
        .elementor-repeater-item-d88db12
        .ekit_menu_label {
        background-color: #7f5fef;
      }
      .elementor-8202
        .elementor-element.elementor-element-575857d3
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-8202
        .elementor-element.elementor-element-575857d3
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-575857d3
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 10px;
        font-weight: 700;
        line-height: 16px;
        margin: -10px 0px 0px 8px;
        padding: 0px 5px 0px 5px;
        align-self: center;
      }
      .elementor-8202
        .elementor-element.elementor-element-575857d3
        > .elementor-widget-container {
        margin: 35px 0px 0px 0px;
        padding: 0px 0px 0px 60px;
        border-style: solid;
        border-width: 0px 0px 0px 1px;
        border-color: #f0f0f0;
      }
      .elementor-8202
        .elementor-element.elementor-element-5daf1d7d
        > .elementor-element-populated {
        border-radius: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-5daf1d7d
        > .elementor-element-populated {
        padding: 50px 60px 46px 60px;
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        .elementskit-infobox {
        padding: 0px 0px 0px 0px;
        border-style: solid;
        border-width: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        .elementskit-infobox
        .elementskit-info-box-title {
        margin: 0px 0px 0px 0px;
        padding: 0px 0px 0px 10px;
        color: #2878eb;
        font-size: 18px;
        font-weight: 700;
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        .elementkit-infobox-icon {
        color: #f14d5d;
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        .elementskit-infobox
        .elementskit-info-box-icon
        i {
        font-size: 20px;
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        .elementskit-infobox
        .elementskit-box-header
        .elementskit-info-box-icon {
        margin: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        .elementskit-infobox
        .elementskit-info-box-icon {
        transform: rotate(0deg);
      }
      .elementor-8202
        .elementor-element.elementor-element-1a314d48
        > .elementor-widget-container {
        margin: 0px 0px 0px 0px;
        padding: 0px 0px 0px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-b2e5cd9
        .elementor-repeater-item-4cde5f1
        .ekit_menu_label {
        background-color: #f14d5d;
      }
      .elementor-8202
        .elementor-element.elementor-element-b2e5cd9
        .ekit_page_list_content {
        flex-direction: row;
      }
      .elementor-8202
        .elementor-element.elementor-element-b2e5cd9
        .elementor-icon-list-text {
        color: #54595f;
        margin: 0px 0px 10px 0px;
      }
      .elementor-8202
        .elementor-element.elementor-element-b2e5cd9
        .ekit_menu_label {
        font-family: "Manrope", Sans-serif;
        font-size: 10px;
        font-weight: 700;
        line-height: 16px;
        margin: -10px 0px 0px 8px;
        padding: 0px 5px 0px 5px;
        align-self: center;
      }
      .elementor-8202
        .elementor-element.elementor-element-6a8d2bc1:not(.elementor-motion-effects-element-type-background)
        > .elementor-column-wrap {
        background-color: #120f2d;
        background-image: url("wp-content/uploads/2021/01/bg_shape.png");
        background-position: center left;
        background-repeat: no-repeat;
      }
      .elementor-8202
        .elementor-element.elementor-element-6a8d2bc1
        > .elementor-element-populated
        > .elementor-background-overlay {
        background-image: url("wp-content/uploads/2021/01/image-1.png");
        background-position: bottom center;
        background-repeat: no-repeat;
        background-size: contain;
        opacity: 1;
      }
      .elementor-8202
        .elementor-element.elementor-element-6a8d2bc1
        > .elementor-element-populated,
      .elementor-8202
        .elementor-element.elementor-element-6a8d2bc1
        > .elementor-element-populated
        > .elementor-background-overlay {
        border-radius: 8px 8px 8px 8px;
      }
      .elementor-8202
        .elementor-element.elementor-element-6a8d2bc1
        > .elementor-element-populated {
        margin: 40px 40px 60px 0px;
        padding: 30px 30px 16px 30px;
      }
      .elementor-8202
        .elementor-element.elementor-element-72e92a1c
        .elementskit-section-title-wraper
        .elementskit-section-title {
        color: #ffffff;
        margin: 0px 0px 5px 0px;
        font-size: 23px;
        font-weight: 900;
      }
      .elementor-8202
        .elementor-element.elementor-element-45e88c48
        .ekit-btn-wraper {
        text-align: left;
      }
      .elementor-8202
        .elementor-element.elementor-element-45e88c48
        .elementskit-btn {
        padding: 15px 22px 15px 22px;
        font-weight: 600;
        background-color: #f14d5d;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
      }
      @media (max-width: 1024px) and (min-width: 768px) {
        .elementor-8202 .elementor-element.elementor-element-56011e30 {
          width: 100%;
        }
        .elementor-8202 .elementor-element.elementor-element-3ecb29ae {
          width: 100%;
        }
        .elementor-8202 .elementor-element.elementor-element-5daf1d7d {
          width: 100%;
        }
        .elementor-8202 .elementor-element.elementor-element-6a8d2bc1 {
          width: 100%;
        }
      }
      @media (max-width: 1024px) {
        .elementor-8202 .elementor-element.elementor-element-51987094 {
          padding: 0px 20px 0px 20px;
        }
        .elementor-8202
          .elementor-element.elementor-element-56011e30
          > .elementor-element-populated {
          margin: 0px 0px 0px 0px;
          padding: 30px 30px 30px 30px;
        }
        .elementor-8202
          .elementor-element.elementor-element-3ecb29ae
          > .elementor-element-populated {
          margin: 0px 0px 0px 0px;
          padding: 0px 30px 30px 30px;
        }
        .elementor-8202
          .elementor-element.elementor-element-575857d3
          > .elementor-widget-container {
          margin: 0px 0px 0px 0px;
          padding: 0px 0px 0px 0px;
          border-width: 0px 0px 0px 0px;
        }
        .elementor-8202
          .elementor-element.elementor-element-5daf1d7d
          > .elementor-element-populated {
          padding: 30px 30px 30px 30px;
        }
        .elementor-8202
          .elementor-element.elementor-element-6a8d2bc1
          > .elementor-element-populated {
          margin: 0px 30px 60px 30px;
          padding: 100px 0px 100px 30px;
        }
      }
      @media (max-width: 767px) {
        .elementor-8202 .elementor-element.elementor-element-51987094 {
          padding: 0px 0px 0px 0px;
        }
        .elementor-8202 .elementor-element.elementor-element-e857c1e {
          padding: 0px 0px 0px 0px;
        }
        .elementor-8202
          .elementor-element.elementor-element-56011e30
          > .elementor-element-populated {
          padding: 30px 0px 0px 30px;
        }
        .elementor-8202
          .elementor-element.elementor-element-3ecb29ae
          > .elementor-element-populated {
          margin: 6px 0px 0px 0px;
        }
        .elementor-8202
          .elementor-element.elementor-element-575857d3
          > .elementor-widget-container {
          margin: 0px 0px 0px 0px;
        }
      }
      @media (min-width: 1024px) and (max-width: 1600px) {
        .elementor-8202
          .elementor-element.elementor-element-51987094.megamenu-section {
          padding: 30px 120px 50px 120px;
        }
      }
    </style>
    <link
      rel="preload"
      href="https://fonts.googleapis.com/css?family=Manrope%3Aregular%2C700%2C400%2C900%7CRoboto%3A300%2C300i%2C400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CRubik%3A400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CManrope%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=swap"
      data-rocket-async="style"
      as="style"
      onload="this.onload=null;this.rel='stylesheet'"
    />
    <link
      rel="preload"
      href="wp-content/cache/min/1/48674de4d79417baaca3cb45b8aaf4fe.css"
      data-rocket-async="style"
      as="style"
      onload="this.onload=null;this.rel='stylesheet'"
      media="all"
      data-minify="1"
    />
    <meta name="robots" content="max-image-preview:large" />
    <link rel="dns-prefetch" href="http://fonts.googleapis.com/" />
    <link href="https://fonts.gstatic.com/" crossorigin rel="preconnect" />
    <link
      rel="alternate"
      type="application/rss+xml"
      title="Courselog &raquo; Feed"
      href="feed/index.html"
    />
    <link
      rel="alternate"
      type="application/rss+xml"
      title="Courselog &raquo; Comments Feed"
      href="comments/feed/index.html"
    />
    <style type="text/css">
      img.wp-smiley,
      img.emoji {
        display: inline !important;
        border: none !important;
        box-shadow: none !important;
        height: 1em !important;
        width: 1em !important;
        margin: 0 0.07em !important;
        vertical-align: -0.1em !important;
        background: none !important;
        padding: 0 !important;
      }
    </style>

    <link
      rel="preload"
      href="wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreenbb49.css?ver=5.2.2"
      data-rocket-async="style"
      as="style"
      onload="this.onload=null;this.rel='stylesheet'"
      type="text/css"
      media="only screen and (max-width: 768px)"
    />

    <style id="woocommerce-inline-inline-css" type="text/css">
      .woocommerce form .form-row .required {
        visibility: visible;
      }
    </style>

    <style id="courselog-style-inline-css" type="text/css">
      body {
        font-family: "Manrope";
        font-size: 16px;
      }

      h1 {
        font-family: "Manrope";
        font-weight: 700;
      }
      h2 {
        font-family: "Manrope";
        font-weight: 700;
      }
      h3 {
        font-family: "Manrope";
        font-weight: 700;
      }

      h4 {
        font-family: "Manrope";
        font-weight: 700;
      }

      .entry-header .entry-title a:hover,
      .sidebar ul li a:hover {
        color: #f14d5d;
      }

      .entry-header .entry-title a {
        color: #120f2d;
      }

      body {
        background-color: #fff;
      }

      .single-intro-text .count-number,
      .sticky.post .meta-featured-post,
      .latest-blog .post .post-meta span:before,
      .sidebar .widget .widget-title:before,
      .pagination li.active a:hover,
      .tag-lists a:hover,
      .tagcloud a:hover,
      .BackTo,
      .ticket-btn.btn:hover,
      .btn-primary,
      .BackTo,
      .woocommerce ul.products li.product .button,
      .woocommerce ul.products li.product .added_to_cart,
      .woocommerce nav.woocommerce-pagination ul li a:focus,
      .woocommerce nav.woocommerce-pagination ul li a:hover,
      .woocommerce nav.woocommerce-pagination ul li span.current,
      .woocommerce #respond input#submit.alt,
      .woocommerce a.button.alt,
      .woocommerce button.button.alt,
      .woocommerce input.button.alt,
      .sponsor-web-link a:hover i,
      .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
      .woocommerce span.onsale,
      #preloader,
      .header .navbar-container .navbar-light .main-menu > li > a:before,
      .tab-course-category ul li:before,
      .co-single-instructor .co-instructors-socials li a:hover,
      .course-entry-content
        .curriculum-content
        .curricolumn-list
        li
        a
        .curricolumn-preview,
      .course-single-wrap .single-course .course-price-item span,
      .single-course .course-category a:before,
      .course-entry-content ul.nav li a:before,
      .courselog-search-course-form .search-course-button,
      .main-slider-style3 .slider-content .sub-title::before,
      .main-menu .elementskit-navbar-nav > li > a::after,
      .btn-primary,
      .learnpress-page .lp-button,
      .place-order-action .lp-button,
      #learn-press-content-item
        #course-item-content-header
        .toggle-content-item,
      #learn-press-content-item #course-item-content-header .lp-button:hover,
      #learn-press-course-curriculum.course-curriculum
        ul.curriculum-sections
        .section-content
        .course-item
        .course-item-meta
        span,
      .course-entry-content .public-xs-review-box .xs-save-button button,
      .header-login-user a sup,
      .cartbtn a sup,
      .user-dashboard .order-recover .button-recover-order,
      .single_add_to_cart_button,
      .tutor-btn,
      .tutor-button,
      a.tutor-btn,
      a.tutor-button,
      .courselog-events .entry-header .event-time:before,
      .courselog-tab .courselog-navs-tab li a .title-content .content::before,
      .learndash-wrapper .ld-primary-background,
      .learndash-wrapper .ld-tabs .ld-tabs-navigation .ld-tab.ld-active:after,
      .learndash-wrapper .ld-primary-background,
      .learndash-wrapper .ld-tabs .ld-tabs-navigation .ld-tab.ld-active:after,
      .courselog-learndash-course
        .ld-single-course
        .ld-course-footer
        .ld-course-price,
      .ld-related-course .ld-single-course .ld-course-footer .ld-course-price,
      .user-dashboard
        #learn-press-profile-nav
        .learn-press-tabs.tabs
        li.active
        > a,
      .user-dashboard
        #learn-press-profile-nav
        .learn-press-tabs.tabs
        li:hover
        > a,
      .woocommerce ul.products li.product .added_to_cart:hover,
      .woocommerce #respond input#submit.alt:hover,
      .woocommerce a.button.alt:hover,
      .woocommerce button.button.alt:hover,
      .woocommerce input.button.alt:hover,
      .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
        background: #f14d5d;
      }
      .btn-primary,
      .btn-primary,
      .learnpress-page .lp-button,
      .place-order-action .lp-button,
      .courselog-learndash-course
        .ld-single-course
        .ld-course-footer
        .ld-course-read-more:hover
        a,
      .ld-related-course
        .ld-single-course
        .ld-course-footer
        .ld-course-read-more:hover
        a,
      .single_add_to_cart_button,
      .tutor-btn,
      .tutor-button,
      a.tutor-btn,
      a.tutor-button,
      .owl-carousel .owl-dots .owl-dot.active {
        border-color: #f14d5d;
      }
      .user-dashboard .lp-profile-content .lp-tab-sections li.active span {
        border-bottom-color: #f14d5d;
      }

      #learn-press-course-curriculum.course-curriculum
        ul.curriculum-sections
        .section-content
        .course-item.current
        a:hover {
        color: #fff;
      }
      .copyright .footer-social li a i:hover,
      .copyright .copyright-text a,
      .header .navbar-container .navbar-light .main-menu li a:hover,
      .header .navbar-container .navbar-light .main-menu li.active > a,
      .post .entry-header .entry-title a:hover,
      a:hover,
      .ts-course-category
        .single-course-category
        .course-category-title
        a:hover,
      .courselog-events .entry-header .entry-title a:hover,
      .woocommerce ul.products li.product .price,
      .footer-widget ul li a:hover,
      .ts-footer .footer-menu li a:hover,
      .courselog-course-latest h3.post-title a:hover,
      .courselog-course-latest p,
      .courselog-learndash-course
        .ld-single-course
        .ld-course-conent:hover
        .ts-title
        a,
      .ld-related-course .ld-single-course .ld-course-conent:hover .ts-title a,
      .courselog-learndash-course
        .ld-single-course
        .ld-course-footer
        .ld-course-read-more:hover
        a,
      .ld-related-course
        .ld-single-course
        .ld-course-footer
        .ld-course-read-more:hover
        a,
      .course-entry-content .curriculum-content .curricolumn-list li a i,
      .course-entry-content .curriculum-content .curricolumn-list li a:hover,
      .co-single-instructor .co-instructor-title a:hover,
      .course-entry-content .curriculum-content .curriculmn-title:after,
      .post-navigation span:hover,
      .post-navigation h3:hover,
      .comments-list .comment-reply-link:hover,
      .tutor-custom-list-style li:before,
      .ld-tabs .ld-tabs-navigation .ld-tab.ld-active span,
      .courselog-tab .courselog-navs-tab li a .title-content .title-icon,
      .user-dashboard .lp-profile-content table td a:hover,
      .user-dashboard .lp-profile-content table th a:hover,
      .user-dashboard .lp-profile-content .lp-list-table td a:hover,
      .user-dashboard .lp-profile-content .lp-list-table th a:hover,
      #learn-press-course-curriculum.course-curriculum
        ul.curriculum-sections
        .section-content
        .course-item
        .section-item-link:hover,
      .woocommerce
        ul.products
        li.product
        .woocommerce-loop-product__title:hover {
        color: #f14d5d;
      }

      /*  secondary color   */

      .single-course .course-footer .course-price-item .course-price,
      .single-course .course-footer .course-price-item .free-course,
      .btn-primary:hover,
      .btn-primary:active,
      .learn-press-form-login form button:hover,
      .learn-press-form-login form button:active,
      .learnpress-page .lp-button:hover,
      .course-single-wrap .single-course:hover .course-price-item span,
      .header--course-meta .course-price span,
      .course-entry-content .public-xs-review-box .xs-save-button button:hover,
      #learn-press-course-curriculum.course-curriculum
        ul.curriculum-sections
        .section-content
        .course-item.item-preview
        .course-item-status,
      #learn-press-course-curriculum.course-curriculum
        ul.curriculum-sections
        .section-content
        .course-item.current:before,
      .user-dashboard .lp-profile-content .lp-tab-sections,
      .course-entry-content ul.nav,
      .pagination li.active a,
      .pagination li:hover a,
      .pagination li:hover a:hover,
      .learnpress-page .lp-button:active,
      .place-order-action .lp-button:hover,
      .place-order-action .lp-button:active {
        background-color: #2878eb;
      }

      .archive-widgets ul li.active a {
        color: #2878eb;
      }

      .btn-primary:hover,
      .btn-primary:active,
      .learn-press-form-login form button:hover,
      .learn-press-form-login form button:active,
      .learnpress-page .lp-button:hover,
      .learnpress-page .lp-button:active,
      .place-order-action .lp-button:hover,
      .place-order-action .lp-button:active {
        border-color: #2878eb;
      }

      .ts-footer {
        background-color: #273c66;
      }

      .copyright .copyright-text {
        color: #fff;
      }
    </style>

    <style id="rocket-lazyload-inline-css" type="text/css">
      .rll-youtube-player {
        position: relative;
        padding-bottom: 56.23%;
        height: 0;
        overflow: hidden;
        max-width: 100%;
      }
      .rll-youtube-player iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 100;
        background: 0 0;
      }
      .rll-youtube-player img {
        bottom: 0;
        display: block;
        left: 0;
        margin: auto;
        max-width: 100%;
        width: 100%;
        position: absolute;
        right: 0;
        top: 0;
        border: none;
        height: auto;
        cursor: pointer;
        -webkit-transition: 0.4s all;
        -moz-transition: 0.4s all;
        transition: 0.4s all;
      }
      .rll-youtube-player img:hover {
        -webkit-filter: brightness(75%);
      }
      .rll-youtube-player .play {
        height: 72px;
        width: 72px;
        left: 50%;
        top: 50%;
        margin-left: -36px;
        margin-top: -36px;
        position: absolute;
        background: url(wp-content/plugins/wp-rocket/assets/img/youtube.png)
          no-repeat;
        cursor: pointer;
      }
    </style>

    <script
      type="text/javascript"
      src="wp-includes/js/jquery/jquery.min9d52.js?ver=3.5.1"
      id="jquery-core-js"
    ></script>
    <script
      type="text/javascript"
      src="wp-includes/js/jquery/jquery-migrate.mind617.js?ver=3.3.2"
      id="jquery-migrate-js"
    ></script>
    <script
      data-minify="1"
      type="text/javascript"
      src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/learnpress-wishlist/assets/js/wishlist32f0.js?ver=1619375310"
      id="lp-course-wishlist-script-js"
    ></script>
    <script
      data-rocketlazyloadscript="https://demo.themewinter.com/wp/courselog/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.1.4"
      type="text/javascript"
      id="font-awesome-4-shim-js"
    ></script>
    <script
      data-minify="1"
      type="text/javascript"
      src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-social/assets/js/social-front32f0.js?ver=1619375310"
      id="xs_social_custom-js"
    ></script>
    <script
      data-minify="1"
      type="text/javascript"
      src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-ultimate-review/assets/public/script/content-page32f0.js?ver=1619375310"
      id="wur_review_content_script-js"
    ></script>
    <script
      data-minify="1"
      type="text/javascript"
      src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/jarallax32f0.js?ver=1619375310"
      id="jarallax-js"
    ></script>
    <script
      type="text/javascript"
      src="wp-content/themes/courselog/assets/js/jquery.repeater.minefb0.js?ver=%201.2.9"
      id="jquery-repeater-min-js"
    ></script>
    <script
      type="text/javascript"
      src="wp-includes/js/underscore.min4511.js?ver=1.8.3"
      id="underscore-js"
    ></script>
    <script type="text/javascript" id="utils-js-extra">
      /* <![CDATA[ */
      var userSettings = {
        url: "\/wp\/courselog\/",
        uid: "0",
        time: "1619594924",
        secure: "1",
      };
      /* ]]> */
    </script>
    <script
      type="text/javascript"
      src="wp-includes/js/utils.mina78f.js?ver=5.7.1"
      id="utils-js"
    ></script>
    <script type="text/javascript" id="lp-global-js-extra">
      /* <![CDATA[ */
      var lpGlobalSettings = {
        url: null,
        siteurl: "https:\/\/demo.themewinter.com\/wp\/courselog",
        ajax: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-admin\/admin-ajax.php",
        theme: "courselog",
        localize: {
          button_ok: "OK",
          button_cancel: "Cancel",
          button_yes: "Yes",
          button_no: "No",
        },
        show_popup_confirm_finish: "yes",
      };
      /* ]]> */
    </script>
    <script
      type="text/javascript"
      src="wp-content/plugins/learnpress/assets/js/global.min4e1b.js?ver=3.2.8.8"
      id="lp-global-js"
    ></script>
    <script
      type="text/javascript"
      src="wp-content/plugins/learnpress/assets/js/dist/utils.min4e1b.js?ver=3.2.8.8"
      id="lp-utils-js"
    ></script>
    <script
      type="text/javascript"
      src="wp-content/plugins/learnpress/assets/src/js/vendor/watch.min4e1b.js?ver=3.2.8.8"
      id="watch-js"
    ></script>
    <script
      type="text/javascript"
      src="wp-content/plugins/learnpress/assets/js/vendor/plugins.all.min4e1b.js?ver=3.2.8.8"
      id="lp-plugins-all-js"
    ></script>
    <link rel="https://api.w.org/" href="wp-json/index.html" />
    <link
      rel="alternate"
      type="application/json"
      href="wp-json/wp/v2/pages/5.json"
    />
    <link
      rel="EditURI"
      type="application/rsd+xml"
      title="RSD"
      href="xmlrpc0db0.php?rsd"
    />
    <link
      rel="wlwmanifest"
      type="application/wlwmanifest+xml"
      href="wp-includes/wlwmanifest.xml"
    />
    <meta name="generator" content="WordPress 5.7.1" />
    <meta name="generator" content="WooCommerce 5.2.2" />
    <link rel="canonical" href="index.html" />
    <link rel="shortlink" href="index.html" />
    <link
      rel="alternate"
      type="application/json+oembed"
      href="wp-json/oembed/1.0/embed1964.json?url=https%3A%2F%2Fdemo.themewinter.com%2Fwp%2Fcourselog%2F"
    />
    <link
      rel="alternate"
      type="text/xml+oembed"
      href="wp-json/oembed/1.0/embeda190?url=https%3A%2F%2Fdemo.themewinter.com%2Fwp%2Fcourselog%2F&amp;format=xml"
    />
    <noscript
      ><style>
        .woocommerce-product-gallery {
          opacity: 1 !important;
        }
      </style></noscript
    >

    <script type="text/javascript">
      var elementskit_module_parallax_url =
        "wp-content/plugins/courselog-essential/modules/parallax/index.html";
    </script>
    <style type="text/css" id="wp-custom-css">
      .single-course-item.course-grid-style2
        .single-course
        .course-title-area
        .course-category
        span {
        padding: 5px 0 5px 0;
      }

      .single-course-item.course-grid-style2
        .single-course
        .xs-review-rattting {
        margin-right: 10px;
      }

      .single-course-item.course-grid-style2
        .single-course
        .xs-review-rattting
        .xs-star {
        color: #ffcc00;
      }
      .single-course-item.course-grid-style2
        .single-course:hover
        .xs-review-rattting
        .xs-star {
        color: #fff;
      }

      .elementor-widget-elementskit-blog-posts .meta-date i,
      .elementor-widget-elementskit-blog-posts.post-cat i {
        vertical-align: middle;
      }
      .elementor-widget-elementskit-blog-posts .meta-date i {
        color: #3478f6;
      }

      .elementor-widget-elementskit-blog-posts .post-cat i {
        color: #0acc86;
      }
      .elementor-widget-elementskit-blog-posts .btn-wraper a i {
        margin-right: 5px;
        vertical-align: middle;
      }

      .elementor-widget-elementskit-blog-posts .btn-wraper a {
        position: relative;
      }

      .elementor-widget-elementskit-blog-posts .btn-wraper a:after {
        position: absolute;
        content: "";
        right: 0px;
        border-bottom: 2px solid #333333;
        width: 80%;
        bottom: -3px;
        transition: all ease 0.4s;
      }
      .elementor-widget-elementskit-blog-posts .btn-wraper:hover a:after {
        opacity: 0;
        visibility: hidden;
      }

      .single-course-item.course-grid-style2 .single-course:hover .hover {
        padding: 40px !important;
      }
      .nav-style-classic:after {
        background: linear-gradient(
          to right,
          #fdbb28 15%,
          #fdbb28 10%,
          #fa4142 10%,
          #fa4142 30%,
          #3478f6 10%,
          #3478f6 45%,
          #0acc86 10%,
          #0acc86 60%,
          #fdbb28 10%,
          #fdbb28 75%,
          #fa4142 10%,
          #fa4142 90%,
          #3478f6 10%,
          #3478f6 90%
        );
        position: absolute;
        content: "";
        height: 2px;
        right: 0;
        left: 0;
        top: 0;
      }
      .single-course-item.course-grid-style2
        .single-course:hover
        .hover
        .course-category {
        padding: 5px 0px;
      }
      .ts-scroll-box .BackTo a {
        font-size: 16px;
      }
      .instructor-list-wrap .single-instructor-item .instructor-social a {
        font-size: 16px;
      }
      .course-grid-style2 .single-course .course-category a:before {
        background: transparent;
      }
      .insturctor-single
        .single-course-item.course-grid-style2
        .single-course
        .excerpt-content
        p {
        display: none;
      }
      .course-full-width-content .turitor-list li:after {
        background: #fa4142;
      }
      .cl-main-header {
        box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.03);
      }
      .ts-cat-menu .menu li .sub-menu li a {
        border-bottom: 0px solid #2878eb;
      }
      .ts-cat-menu .menu li .sub-menu li a:after {
        display: none;
      }

      .ts-cat-menu .sub-menu {
        position: absolute;
        left: 28px;
        top: 30px;
        list-style: none;
        background: #fff;
        min-width: 150px;
        padding: 0;
        -webkit-box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.2);
        box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.2);
        border: none;
        transition: transform 0.4s ease, -webkit-transform 0.4s ease;
        margin: 0;
        z-index: 11;
        transform: translateY(20px);
        display: block;
        border-radius: 6px;
        -webkit-border-radius: 6px;
        -ms-border-radius: 6px;
        opacity: 0;
        visibility: hidden;
      }

      .ts-cat-menu .menu .sub-menu li {
        border-style: solid;
        border-width: 0px 0px 1px 0px;
        border-color: #f0f0f0;
        background-color: #ffffff;
        border-radius: 0px;
        padding: 15px 30px 15px 15px;
      }

      .ts-cat-menu .menu .menu-item:hover .sub-menu {
        transform: translateY(5px);
        opacity: 1;
        visibility: visible;
      }

      @media (max-width: 992px) {
        .elementor-widget-turitor-userlogin {
          display: block !important;
        }
      }
      @media (max-width: 1600px) {
        .ekit-section-parallax-layer {
          display: none;
        }
        .skew-column .elementor-element-populated {
          background: none !important;
        }
      }
      .instructor-list-wrap
        .single-instructor-item:hover
        .instructor-profile-content
        .instructor-social {
        bottom: 25% !important;
      }
      .start-quiz button {
        padding: 10px 22px 10px 22px;
        background-color: #f14d5d;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
        color: #fff;
        cursor: pointer;
        border-radius: 50px;
      }

      .lp-quiz-buttons .form-button button {
        padding: 10px 22px 10px 22px;
        background-color: #f14d5d;
        border-style: none;
        border-radius: 5px 5px 5px 5px;
        color: #fff;
        cursor: pointer;
        border-radius: 50px;
      }
      @media (max-width: 768px) {
        .elementskit-navbar-nav-default
          .elementskit-dropdown-has
          > a
          .elementskit-submenu-indicator {
          margin-left: auto !important;
          border-color: transparent;
        }
      }

      .tab-course-category ul li:hover:before,
      .tab-course-category ul li.active:before {
        background: rgba(255, 255, 255, 0.5);
      }

      .ts-instructor-profile-info {
        margin-bottom: 50px;
      }
      .user-meta-summery {
        margin-bottom: 60px;
      }

      .elementskit-dropdown-has > a .elementskit-submenu-indicator {
        margin: 0px 0px 0px auto;
        margin-left: auto;
        border: none;
      }
      .banner-course .course-instructor .course-instructor-thumb img {
        width: 36px;
        height: 36px;
      }

      .courselog-instructor-profile-header .ts-instructor-info .ts-title {
        margin: 0;
        text-transform: capitalize;
      }
      @media (min-width: 575px) and (max-width: 1024px) {
        .header-course-search .courselog-search-course-form {
          width: 50%;
        }
      }
      @media (max-width: 1024px) {
        .elementskit-navbar-nav .elementskit-submenu-panel {
          background-color: transparent !important;
        }
      }
      .archive-course-container.archive-course-solid .archive-style-solid {
        padding-bottom: 250px;
        margin-bottom: -200px;
      }
      .tab-course-category ul li {
        padding-left: 30px;
      }

      .cl-main-header.ekit-sticky {
        z-index: 999;
      }
    </style>
    <noscript
      ><style id="rocket-lazyload-nojs-css">
        .rll-youtube-player,
        [data-lazy-src] {
          display: none !important;
        }
      </style></noscript
    >
    <script>
      /*! loadCSS rel=preload polyfill. [c]2017 Filament Group, Inc. MIT License */
      (function (w) {
        "use strict";
        if (!w.loadCSS) {
          w.loadCSS = function () {};
        }
        var rp = (loadCSS.relpreload = {});
        rp.support = (function () {
          var ret;
          try {
            ret = w.document.createElement("link").relList.supports("preload");
          } catch (e) {
            ret = !1;
          }
          return function () {
            return ret;
          };
        })();
        rp.bindMediaToggle = function (link) {
          var finalMedia = link.media || "all";
          function enableStylesheet() {
            link.media = finalMedia;
          }
          if (link.addEventListener) {
            link.addEventListener("load", enableStylesheet);
          } else if (link.attachEvent) {
            link.attachEvent("onload", enableStylesheet);
          }
          setTimeout(function () {
            link.rel = "stylesheet";
            link.media = "only x";
          });
          setTimeout(enableStylesheet, 3000);
        };
        rp.poly = function () {
          if (rp.support()) {
            return;
          }
          var links = w.document.getElementsByTagName("link");
          for (var i = 0; i < links.length; i++) {
            var link = links[i];
            if (
              link.rel === "preload" &&
              link.getAttribute("as") === "style" &&
              !link.getAttribute("data-loadcss")
            ) {
              link.setAttribute("data-loadcss", !0);
              rp.bindMediaToggle(link);
            }
          }
        };
        if (!rp.support()) {
          rp.poly();
          var run = w.setInterval(rp.poly, 500);
          if (w.addEventListener) {
            w.addEventListener("load", function () {
              rp.poly();
              w.clearInterval(run);
            });
          } else if (w.attachEvent) {
            w.attachEvent("onload", function () {
              rp.poly();
              w.clearInterval(run);
            });
          }
        }
        if (typeof exports !== "undefined") {
          exports.loadCSS = loadCSS;
        } else {
          w.loadCSS = loadCSS;
        }
      })(typeof global !== "undefined" ? global : this);
    </script>
  </head>
  <body
    class="
      home
      page-template
      page-template-template
      page-template-homepage-template
      page-template-templatehomepage-template-php
      page
      page-id-5
      theme-courselog
      woocommerce-no-js
      sidebar-active
      elementor-default elementor-kit-573 elementor-page elementor-page-5
    "
  >
