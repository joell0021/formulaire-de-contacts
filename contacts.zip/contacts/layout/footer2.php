  <!--footer-->
  <div class="ekit-template-content-markup ekit-template-content-footer ekit-template-content-theme-support" style="background-color: #2878eb;">
    <div data-elementor-type="wp-post" data-elementor-id="8566" class="elementor elementor-8566" data-elementor-settings="[]">
      <div class="elementor-inner">
        <div class="elementor-section-wrap">
          <section class="elementor-section elementor-top-section elementor-element elementor-element-c2193ea elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c2193ea" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
            <div class="elementor-background-overlay"></div>
            <div class="elementor-container elementor-column-gap-default">
              <div class="elementor-row">
                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9690007" data-id="9690007" data-element_type="column">
                  <div class="elementor-column-wrap elementor-element-populated">
                    <div class="elementor-widget-wrap">
                      <section class="elementor-section elementor-inner-section elementor-element elementor-element-26553ce elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="26553ce" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
                        <div class="elementor-container elementor-column-gap-default">
                          <div class="elementor-row">


                            <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-9b6bfe5" data-id="9b6bfe5" data-element_type="column">
                              <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                  <div class="elementor-element elementor-element-4f0153e elementor-widget elementor-widget-courselog-logo" data-id="4f0153e" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="courselog-logo.default">
                                    <div class="elementor-widget-container">
                                      <div class="courselog-widget-logo">
                                        <a href="">
                                          <img src="../assets/img/logoprim.jpg" alt="Courselog" data-lazy-src="../assets/img/logoprim.jpg">
                                          <noscript><img src="../assets/img/logoprim.jpg" alt="Courselog"></noscript>
                                        </a>
                                      </div>

                                    </div>
                                  </div>


                                </div>
                              </div>
                            </div>
                            <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b2b6e77" data-id="b2b6e77" data-element_type="column">
                              <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                  <div class="elementor-element elementor-element-3a91400 elementor-widget elementor-widget-elementskit-heading" data-id="3a91400" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                                    <div class="elementor-widget-container">
                                      <div class="ekit-wid-con">
                                        <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                          <ul class="ekit_social_media">

                                            <li class="elementor-repeater-item-d580217" style="display: inline-block; padding: 14px;">
                                              <a href="" class="facebook">

                                                <i aria-hidden="true" class="icon icon-facebook "></i>
                                              </a>
                                            </li>
                                            <li class="elementor-repeater-item-76ac81f" style="display: inline-block; padding: 14px;">
                                              <a href="" class="1 ">
                                                <i aria-hidden="true" class="icon icon-instagram-1 "></i>
                                              </a>
                                            </li>

                                            <li class="elementor-repeater-item-d5286e9" style="display: inline-block; padding: 14px;">
                                              <a href="" class="twitter">
                                                <i aria-hidden="true" class="icon icon-twitter"></i>
                                              </a>
                                            </li>

                                            <li class="elementor-repeater-item-d5286e9" style="display: inline-block; padding: 14px;">
                                              <a href="" class="twitter">
                                                <i aria-hidden="true" class="icon icon-location">MAP</i>
                                              </a>
                                            </li>

                                          </ul>

                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div class="elementor-element elementor-element-648929d elementor-widget elementor-widget-elementskit-page-list" data-id="648929d" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                    <div class="elementor-widget-container">
                                      <div class="ekit-wid-con">
                                        <div class="elementor-icon-list-items ">


                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <!--newsletter-->
                            <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-b2b6e77" data-id="b2b6e77" data-element_type="column">
                              <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                  <div class="elementor-element elementor-element-3a91400 elementor-widget elementor-widget-elementskit-heading" data-id="3a91400" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                                    <div class="elementor-widget-container">
                                      <div class="ekit-wid-con">
                                        <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                          <h6 style="color:black">Souscrivez A Notre Newsletter</h6>
                                          <div class="elementor-element elementor-element-aa9c61b elementor-widget elementor-widget-courselog-course-search" data-id="aa9c61b" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="courselog-course-search.default">
                                            <div class="elementor-widget-container">

                                              <div class="courselog-course-search header-course-search">
                                                <form method="get" name="search-course" class="courselog-search-course-form" action="mail.php">
                                                  <input type="text" name="s" class="search-course-input" placeholder="Email..." />
                                                  <input type="hidden" name="ref" value="course" />

                                                  <button class="lp-button button search-course-button">ok</button>
                                                </form>
                                              </div>

                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>


                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </div>

  </section>
  <section style="background-color: black;" class="elementor-section elementor-top-section elementor-element elementor-element-55945e6 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="55945e6" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
    <div class="elementor-container elementor-column-gap-default">
      <div class="elementor-row">
        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-24a6fc3" data-id="24a6fc3" data-element_type="column">
          <div class="elementor-column-wrap elementor-element-populated">
            <div class="elementor-widget-wrap">
              <div class="elementor-element elementor-element-6806583 elementor-widget elementor-widget-elementskit-heading" data-id="6806583" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                <div class="elementor-widget-container">
                  <div class="ekit-wid-con">
                    <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                      <div class='ekit-heading__description'>
                        <p class="text-white">&copy; <?php echo date('Y'); ?> . All Rights Reserved.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-bce67fd" data-id="bce67fd" data-element_type="column">
          <div class="elementor-column-wrap elementor-element-populated">
            <div class="elementor-widget-wrap">
              <div class="elementor-element elementor-element-8cfdf1d elementor-align-right elementor-mobile-align-left elementor-tablet-align-left elementor-widget elementor-widget-elementskit-page-list" data-id="8cfdf1d" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                <div class="elementor-widget-container">
                  <div class="ekit-wid-con">
                    <div class="elementor-icon-list-items  elementor-inline-items">
                      <div class="elementor-icon-list-item   ">
                        <a target=_blank rel="" href="../index.php" class="elementor-repeater-item-7403058 ">
                          <div class="ekit_page_list_content">
                            <span class="elementor-icon-list-text">
                              <span class="ekit_page_list_title_title text-white">Accueil</span>
                            </span>
                          </div>
                        </a>
                      </div>
                      <div class="elementor-icon-list-item   ">
                        <a target=_blank rel="" href="#" class="elementor-repeater-item-a088a2b ">
                          <div class="ekit_page_list_content">
                            <span class="elementor-icon-list-text">
                              <span class="ekit_page_list_title_title text-white">A propos</span>
                            </span>
                          </div>
                        </a>
                      </div>
                      <div class="elementor-icon-list-item   ">
                        <a target=_blank rel="" href="#" class="elementor-repeater-item-baf2a8d ">
                          <div class="ekit_page_list_content">
                            <span class="elementor-icon-list-text">
                              <span class="ekit_page_list_title_title text-white">Contacts</span>
                            </span>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!--end footer-->

  <!--ascenceur-->
  <style>
    #scrollUp {
      position: fixed;
      bottom: 10px;
      right: 40px;
      opacity: 0.6;
      z-index: 1;
    }

    #scrollUp i {
      font-size: 40px;
      z-index: 1;
      color: red;
      background-color: black;
    }
  </style>
  <!--ascenceur-->
  <div id="scrollUp">
    <a href="">
      <i class="fas fa-arrow-up"> </i>
    </a>
  </div>

  <script type="text/javascript">
    (function() {
      var c = document.body.className;
      c = c.replace(/woocommerce-no-js/, "woocommerce-js");
      document.body.className = c;
    })();
  </script>
  <style id="etn-custom-css-inline-css" type="text/css">
    .etn-event-single-content-wrap .etn-event-meta .etn-event-category span,
    .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border,
    .etn-btn.etn-btn-border,
    .attr-btn-primary.etn-btn-border,
    .etn-attendee-form .etn-btn.etn-btn-border,
    .etn-ticket-widget .etn-btn.etn-btn-border,
    .etn-settings-dashboard .button-primary.etn-btn-border,
    .etn-single-speaker-item .etn-speaker-content a:hover,
    .etn-event-style2 .etn-event-date,
    .etn-event-style3 .etn-event-content .etn-title a:hover,
    .etn-event-item:hover .etn-title a {
      color: #5d78ff;
    }

    .etn-event-item .etn-event-category span,
    .etn-btn,
    .attr-btn-primary,
    .etn-attendee-form .etn-btn,
    .etn-ticket-widget .etn-btn,
    .schedule-list-1 .schedule-header,
    .speaker-style4 .etn-speaker-content .etn-title a,
    .etn-speaker-details3 .speaker-title-info,
    .etn-event-slider .swiper-pagination-bullet,
    .etn-speaker-slider .swiper-pagination-bullet,
    .etn-event-slider .swiper-button-next,
    .etn-event-slider .swiper-button-prev,
    .etn-speaker-slider .swiper-button-next,
    .etn-speaker-slider .swiper-button-prev,
    .etn-single-speaker-item .etn-speaker-thumb .etn-speakers-social a,
    .etn-event-header .etn-event-countdown-wrap .etn-count-item,
    .schedule-tab-1 .etn-nav li a.etn-active,
    .etn-settings-dashboard .button-primary {
      background-color: #5d78ff;
    }

    .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border,
    .etn-btn.etn-btn-border,
    .attr-btn-primary.etn-btn-border,
    .etn-attendee-form .etn-btn.etn-btn-border,
    .etn-ticket-widget .etn-btn.etn-btn-border,
    .etn-settings-dashboard .button-primary.etn-btn-border {
      border-color: #5d78ff;
    }

    .schedule-tab-wrapper .etn-nav li a.etn-active {
      border-bottom-color: #5d78ff;
    }

    .schedule-tab-wrapper .etn-nav li a:after,
    .schedule-tab-1 .etn-nav li a.etn-active:after {
      border-color: #5d78ff transparent transparent transparent;
    }


    .etn-btn:hover,
    .attr-btn-primary:hover,
    .etn-attendee-form .etn-btn:hover,
    .etn-ticket-widget .etn-btn:hover,
    .speaker-style4 .etn-speaker-content p,
    .etn-single-speaker-item .etn-speaker-thumb .etn-speakers-social a:hover,
    .etn-settings-dashboard .button-primary:hover {
      background-color: ;
    }
  </style>




  <script type="text/javascript" src="../wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70" id="jquery-blockui-js"></script>
  <script type="text/javascript" id="wc-add-to-cart-js-extra">
    /* <![CDATA[ */
    var wc_add_to_cart_params = {
      ajax_url: "\/wp\/courselog\/wp-admin\/admin-ajax.php",
      wc_ajax_url: "\/wp\/courselog\/?wc-ajax=%%endpoint%%",
      i18n_view_cart: "View cart",
      cart_url: "https:\/\/demo.themewinter.com\/wp\/courselog\/cart\/",
      is_cart: "",
      cart_redirect_after_add: "no",
    };
    /* ]]> */
  </script>
  <script type="text/javascript" src="../wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.minbb49.js?ver=5.2.2" id="wc-add-to-cart-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min6b25.js?ver=2.1.4" id="js-cookie-js"></script>
  <script type="text/javascript" id="woocommerce-js-extra">
    /* <![CDATA[ */
    var woocommerce_params = {
      ajax_url: "\/wp\/courselog\/wp-admin\/admin-ajax.php",
      wc_ajax_url: "\/wp\/courselog\/?wc-ajax=%%endpoint%%",
    };
    /* ]]> */
  </script>
  <script type="text/javascript" src="../wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.minbb49.js?ver=5.2.2" id="woocommerce-js"></script>
  <script type="text/javascript" id="wc-cart-fragments-js-extra">
    /* <![CDATA[ */
    var wc_cart_fragments_params = {
      ajax_url: "\/wp\/courselog\/wp-admin\/admin-ajax.php",
      wc_ajax_url: "\/wp\/courselog\/?wc-ajax=%%endpoint%%",
      cart_hash_key: "wc_cart_hash_6915161f49948399f91c6d7efb168b53",
      fragment_name: "wc_fragments_6915161f49948399f91c6d7efb168b53",
      request_timeout: "5000",
    };
    /* ]]> */
  </script>
  <script type="text/javascript" src="../wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.minbb49.js?ver=5.2.2" id="wc-cart-fragments-js"></script>
  <script type="text/javascript" id="rocket-browser-checker-js-after">
    "use strict";
    var _createClass = (function() {
      function defineProperties(target, props) {
        for (var i = 0; i < props.length; i++) {
          var descriptor = props[i];
          (descriptor.enumerable = descriptor.enumerable || !1),
          (descriptor.configurable = !0),
          "value" in descriptor && (descriptor.writable = !0),
            Object.defineProperty(target, descriptor.key, descriptor);
        }
      }
      return function(Constructor, protoProps, staticProps) {
        return (
          protoProps && defineProperties(Constructor.prototype, protoProps),
          staticProps && defineProperties(Constructor, staticProps),
          Constructor
        );
      };
    })();

    function _classCallCheck(instance, Constructor) {
      if (!(instance instanceof Constructor))
        throw new TypeError("Cannot call a class as a function");
    }
    var RocketBrowserCompatibilityChecker = (function() {
      function RocketBrowserCompatibilityChecker(options) {
        _classCallCheck(this, RocketBrowserCompatibilityChecker),
          (this.passiveSupported = !1),
          this._checkPassiveOption(this),
          (this.options = !!this.passiveSupported && options);
      }
      return (
        _createClass(RocketBrowserCompatibilityChecker, [{
            key: "_checkPassiveOption",
            value: function(self) {
              try {
                var options = {
                  get passive() {
                    return !(self.passiveSupported = !0);
                  },
                };
                window.addEventListener("test", null, options),
                  window.removeEventListener("test", null, options);
              } catch (err) {
                self.passiveSupported = !1;
              }
            },
          },
          {
            key: "initRequestIdleCallback",
            value: function() {
              !1 in window &&
                (window.requestIdleCallback = function(cb) {
                  var start = Date.now();
                  return setTimeout(function() {
                    cb({
                      didTimeout: !1,
                      timeRemaining: function() {
                        return Math.max(0, 50 - (Date.now() - start));
                      },
                    });
                  }, 1);
                }),
                !1 in window &&
                (window.cancelIdleCallback = function(id) {
                  return clearTimeout(id);
                });
            },
          },
          {
            key: "isDataSaverModeOn",
            value: function() {
              return (
                "connection" in navigator &&
                !0 === navigator.connection.saveData
              );
            },
          },
          {
            key: "supportsLinkPrefetch",
            value: function() {
              var elem = document.createElement("link");
              return (
                elem.relList &&
                elem.relList.supports &&
                elem.relList.supports("prefetch") &&
                window.IntersectionObserver &&
                "isIntersecting" in IntersectionObserverEntry.prototype
              );
            },
          },
          {
            key: "isSlowConnection",
            value: function() {
              return (
                "connection" in navigator &&
                "effectiveType" in navigator.connection &&
                ("2g" === navigator.connection.effectiveType ||
                  "slow-2g" === navigator.connection.effectiveType)
              );
            },
          },
        ]),
        RocketBrowserCompatibilityChecker
      );
    })();
  </script>
  <script type="text/javascript" id="rocket-delay-js-js-after">
    (function() {
      "use strict";
      var e = (function() {
        function n(e, t) {
          for (var r = 0; r < t.length; r++) {
            var n = t[r];
            (n.enumerable = n.enumerable || !1),
            (n.configurable = !0),
            "value" in n && (n.writable = !0),
              Object.defineProperty(e, n.key, n);
          }
        }
        return function(e, t, r) {
          return t && n(e.prototype, t), r && n(e, r), e;
        };
      })();

      function n(e, t) {
        if (!(e instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      var t = (function() {
        function r(e, t) {
          n(this, r),
            (this.attrName = "data-rocketlazyloadscript"),
            (this.browser = t),
            (this.options = this.browser.options),
            (this.triggerEvents = e),
            (this.userEventListener = this.triggerListener.bind(this));
        }
        return (
          e(
            r,
            [{
                key: "init",
                value: function() {
                  this._addEventListener(this);
                },
              },
              {
                key: "reset",
                value: function() {
                  this._removeEventListener(this);
                },
              },
              {
                key: "_addEventListener",
                value: function(t) {
                  this.triggerEvents.forEach(function(e) {
                    return window.addEventListener(
                      e,
                      t.userEventListener,
                      t.options
                    );
                  });
                },
              },
              {
                key: "_removeEventListener",
                value: function(t) {
                  this.triggerEvents.forEach(function(e) {
                    return window.removeEventListener(
                      e,
                      t.userEventListener,
                      t.options
                    );
                  });
                },
              },
              {
                key: "_loadScriptSrc",
                value: function() {
                  var r = this,
                    e = document.querySelectorAll(
                      "script[" + this.attrName + "]"
                    );
                  0 !== e.length &&
                    Array.prototype.slice.call(e).forEach(function(e) {
                      var t = e.getAttribute(r.attrName);
                      e.setAttribute("src", t), e.removeAttribute(r.attrName);
                    }),
                    this.reset();
                },
              },
              {
                key: "triggerListener",
                value: function() {
                  this._loadScriptSrc(), this._removeEventListener(this);
                },
              },
            ],
            [{
              key: "run",
              value: function() {
                RocketBrowserCompatibilityChecker &&
                  new r(
                    [
                      "keydown",
                      "mouseover",
                      "touchmove",
                      "touchstart",
                      "wheel",
                    ],
                    new RocketBrowserCompatibilityChecker({
                      passive: !0
                    })
                  ).init();
              },
            }, ]
          ),
          r
        );
      })();
      t.run();
    })();
  </script>
  <script type="text/javascript" id="rocket-preload-links-js-extra">
    /* <![CDATA[ */
    var RocketPreloadLinksConfig = {
      excludeUris: "\/wp\/courselog(\/(.+\/)?feed\/?.+\/?|\/(?:.+\/)?embed\/|\/cart\/|\/my-account\/|\/wc-api\/v(.*)|(\/[^\/]+)?\/(index\\.php\/)?wp\\-json(\/.*|$))|\/wp-admin\/|\/logout\/|\/wp-login.php",
      usesTrailingSlash: "1",
      imageExt: "jpg|jpeg|gif|png|tiff|bmp|webp|avif",
      fileExt: "jpg|jpeg|gif|png|tiff|bmp|webp|avif|php|pdf|html|htm",
      siteUrl: "https:\/\/demo.themewinter.com\/wp\/courselog",
      onHoverDelay: "100",
      rateThrottle: "3",
    };
    /* ]]> */
  </script>
  <script type="text/javascript" id="rocket-preload-links-js-after">
    (function() {
      "use strict";
      var r =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function(e) {
          return typeof e;
        } :
        function(e) {
          return e &&
            "function" == typeof Symbol &&
            e.constructor === Symbol &&
            e !== Symbol.prototype ?
            "symbol" :
            typeof e;
        },
        e = (function() {
          function i(e, t) {
            for (var n = 0; n < t.length; n++) {
              var i = t[n];
              (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              "value" in i && (i.writable = !0),
                Object.defineProperty(e, i.key, i);
            }
          }
          return function(e, t, n) {
            return t && i(e.prototype, t), n && i(e, n), e;
          };
        })();

      function i(e, t) {
        if (!(e instanceof t))
          throw new TypeError("Cannot call a class as a function");
      }
      var t = (function() {
        function n(e, t) {
          i(this, n),
            (this.browser = e),
            (this.config = t),
            (this.options = this.browser.options),
            (this.prefetched = new Set()),
            (this.eventTime = null),
            (this.threshold = 1111),
            (this.numOnHover = 0);
        }
        return (
          e(
            n,
            [{
                key: "init",
                value: function() {
                  !this.browser.supportsLinkPrefetch() ||
                    this.browser.isDataSaverModeOn() ||
                    this.browser.isSlowConnection() ||
                    ((this.regex = {
                        excludeUris: RegExp(this.config.excludeUris, "i"),
                        images: RegExp(".(" + this.config.imageExt + ")$", "i"),
                        fileExt: RegExp(".(" + this.config.fileExt + ")$", "i"),
                      }),
                      this._initListeners(this));
                },
              },
              {
                key: "_initListeners",
                value: function(e) {
                  -1 < this.config.onHoverDelay &&
                    document.addEventListener(
                      "mouseover",
                      e.listener.bind(e),
                      e.listenerOptions
                    ),
                    document.addEventListener(
                      "mousedown",
                      e.listener.bind(e),
                      e.listenerOptions
                    ),
                    document.addEventListener(
                      "touchstart",
                      e.listener.bind(e),
                      e.listenerOptions
                    );
                },
              },
              {
                key: "listener",
                value: function(e) {
                  var t = e.target.closest("a"),
                    n = this._prepareUrl(t);
                  if (null !== n)
                    switch (e.type) {
                      case "mousedown":
                      case "touchstart":
                        this._addPrefetchLink(n);
                        break;
                      case "mouseover":
                        this._earlyPrefetch(t, n, "mouseout");
                    }
                },
              },
              {
                key: "_earlyPrefetch",
                value: function(t, e, n) {
                  var i = this,
                    r = setTimeout(function() {
                      if (((r = null), 0 === i.numOnHover))
                        setTimeout(function() {
                          return (i.numOnHover = 0);
                        }, 1e3);
                      else if (i.numOnHover > i.config.rateThrottle) return;
                      i.numOnHover++, i._addPrefetchLink(e);
                    }, this.config.onHoverDelay);
                  t.addEventListener(
                    n,
                    function e() {
                      t.removeEventListener(n, e, {
                          passive: !0
                        }),
                        null !== r && (clearTimeout(r), (r = null));
                    }, {
                      passive: !0
                    }
                  );
                },
              },
              {
                key: "_addPrefetchLink",
                value: function(i) {
                  return (
                    this.prefetched.add(i.href),
                    new Promise(function(e, t) {
                      var n = document.createElement("link");
                      (n.rel = "prefetch"),
                      (n.href = i.href),
                      (n.onload = e),
                      (n.onerror = t),
                      document.head.appendChild(n);
                    }).catch(function() {})
                  );
                },
              },
              {
                key: "_prepareUrl",
                value: function(e) {
                  if (
                    null === e ||
                    "object" !== (void 0 === e ? "undefined" : r(e)) ||
                    !1 in e ||
                    -1 === ["http:", "https:"].indexOf(e.protocol)
                  )
                    return null;
                  var t = e.href.substring(0, this.config.siteUrl.length),
                    n = this._getPathname(e.href, t),
                    i = {
                      original: e.href,
                      protocol: e.protocol,
                      origin: t,
                      pathname: n,
                      href: t + n,
                    };
                  return this._isLinkOk(i) ? i : null;
                },
              },
              {
                key: "_getPathname",
                value: function(e, t) {
                  var n = t ? e.substring(this.config.siteUrl.length) : e;
                  return (
                    n.startsWith("https://demo.themewinter.com/") ||
                    (n = "/" + n),
                    this._shouldAddTrailingSlash(n) ? n + "/" : n
                  );
                },
              },
              {
                key: "_shouldAddTrailingSlash",
                value: function(e) {
                  return (
                    this.config.usesTrailingSlash &&
                    !e.endsWith("https://demo.themewinter.com/") &&
                    !this.regex.fileExt.test(e)
                  );
                },
              },
              {
                key: "_isLinkOk",
                value: function(e) {
                  return (
                    null !== e &&
                    "object" === (void 0 === e ? "undefined" : r(e)) &&
                    !this.prefetched.has(e.href) &&
                    e.origin === this.config.siteUrl &&
                    -1 === e.href.indexOf("?") &&
                    -1 === e.href.indexOf("#") &&
                    !this.regex.excludeUris.test(e.href) &&
                    !this.regex.images.test(e.href)
                  );
                },
              },
            ],
            [{
              key: "run",
              value: function() {
                "undefined" != typeof RocketPreloadLinksConfig &&
                  new n(
                    new RocketBrowserCompatibilityChecker({
                      capture: !0,
                      passive: !0,
                    }),
                    RocketPreloadLinksConfig
                  ).init();
              },
            }, ]
          ),
          n
        );
      })();
      t.run();
    })();
  </script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/metform/public/assets/js/htm32f0.js?ver=1619375310" id="htm-js"></script>
  <script type="text/javascript" src="../wp-includes/js/dist/vendor/lodash.minf492.js?ver=4.17.19" id="lodash-js"></script>
  <script type="text/javascript" id="lodash-js-after">
    window.lodash = _.noConflict();
  </script>
  <script type="text/javascript" src="../wp-includes/js/dist/vendor/wp-polyfill.min89b1.js?ver=7.4.4" id="wp-polyfill-js"></script>
  <script type="text/javascript" id="wp-polyfill-js-after">
    "fetch" in window ||
      document.write(
        '<script src="../wp-includes/js/dist/vendor/wp-polyfill-fetch.min6e0e.js?ver=3.0.0"></scr' +
        "ipt>"
      );
    document.contains ||
      document.write(
        '<script src="../wp-includes/js/dist/vendor/wp-polyfill-node-contains.min2e00.js?ver=3.42.0"></scr' +
        "ipt>"
      );
    window.DOMRect ||
      document.write(
        '<script src="../wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min2e00.js?ver=3.42.0"></scr' +
        "ipt>"
      );
    (window.URL && window.URL.prototype && window.URLSearchParams) ||
    document.write(
      '<script src="../wp-includes/js/dist/vendor/wp-polyfill-url.min5aed.js?ver=3.6.4"></scr' +
      "ipt>"
    );
    (window.FormData && window.FormData.prototype.keys) ||
    document.write(
      '<script src="../wp-includes/js/dist/vendor/wp-polyfill-formdata.mine9bd.js?ver=3.0.12"></scr' +
      "ipt>"
    );
    (Element.prototype.matches && Element.prototype.closest) ||
    document.write(
      '<script src="../wp-includes/js/dist/vendor/wp-polyfill-element-closest.min4c56.js?ver=2.0.2"></scr' +
      "ipt>"
    );
    "objectFit" in document.documentElement.style ||
      document.write(
        '<script src="../wp-includes/js/dist/vendor/wp-polyfill-object-fit.min531b.js?ver=2.3.4"></scr' +
        "ipt>"
      );
  </script>
  <script type="text/javascript" src="../wp-includes/js/dist/vendor/react.mincd00.js?ver=16.13.1" id="react-js"></script>
  <script type="text/javascript" src="../wp-includes/js/dist/vendor/react-dom.mincd00.js?ver=16.13.1" id="react-dom-js"></script>
  <script type="text/javascript" src="../wp-includes/js/dist/escape-html.minff4e.js?ver=318abfb97a58ba13225ff74699ad73d4" id="wp-escape-html-js"></script>
  <script type="text/javascript" src="../wp-includes/js/dist/element.mina1b5.js?ver=ade78933fc78fc95c1988dda7ccc9fb3" id="wp-element-js"></script>
  <script type="text/javascript" id="metform-app-js-extra">
    /* <![CDATA[ */
    var mf = {
      postType: "page",
      restURI: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-json\/metform\/v1\/forms\/views\/",
    };
    /* ]]> */
  </script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/metform/public/assets/js/app32f0.js?ver=1619375310" id="metform-app-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-event-solution/assets/js/event-manager-public32f0.js?ver=1619375310" id="etn-public-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script32f0.js?ver=1619375310" id="elementskit-framework-js-frontend-js"></script>
  <script type="text/javascript" id="elementskit-framework-js-frontend-js-after">
    var elementskit = {
      resturl: "https://demo.themewinter.com/wp/courselog/wp-json/elementskit/v1/",
    };
  </script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts32f0.js?ver=1619375310" id="ekit-widget-scripts-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/courselog-essential/modules/parallax/assets/js/TweenMax.min7fb9.js?ver=1.5.9" id="tweenmax-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/jquery.easing.1.332f0.js?ver=1619375310" id="jquery-easing-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/courselog-essential/modules/parallax/assets/js/tilt.jquery.min7fb9.js?ver=1.5.9" id="tilt-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/anime32f0.js?ver=1619375310" id="animejs-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/magician32f0.js?ver=1619375310" id="magicianjs-js"></script>
  <script type="text/javascript" src="../wp-content/themes/courselog/assets/js/bootstrap.minefb0.js?ver=%201.2.9" id="bootstrap-js"></script>
  <script type="text/javascript" src="../wp-content/themes/courselog/assets/js/jquery.magnific-popup.minefb0.js?ver=%201.2.9" id="magnific-popup-js"></script>
  <script type="text/javascript" src="../wp-content/themes/courselog/assets/js/jquery.filterizr.minefb0.js?ver=%201.2.9" id="jquery-filterizr-js"></script>
  <script type="text/javascript" src="../wp-content/themes/courselog/assets/js/owl.carousel.minefb0.js?ver=%201.2.9" id="owl-carousel-js"></script>
  <script type="text/javascript" src="../wp-content/themes/courselog/assets/js/jquery.countdown.minefb0.js?ver=%201.2.9" id="jquery-countdown-js"></script>
  <script type="text/javascript" id="courselog-script-js-extra">
    /* <![CDATA[ */
    var courselog_obj = {
      ajax_url: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-admin\/admin-ajax.php",
      nonce: "fda00f0198",
      security: "767db86dd5",
      blog_sticky_sidebar: "no",
      logged_in: "",
      message_login: "You are not logged in",
    };
    /* ]]> */
  </script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/themes/courselog/assets/js/script32f0.js?ver=1619375310" id="courselog-script-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/learnpress/assets/js/frontend/course.min4e1b.js?ver=3.2.8.8" id="course-js"></script>
  <script type="text/javascript" src="../wp-includes/js/wp-embed.mina78f.js?ver=5.7.1" id="wp-embed-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementskit-lite/widgets/init/assets/js/goodshare.mina78f.js?ver=5.7.1" id="goodshare-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/js/webpack.runtime.minaeb9.js?ver=3.1.4" id="elementor-webpack-runtime-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/js/frontend-modules.minaeb9.js?ver=3.1.4" id="elementor-frontend-modules-js"></script>
  <script type="text/javascript" src="../wp-includes/js/jquery/ui/core.min35d0.js?ver=1.12.1" id="jquery-ui-core-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/lib/dialog/dialog.mina288.js?ver=4.8.1" id="elementor-dialog-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2" id="elementor-waypoints-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/lib/share-link/share-link.minaeb9.js?ver=3.1.4" id="share-link-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/lib/swiper/swiper.min48f5.js?ver=5.3.6" id="swiper-js"></script>
  <script type="text/javascript" id="elementor-frontend-js-before">
    var elementorFrontendConfig = {
      environmentMode: {
        edit: false,
        wpPreview: false,
        isScriptDebug: false,
        isImprovedAssetsLoading: false,
      },
      i18n: {
        shareOnFacebook: "Share on Facebook",
        shareOnTwitter: "Share on Twitter",
        pinIt: "Pin it",
        download: "Download",
        downloadImage: "Download image",
        fullscreen: "Fullscreen",
        zoom: "Zoom",
        share: "Share",
        playVideo: "Play Video",
        previous: "Previous",
        next: "Next",
        close: "Close",
      },
      is_rtl: false,
      breakpoints: {
        xs: 0,
        sm: 480,
        md: 768,
        lg: 1025,
        xl: 1440,
        xxl: 1600
      },
      version: "3.1.4",
      is_static: false,
      experimentalFeatures: [],
      urls: {
        assets: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-content\/plugins\/elementor\/assets\/",
      },
      settings: {
        page: [],
        editorPreferences: []
      },
      kit: {
        global_image_lightbox: "yes",
        lightbox_enable_counter: "yes",
        lightbox_enable_fullscreen: "yes",
        lightbox_enable_zoom: "yes",
        lightbox_enable_share: "yes",
        lightbox_title_src: "title",
        lightbox_description_src: "description",
      },
      post: {
        id: 6440,
        title: "Contact%20%E2%80%93%20Courselog",
        excerpt: "",
        featuredImage: false,
      },
    };
  </script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/js/frontend.minaeb9.js?ver=3.1.4" id="elementor-frontend-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-event-solution/assets/js/elementor32f0.js?ver=1619375310" id="etn-elementor-inputs-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/themes/courselog/assets/js/elementor32f0.js?ver=1619375310" id="courselog-main-elementor-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/themes/courselog/assets/js/widget-scripts-pro32f0.js?ver=1619375310" id="courselog-widget-scripts-pro-js"></script>
  <script type="text/javascript" src="https://unpkg.com/popper.js@1?ver=2.2.2" id="ekit-popover-js"></script>
  <script type="text/javascript" src="https://unpkg.com/tippy.js@5?ver=2.2.2" id="ekit-typpy-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementskit-lite/widgets/init/assets/js/slick.min605a.js?ver=2.2.2" id="ekit-slick-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor32f0.js?ver=1619375310" id="elementskit-elementor-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/sticky-content/assets/js/jquery.sticky32f0.js?ver=1619375310" id="elementskit-sticky-content-script-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/sticky-content/assets/js/main32f0.js?ver=1619375310" id="elementskit-sticky-content-script-core-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/widget-init32f0.js?ver=1619375310" id="elementskit-parallax-widget-init-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/section-init32f0.js?ver=1619375310" id="elementskit-parallax-section-init-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.minaeb9.js?ver=3.1.4" id="preloaded-elements-handlers-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/metform/controls/assets/js/form-picker-editor32f0.js?ver=1619375310" id="metform-js-formpicker-control-editor-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/modules/controls/assets/js/widgetarea-editor32f0.js?ver=1619375310" id="elementskit-js-widgetarea-control-editor-js"></script>
  <script>
    window.lazyLoadOptions = {
      elements_selector: "img[data-lazy-src],.rocket-lazyload,iframe[data-lazy-src]",
      data_src: "lazy-src",
      data_srcset: "lazy-srcset",
      data_sizes: "lazy-sizes",
      class_loading: "lazyloading",
      class_loaded: "lazyloaded",
      threshold: 300,
      callback_loaded: function(element) {
        if (
          element.tagName === "IFRAME" &&
          element.dataset.rocketLazyload == "fitvidscompatible"
        ) {
          if (element.classList.contains("lazyloaded")) {
            if (typeof window.jQuery != "undefined") {
              if (jQuery.fn.fitVids) {
                jQuery(element).parent().fitVids();
              }
            }
          }
        }
      },
    };
    window.addEventListener(
      "LazyLoad::Initialized",
      function(e) {
        var lazyLoadInstance = e.detail.instance;
        if (window.MutationObserver) {
          var observer = new MutationObserver(function(mutations) {
            var image_count = 0;
            var iframe_count = 0;
            var rocketlazy_count = 0;
            mutations.forEach(function(mutation) {
              for (i = 0; i < mutation.addedNodes.length; i++) {
                if (
                  typeof mutation.addedNodes[i].getElementsByTagName !==
                  "function"
                ) {
                  continue;
                }
                if (
                  typeof mutation.addedNodes[i].getElementsByClassName !==
                  "function"
                ) {
                  continue;
                }
                images = mutation.addedNodes[i].getElementsByTagName("img");
                is_image = mutation.addedNodes[i].tagName == "IMG";
                iframes =
                  mutation.addedNodes[i].getElementsByTagName("iframe");
                is_iframe = mutation.addedNodes[i].tagName == "IFRAME";
                rocket_lazy =
                  mutation.addedNodes[i].getElementsByClassName(
                    "rocket-lazyload"
                  );
                image_count += images.length;
                iframe_count += iframes.length;
                rocketlazy_count += rocket_lazy.length;
                if (is_image) {
                  image_count += 1;
                }
                if (is_iframe) {
                  iframe_count += 1;
                }
              }
            });
            if (image_count > 0 || iframe_count > 0 || rocketlazy_count > 0) {
              lazyLoadInstance.update();
            }
          });
          var b = document.getElementsByTagName("body")[0];
          var config = {
            childList: !0,
            subtree: !0
          };
          observer.observe(b, config);
        }
      },
      !1
    );
  </script>
  <script data-no-minify="1" async src="../wp-content/plugins/wp-rocket/assets/js/lazyload/16.1/lazyload.min.js"></script>
  <script>
    function lazyLoadThumb(e) {
      var t =
        '<img loading="lazy" data-lazy-src="https://i.ytimg.com/vi/ID/hqdefault.jpg" alt="" width="480" height="360"><noscript><img src="https://i.ytimg.com/vi/ID/hqdefault.jpg" alt="" width="480" height="360"></noscript>',
        a = '<div class="play"></div>';
      return t.replace("ID", e) + a;
    }

    function lazyLoadYoutubeIframe() {
      var e = document.createElement("iframe"),
        t = "ID?autoplay=1";
      t += 0 === this.dataset.query.length ? "" : "&" + this.dataset.query;
      e.setAttribute("src", t.replace("ID", this.dataset.src)),
        e.setAttribute("frameborder", "0"),
        e.setAttribute("allowfullscreen", "1"),
        e.setAttribute(
          "allow",
          "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
        ),
        this.parentNode.replaceChild(e, this);
    }
    document.addEventListener("DOMContentLoaded", function() {
      var e,
        t,
        a = document.getElementsByClassName("rll-youtube-player");
      for (t = 0; t < a.length; t++)
        (e = document.createElement("div")),
        e.setAttribute("data-id", a[t].dataset.id),
        e.setAttribute("data-query", a[t].dataset.query),
        e.setAttribute("data-src", a[t].dataset.src),
        (e.innerHTML = lazyLoadThumb(a[t].dataset.id)),
        (e.onclick = lazyLoadYoutubeIframe),
        a[t].appendChild(e);
    });
  </script>

<script type="text/javascript" src="../assets/js/bootstrap.min.js">

  </body>

  </html>