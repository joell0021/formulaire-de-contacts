﻿<!DOCTYPE html>
<html lang="fr-FR" class="" data-skin="light">
<!-- Mirrored from demo.themewinter.com/wp/courselog/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 28 Apr 2021 16:52:39 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>
    <?php
    echo    $title;
    ?>
  </title>
  <link rel="icon" href="../assets/img/gsa.png">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Manrope%3Aregular%2C700%2C400%2C900%7CRoboto%3A300%2C300i%2C400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CRubik%3A400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CManrope%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=swap" />
  <link rel="stylesheet" href="../wp-content/cache/min/1/70d4e595dbfc9fea9476a09ce9048a92.css" media="all" data-minify="1" />
  <meta name="robots" content="max-image-preview:large" />
  <link rel="dns-prefetch" href="http://fonts.googleapis.com/" />
  <link href="https://fonts.gstatic.com/" crossorigin rel="preconnect" />
  <link rel="alternate" type="application/rss+xml" title="CHP GSA; Feed" />
 <link rel="stylesheet" href="../assets/css/bootstrap.css">
 <link rel="stylesheet" href="../assets/css/mdb.min.css">
  
  <!--/*site style*/-->
  <style>
    p,
    p>i {
      color: #37474f;
      text-align: justify;
    }

    .titre {
      color: #2878EB;
      font-size: 60px
    }

    .titre2 {
      color: #f14d5d;
    }

    .titre3 {
      color: #2878EB;
    }
  </style>

  <style type="text/css">
    img.wp-smiley,
    img.emoji {
      display: inline !important;
      border: none !important;
      box-shadow: none !important;
      height: 1em !important;
      width: 1em !important;
      margin: 0 0.07em !important;
      vertical-align: -0.1em !important;
      background: none !important;
      padding: 0 !important;
    }
  </style>

  <link rel="stylesheet" id="woocommerce-smallscreen-css" href="../wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreenbb49.css?ver=5.2.2" type="text/css" media="only screen and (max-width: 768px)" />

  <style id="woocommerce-inline-inline-css" type="text/css">
    .woocommerce form .form-row .required {
      visibility: visible;
    }
  </style>

  <style id="courselog-style-inline-css" type="text/css">
    body {
      font-family: "Manrope";
      font-size: 16px;
    }

    h1 {
      font-family: "Manrope";
      font-weight: 700;
    }

    h2 {
      font-family: "Manrope";
      font-weight: 700;
    }

    h3 {
      font-family: "Manrope";
      font-weight: 700;
    }

    h4 {
      font-family: "Manrope";
      font-weight: 700;
    }

    .entry-header .entry-title a:hover,
    .sidebar ul li a:hover {
      color: #f14d5d;
    }

    .entry-header .entry-title a {
      color: #120f2d;
    }

    body {
      background-color: #fff;
    }

    .single-intro-text .count-number,
    .sticky.post .meta-featured-post,
    .latest-blog .post .post-meta span:before,
    .sidebar .widget .widget-title:before,
    .pagination li.active a:hover,
    .tag-lists a:hover,
    .tagcloud a:hover,
    .BackTo,
    .ticket-btn.btn:hover,
    .btn-primary,
    .BackTo,
    .woocommerce ul.products li.product .button,
    .woocommerce ul.products li.product .added_to_cart,
    .woocommerce nav.woocommerce-pagination ul li a:focus,
    .woocommerce nav.woocommerce-pagination ul li a:hover,
    .woocommerce nav.woocommerce-pagination ul li span.current,
    .woocommerce #respond input#submit.alt,
    .woocommerce a.button.alt,
    .woocommerce button.button.alt,
    .woocommerce input.button.alt,
    .sponsor-web-link a:hover i,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
    .woocommerce span.onsale,
    #preloader,
    .header .navbar-container .navbar-light .main-menu>li>a:before,
    .tab-course-category ul li:before,
    .co-single-instructor .co-instructors-socials li a:hover,
    .course-entry-content .curriculum-content .curricolumn-list li a .curricolumn-preview,
    .course-single-wrap .single-course .course-price-item span,
    .single-course .course-category a:before,
    .course-entry-content ul.nav li a:before,
    .courselog-search-course-form .search-course-button,
    .main-slider-style3 .slider-content .sub-title::before,
    .main-menu .elementskit-navbar-nav>li>a::after,
    .btn-primary,
    .learnpress-page .lp-button,
    .place-order-action .lp-button,
    #learn-press-content-item #course-item-content-header .toggle-content-item,
    #learn-press-content-item #course-item-content-header .lp-button:hover,
    #learn-press-course-curriculum.course-curriculum ul.curriculum-sections .section-content .course-item .course-item-meta span,
    .course-entry-content .public-xs-review-box .xs-save-button button,
    .header-login-user a sup,
    .cartbtn a sup,
    .user-dashboard .order-recover .button-recover-order,
    .single_add_to_cart_button,
    .tutor-btn,
    .tutor-button,
    a.tutor-btn,
    a.tutor-button,
    .courselog-events .entry-header .event-time:before,
    .courselog-tab .courselog-navs-tab li a .title-content .content::before,
    .learndash-wrapper .ld-primary-background,
    .learndash-wrapper .ld-tabs .ld-tabs-navigation .ld-tab.ld-active:after,
    .learndash-wrapper .ld-primary-background,
    .learndash-wrapper .ld-tabs .ld-tabs-navigation .ld-tab.ld-active:after,
    .courselog-learndash-course .ld-single-course .ld-course-footer .ld-course-price,
    .ld-related-course .ld-single-course .ld-course-footer .ld-course-price,
    .user-dashboard #learn-press-profile-nav .learn-press-tabs.tabs li.active>a,
    .user-dashboard #learn-press-profile-nav .learn-press-tabs.tabs li:hover>a,
    .woocommerce ul.products li.product .added_to_cart:hover,
    .woocommerce #respond input#submit.alt:hover,
    .woocommerce a.button.alt:hover,
    .woocommerce button.button.alt:hover,
    .woocommerce input.button.alt:hover,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-handle {
      background: #f14d5d;
    }

    .btn-primary,
    .btn-primary,
    .learnpress-page .lp-button,
    .place-order-action .lp-button,
    .courselog-learndash-course .ld-single-course .ld-course-footer .ld-course-read-more:hover a,
    .ld-related-course .ld-single-course .ld-course-footer .ld-course-read-more:hover a,
    .single_add_to_cart_button,
    .tutor-btn,
    .tutor-button,
    a.tutor-btn,
    a.tutor-button,
    .owl-carousel .owl-dots .owl-dot.active {
      border-color: #f14d5d;
    }

    .user-dashboard .lp-profile-content .lp-tab-sections li.active span {
      border-bottom-color: #f14d5d;
    }

    #learn-press-course-curriculum.course-curriculum ul.curriculum-sections .section-content .course-item.current a:hover {
      color: #fff;
    }

    .copyright .footer-social li a i:hover,
    .copyright .copyright-text a,
    .header .navbar-container .navbar-light .main-menu li a:hover,
    .header .navbar-container .navbar-light .main-menu li.active>a,
    .post .entry-header .entry-title a:hover,
    a:hover,
    .ts-course-category .single-course-category .course-category-title a:hover,
    .courselog-events .entry-header .entry-title a:hover,
    .woocommerce ul.products li.product .price,
    .footer-widget ul li a:hover,
    .ts-footer .footer-menu li a:hover,
    .courselog-course-latest h3.post-title a:hover,
    .courselog-course-latest p,
    .courselog-learndash-course .ld-single-course .ld-course-conent:hover .ts-title a,
    .ld-related-course .ld-single-course .ld-course-conent:hover .ts-title a,
    .courselog-learndash-course .ld-single-course .ld-course-footer .ld-course-read-more:hover a,
    .ld-related-course .ld-single-course .ld-course-footer .ld-course-read-more:hover a,
    .course-entry-content .curriculum-content .curricolumn-list li a i,
    .course-entry-content .curriculum-content .curricolumn-list li a:hover,
    .co-single-instructor .co-instructor-title a:hover,
    .course-entry-content .curriculum-content .curriculmn-title:after,
    .post-navigation span:hover,
    .post-navigation h3:hover,
    .comments-list .comment-reply-link:hover,
    .tutor-custom-list-style li:before,
    .ld-tabs .ld-tabs-navigation .ld-tab.ld-active span,
    .courselog-tab .courselog-navs-tab li a .title-content .title-icon,
    .user-dashboard .lp-profile-content table td a:hover,
    .user-dashboard .lp-profile-content table th a:hover,
    .user-dashboard .lp-profile-content .lp-list-table td a:hover,
    .user-dashboard .lp-profile-content .lp-list-table th a:hover,
    #learn-press-course-curriculum.course-curriculum ul.curriculum-sections .section-content .course-item .section-item-link:hover,
    .woocommerce ul.products li.product .woocommerce-loop-product__title:hover {
      color: #f14d5d;
    }

    /*  secondary color   */

    .single-course .course-footer .course-price-item .course-price,
    .single-course .course-footer .course-price-item .free-course,
    .btn-primary:hover,
    .btn-primary:active,
    .learn-press-form-login form button:hover,
    .learn-press-form-login form button:active,
    .learnpress-page .lp-button:hover,
    .course-single-wrap .single-course:hover .course-price-item span,
    .header--course-meta .course-price span,
    .course-entry-content .public-xs-review-box .xs-save-button button:hover,
    #learn-press-course-curriculum.course-curriculum ul.curriculum-sections .section-content .course-item.item-preview .course-item-status,
    #learn-press-course-curriculum.course-curriculum ul.curriculum-sections .section-content .course-item.current:before,
    .user-dashboard .lp-profile-content .lp-tab-sections,
    .course-entry-content ul.nav,
    .pagination li.active a,
    .pagination li:hover a,
    .pagination li:hover a:hover,
    .learnpress-page .lp-button:active,
    .place-order-action .lp-button:hover,
    .place-order-action .lp-button:active {
      background-color: #2878eb;
    }

    .archive-widgets ul li.active a {
      color: #2878eb;
    }

    .btn-primary:hover,
    .btn-primary:active,
    .learn-press-form-login form button:hover,
    .learn-press-form-login form button:active,
    .learnpress-page .lp-button:hover,
    .learnpress-page .lp-button:active,
    .place-order-action .lp-button:hover,
    .place-order-action .lp-button:active {
      border-color: #2878eb;
    }

    .ts-footer {
      background-color: #273c66;
    }

    .copyright .copyright-text {
      color: #fff;
    }
  </style>

  <style id="rocket-lazyload-inline-css" type="text/css">
    .rll-youtube-player {
      position: relative;
      padding-bottom: 56.23%;
      height: 0;
      overflow: hidden;
      max-width: 100%;
    }

    .rll-youtube-player iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 100;
      background: 0 0;
    }

    .rll-youtube-player img {
      bottom: 0;
      display: block;
      left: 0;
      margin: auto;
      max-width: 100%;
      width: 100%;
      position: absolute;
      right: 0;
      top: 0;
      border: none;
      height: auto;
      cursor: pointer;
      -webkit-transition: 0.4s all;
      -moz-transition: 0.4s all;
      transition: 0.4s all;
    }

    .rll-youtube-player img:hover {
      -webkit-filter: brightness(75%);
    }

    .rll-youtube-player .play {
      height: 72px;
      width: 72px;
      left: 50%;
      top: 50%;
      margin-left: -36px;
      margin-top: -36px;
      position: absolute;
      background: url(../wp-content/plugins/wp-rocket/assets/img/youtube.png) no-repeat;
      cursor: pointer;
    }
  </style>

  <script type="text/javascript" src="../wp-includes/js/jquery/jquery.min9d52.js?ver=3.5.1" id="jquery-core-js"></script>
  <script type="text/javascript" src="../wp-includes/js/jquery/jquery-migrate.mind617.js?ver=3.3.2" id="jquery-migrate-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/learnpress-wishlist/assets/js/wishlist32f0.js?ver=1619375310" id="lp-course-wishlist-script-js"></script>
  <script data-rocketlazyloadscript="https://demo.themewinter.com/wp/courselog/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.1.4" type="text/javascript" id="font-awesome-4-shim-js"></script>
  <script type="text/javascript" id="xs_social_custom-js-extra">
    /* <![CDATA[ */
    var rest_api_conf = {
      siteurl: "https:\/\/demo.themewinter.com\/wp\/courselog",
      nonce: "5f14c258b8",
      root: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-json\/",
    };
    /* ]]> */
  </script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-social/assets/js/social-front32f0.js?ver=1619375310" id="xs_social_custom-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-ultimate-review/assets/public/script/content-page32f0.js?ver=1619375310" id="wur_review_content_script-js"></script>
  <script data-minify="1" type="text/javascript" src="../wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/jarallax32f0.js?ver=1619375310" id="jarallax-js"></script>
  <script type="text/javascript" src="../wp-content/themes/courselog/assets/js/jquery.repeater.minefb0.js?ver=%201.2.9" id="jquery-repeater-min-js"></script>
  <script type="text/javascript" src="../wp-includes/js/underscore.min4511.js?ver=1.8.3" id="underscore-js"></script>
  <script type="text/javascript" id="utils-js-extra">
    /* <![CDATA[ */
    var userSettings = {
      url: "\/wp\/courselog\/",
      uid: "0",
      time: "1619602107",
      secure: "1",
    };
    /* ]]> */
  </script>
  <script type="text/javascript" src="../wp-includes/js/utils.mina78f.js?ver=5.7.1" id="utils-js"></script>
  <script type="text/javascript" id="lp-global-js-extra">
    /* <![CDATA[ */
    var lpGlobalSettings = {
      url: "https:\/\/demo.themewinter.com\/wp\/courselog\/contact\/",
      siteurl: "https:\/\/demo.themewinter.com\/wp\/courselog",
      ajax: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-admin\/admin-ajax.php",
      theme: "courselog",
      localize: {
        button_ok: "OK",
        button_cancel: "Cancel",
        button_yes: "Yes",
        button_no: "No",
      },
      show_popup_confirm_finish: "yes",
    };
    /* ]]> */
  </script>
  <script type="text/javascript" src="../wp-content/plugins/learnpress/assets/js/global.min4e1b.js?ver=3.2.8.8" id="lp-global-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/learnpress/assets/js/dist/utils.min4e1b.js?ver=3.2.8.8" id="lp-utils-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/learnpress/assets/src/js/vendor/watch.min4e1b.js?ver=3.2.8.8" id="watch-js"></script>
  <script type="text/javascript" src="../wp-content/plugins/learnpress/assets/js/vendor/plugins.all.min4e1b.js?ver=3.2.8.8" id="lp-plugins-all-js"></script>
  <link rel="alternate" type="application/json" href="../wp-json/wp/v2/pages/6440.json" />
  <link rel="EditURI" type="application/rsd+xml" title="RSD" href="../xmlrpc0db0.php?rsd" />
  <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../wp-includes/wlwmanifest.xml" />
  <meta name="generator" content="WordPress 5.7.1" />
  <meta name="generator" content="WooCommerce 5.2.2" />
  <link rel="canonical" href="index.html" />
  <link rel="shortlink" href="../index4eb5.html?p=6440" />
  <link rel="alternate" type="application/json+oembed" href="../wp-json/oembed/1.0/embed1781.json?url=https%3A%2F%2Fdemo.themewinter.com%2Fwp%2Fcourselog%2Fcontact%2F" />
  <link rel="alternate" type="text/xml+oembed" href="../wp-json/oembed/1.0/embedbfdf?url=https%3A%2F%2Fdemo.themewinter.com%2Fwp%2Fcourselog%2Fcontact%2F&amp;format=xml" />
  <noscript>
    <style>
      .woocommerce-product-gallery {
        opacity: 1 !important;
      }
    </style>
  </noscript>

  <script type="text/javascript">
    var elementskit_module_parallax_url =
      "../wp-content/plugins/courselog-essential/modules/parallax/index.html";
  </script>
  <style type="text/css" id="wp-custom-css">
    .single-course-item.course-grid-style2 .single-course .course-title-area .course-category span {
      padding: 5px 0 5px 0;
    }

    .single-course-item.course-grid-style2 .single-course .xs-review-rattting {
      margin-right: 10px;
    }

    .single-course-item.course-grid-style2 .single-course .xs-review-rattting .xs-star {
      color: #ffcc00;
    }

    .single-course-item.course-grid-style2 .single-course:hover .xs-review-rattting .xs-star {
      color: #fff;
    }

    .elementor-widget-elementskit-blog-posts .meta-date i,
    .elementor-widget-elementskit-blog-posts.post-cat i {
      vertical-align: middle;
    }

    .elementor-widget-elementskit-blog-posts .meta-date i {
      color: #3478f6;
    }

    .elementor-widget-elementskit-blog-posts .post-cat i {
      color: #0acc86;
    }

    .elementor-widget-elementskit-blog-posts .btn-wraper a i {
      margin-right: 5px;
      vertical-align: middle;
    }

    .elementor-widget-elementskit-blog-posts .btn-wraper a {
      position: relative;
    }

    .elementor-widget-elementskit-blog-posts .btn-wraper a:after {
      position: absolute;
      content: "";
      right: 0px;
      border-bottom: 2px solid #333333;
      width: 80%;
      bottom: -3px;
      transition: all ease 0.4s;
    }

    .elementor-widget-elementskit-blog-posts .btn-wraper:hover a:after {
      opacity: 0;
      visibility: hidden;
    }

    .single-course-item.course-grid-style2 .single-course:hover .hover {
      padding: 40px !important;
    }

    .nav-style-classic:after {
      background: linear-gradient(to right,
          #fdbb28 15%,
          #fdbb28 10%,
          #fa4142 10%,
          #fa4142 30%,
          #3478f6 10%,
          #3478f6 45%,
          #0acc86 10%,
          #0acc86 60%,
          #fdbb28 10%,
          #fdbb28 75%,
          #fa4142 10%,
          #fa4142 90%,
          #3478f6 10%,
          #3478f6 90%);
      position: absolute;
      content: "";
      height: 2px;
      right: 0;
      left: 0;
      top: 0;
    }

    .single-course-item.course-grid-style2 .single-course:hover .hover .course-category {
      padding: 5px 0px;
    }

    .ts-scroll-box .BackTo a {
      font-size: 16px;
    }

    .instructor-list-wrap .single-instructor-item .instructor-social a {
      font-size: 16px;
    }

    .course-grid-style2 .single-course .course-category a:before {
      background: transparent;
    }

    .insturctor-single .single-course-item.course-grid-style2 .single-course .excerpt-content p {
      display: none;
    }

    .course-full-width-content .turitor-list li:after {
      background: #fa4142;
    }

    .cl-main-header {
      box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.03);
    }

    .ts-cat-menu .menu li .sub-menu li a {
      border-bottom: 0px solid #2878eb;
    }

    .ts-cat-menu .menu li .sub-menu li a:after {
      display: none;
    }

    .ts-cat-menu .sub-menu {
      position: absolute;
      left: 28px;
      top: 30px;
      list-style: none;
      background: #fff;
      min-width: 150px;
      padding: 0;
      -webkit-box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.2);
      box-shadow: 0 3px 5px 0 rgba(0, 0, 0, 0.2);
      border: none;
      transition: transform 0.4s ease, -webkit-transform 0.4s ease;
      margin: 0;
      z-index: 11;
      transform: translateY(20px);
      display: block;
      border-radius: 6px;
      -webkit-border-radius: 6px;
      -ms-border-radius: 6px;
      opacity: 0;
      visibility: hidden;
    }

    .ts-cat-menu .menu .sub-menu li {
      border-style: solid;
      border-width: 0px 0px 1px 0px;
      border-color: #f0f0f0;
      background-color: #ffffff;
      border-radius: 0px;
      padding: 15px 30px 15px 15px;
    }

    .ts-cat-menu .menu .menu-item:hover .sub-menu {
      transform: translateY(5px);
      opacity: 1;
      visibility: visible;
    }

    @media (max-width: 992px) {
      .elementor-widget-turitor-userlogin {
        display: block !important;
      }
    }

    @media (max-width: 1600px) {
      .ekit-section-parallax-layer {
        display: none;
      }

      .skew-column .elementor-element-populated {
        background: none !important;
      }
    }

    .instructor-list-wrap .single-instructor-item:hover .instructor-profile-content .instructor-social {
      bottom: 25% !important;
    }

    .start-quiz button {
      padding: 10px 22px 10px 22px;
      background-color: #f14d5d;
      border-style: none;
      border-radius: 5px 5px 5px 5px;
      color: #fff;
      cursor: pointer;
      border-radius: 50px;
    }

    .lp-quiz-buttons .form-button button {
      padding: 10px 22px 10px 22px;
      background-color: #f14d5d;
      border-style: none;
      border-radius: 5px 5px 5px 5px;
      color: #fff;
      cursor: pointer;
      border-radius: 50px;
    }

    @media (max-width: 768px) {
      .elementskit-navbar-nav-default .elementskit-dropdown-has>a .elementskit-submenu-indicator {
        margin-left: auto !important;
        border-color: transparent;
      }
    }

    .tab-course-category ul li:hover:before,
    .tab-course-category ul li.active:before {
      background: rgba(255, 255, 255, 0.5);
    }

    .ts-instructor-profile-info {
      margin-bottom: 50px;
    }

    .user-meta-summery {
      margin-bottom: 60px;
    }

    .elementskit-dropdown-has>a .elementskit-submenu-indicator {
      margin: 0px 0px 0px auto;
      margin-left: auto;
      border: none;
    }

    .banner-course .course-instructor .course-instructor-thumb img {
      width: 36px;
      height: 36px;
    }

    .courselog-instructor-profile-header .ts-instructor-info .ts-title {
      margin: 0;
      text-transform: capitalize;
    }

    @media (min-width: 575px) and (max-width: 1024px) {
      .header-course-search .courselog-search-course-form {
        width: 50%;
      }
    }

    @media (max-width: 1024px) {
      .elementskit-navbar-nav .elementskit-submenu-panel {
        background-color: transparent !important;
      }
    }

    .archive-course-container.archive-course-solid .archive-style-solid {
      padding-bottom: 250px;
      margin-bottom: -200px;
    }

    .tab-course-category ul li {
      padding-left: 30px;
    }

    .cl-main-header.ekit-sticky {
      z-index: 999;
    }
  </style>
  <noscript>
    <style id="rocket-lazyload-nojs-css">
      .rll-youtube-player,
      [data-lazy-src] {
        display: none !important;
      }
    </style>
  </noscript>
</head>

<body class="page-template page-template-template
      page-template-full-width-template
      page-template-templatefull-width-template-php
      page
      page-id-6440
      theme-courselog
      woocommerce-no-js
      sidebar-active
      elementor-default elementor-kit-573 elementor-page elementor-page-6440
    ">

    <div class="
        ekit-template-content-markup
        ekit-template-content-header
        ekit-template-content-theme-support
      ">
      <div data-elementor-type="wp-post" data-elementor-id="138" class="elementor elementor-138" data-elementor-settings="[]">
        <div class="elementor-inner">
          <div class="elementor-section-wrap">
            <section class="
                elementor-section
                elementor-top-section
                elementor-element
                elementor-element-8ba937a
                elementor-section-full_width
                elementor-section-height-default
                elementor-section-height-default
              " data-id="8ba937a" data-element_type="section" data-settings='{"background_background":"classic","ekit_has_onepagescroll_dot":"yes"}' style="background-color:#f14d5d;">
              <div class="elementor-container elementor-column-gap-default container">
                <div class="elementor-row">
                  <div class="
                      elementor-column
                      elementor-col-50
                      elementor-top-column
                      elementor-element
                      elementor-element-a5fcde8
                    " data-id="a5fcde8" data-element_type="column">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="
                            elementor-element elementor-element-6b930f1
                            top-header-text
                            elementor-widget elementor-widget-text-editor
                          " data-id="6b930f1" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="text-editor.default">
                          <div class="elementor-widget-container">
                            <div class="elementor-text-editor elementor-clearfix"> <b style="font-size: 2.3em; font-weight:bolder">Centre de sante</b>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="
                      elementor-column
                      elementor-col-50
                      elementor-top-column
                      elementor-element
                      elementor-element-361bc0b
                    " data-id="361bc0b" data-element_type="column">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="
                            elementor-element
                            elementor-element-31a3327
                            elementor-widget
                            elementor-widget-elementskit-social-media
                          " data-id="31a3327" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-social-media.default">
                          <div class="elementor-widget-container">
                            <div class="ekit-wid-con">
                              <ul class="ekit_social_media">
                                <li class="elementor-repeater-item-0745300">
                                  <a href="" class="facebook">
                                    <i aria-hidden="true" class="icon icon-facebook"></i>
                                  </a>
                                </li>
                                <li class="elementor-repeater-item-b5cd8a5">
                                  <a href="" class="1">
                                    <i aria-hidden="true" class="icon icon-instagram-1"></i>
                                  </a>
                                </li>

                                <li class="elementor-repeater-item-9cd60b5">
                                  <a href="" class="twitter">
                                    <i aria-hidden="true" class="icon icon-twitter"></i>
                                  </a>
                                </li>
                                <li class="elementor-repeater-item-9cd60b5">
                                  <select name="category">
                                    <option value="lien"> FR </option>
                                    <option value="lien">EN</option>
                                  </select>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <section class="
                elementor-section
                elementor-top-section
                elementor-element
                elementor-element-db3f74d
                elementor-section-full_width
                cl-main-header
                elementor-section-height-default
                elementor-section-height-default
              " data-id="db3f74d" data-element_type="section" data-settings='{"background_background":"classic","ekit_sticky":"top","ekit_has_onepagescroll_dot":"yes","ekit_sticky_on":["desktop","tablet","mobile"],"ekit_sticky_offset":{"unit":"px","size":0,"sizes":[]},"ekit_sticky_effect_offset":{"unit":"px","size":0,"sizes":[]}}'>
              <div class="elementor-container elementor-column-gap-default">
                <div class="elementor-row">
                  <div style="width: 25%;" class="
                      elementor-column
                      elementor-col-25
                      elementor-top-column
                      elementor-element
                      elementor-element-3189300
                      hide-search-and--------button
                    " data-id="3189300" data-element_type="column">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="
                            elementor-element elementor-element-43eeffd
                            elementor-widget__width-auto
                            elementor-widget elementor-widget-courselog-logo
                          " data-id="43eeffd" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="courselog-logo.default">
                          <div class="elementor-widget-container">
                            <div class="courselog-widget-logo">
                              <a href="../index.php">
                                <img src="../assets/img/logoprim.jpg" alt="logo" />
                              </a>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>


                  <div style="width: 75%;" class="
                      elementor-column
                      elementor-col-75
                      elementor-top-column
                      elementor-element
                      elementor-element-ac77f67
                      course-log-nav
                    " data-id="ac77f67" data-element_type="column">
                    <div class="elementor-column-wrap elementor-element-populated">
                      <div class="elementor-widget-wrap">
                        <div class="
                            elementor-element elementor-element-de707fc
                            elementor-widget__width-auto
                            ts-color-nav
                            elementor-widget elementor-widget-ekit-nav-menu
                          " data-id="de707fc" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="ekit-nav-menu.default">
                          <div class="elementor-widget-container">
                            <div class="ekit-wid-con ekit_menu_responsive_tablet" data-hamburger-icon="icon icon-menu-9" data-hamburger-icon-type="icon" data-responsive-breakpoint="1024">
                              <button class="
                                  elementskit-menu-hamburger
                                  elementskit-menu-toggler
                                ">
                                <i aria-hidden="true" class="ekit-menu-icon icon icon-menu-9"></i>
                              </button>
                              <div id="ekit-megamenu-main-menu" class="
                                  elementskit-menu-container
                                  elementskit-menu-offcanvas-elements
                                  elementskit-navbar-nav-default
                                  elementskit_line_arrow
                                  ekit-nav-menu-one-page-yes
                                ">
                                <ul id="main-menu" class=" elementskit-navbar-nav
                                    elementskit-menu-po-left
                                    submenu-click-on-icon
                                  " >


                                  <li id="menu-item-1359" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page
                                      menu-item-has-children
                                      menu-item-1359
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                    " data-vertical-menu="750px">
                                    <a href="../index.php" class=" ekit-menu-nav-link ">
                                      Accueil
                                    </a>
                                  </li>

                                  <li id="menu-item-1359" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page
                                      menu-item-has-children
                                      menu-item-1359
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                    " data-vertical-menu="750px">
                                    <a href="../public/labo.php" class="
                                        ekit-menu-nav-link
                                        ekit-menu-dropdown-toggle
                                      ">A propos</a>
                                 
                                  </li>



                                  <!--li diferent large-->
                                  <li id="menu-item-1027" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1027 nav-item elementskit-dropdown-has top_position elementskit-dropdown-menu-full_width elementskit-megamenu-has elementskit-mobile-builder-content" data-vertical-menu=""><a href="#" class="ekit-menu-nav-link ekit-menu-dropdown-toggle">Hôpital<i class="icon icon-down-arrow1 elementskit-submenu-indicator"></i></a>
                                    <ul class="elementskit-dropdown elementskit-submenu-panel">
                                      <li id="menu-item-10" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">About</a>
                                      <li id="menu-item-898" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-898 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">Instructor</a>
                                      <li id="menu-item-1208" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1208 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">Instructor Profile</a>
                                      <li id="menu-item-4232" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4232 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">Become an instructor</a>
                                      <li id="menu-item-6699" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6699 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">Pricing</a>
                                      <li id="menu-item-4233" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4233 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">FAQs</a>
                                      <li id="menu-item-6698" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6698 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">Contact</a>
                                      <li id="menu-item-4245" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4245 nav-item elementskit-mobile-builder-content" data-vertical-menu=750px><a href="" class=" dropdown-item">404</a>
                                    </ul>
                                    <ul class="elementskit-megamenu-panel">
                                      <div data-elementor-type="wp-post" data-elementor-id="8202" class="elementor elementor-8202" data-elementor-settings="[]">
                                        <div class="elementor-inner">
                                          <div class="elementor-section-wrap">
                                            <section class="elementor-section elementor-top-section elementor-element elementor-element-51987094 megamenu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="51987094" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
                                              <div class="elementor-container elementor-column-gap-no">
                                                <div class="elementor-row">
                                                  <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5fada50a" data-id="5fada50a" data-element_type="column">
                                                    <div class="elementor-column-wrap elementor-element-populated">
                                                      <div class="elementor-widget-wrap">
                                                        <section class="elementor-section elementor-inner-section elementor-element elementor-element-e857c1e elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="e857c1e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
                                                          <div class="elementor-container elementor-column-gap-no">
                                                            <div class="elementor-row">
                                                              <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-56011e30" data-id="56011e30" data-element_type="column">
                                                                <div class="elementor-column-wrap elementor-element-populated">
                                                                  <div class="elementor-widget-wrap">
                                                                    <div class="elementor-element elementor-element-8f0e9b6 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="8f0e9b6" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <!-- link opening -->
                                                                          <!-- end link opening -->

                                                                          <div class="elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media  ">
                                                                            <div class="elementskit-box-header elementor-animation-">
                                                                              <div class="elementskit-info-box-icon  text-center">
                                                                                <i aria-hidden="true" class="elementkit-infobox-icon fas fa-clipboard-list"></i>
                                                                              </div>
                                                                            </div>
                                                                            <div class="box-body">
                                                                              <h3 class="elementskit-info-box-title">
                                                                               titre </h3>
                                                                            </div>


                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                    <div class="elementor-element elementor-element-18c1e897 elementor-widget elementor-widget-elementskit-page-list" data-id="18c1e897" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <div class="elementor-icon-list-items ">
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-ac26393 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Equipe médicale</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>


                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-c8da05e ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Plateau technique</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-46b5541 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Sous tire2</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-395176d ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Sous tire3</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                              <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3ecb29ae" data-id="3ecb29ae" data-element_type="column">
                                                                <div class="elementor-column-wrap elementor-element-populated">
                                                                  <div class="elementor-widget-wrap">
                                                                    <div class="elementor-element elementor-element-575857d3 elementor-widget elementor-widget-elementskit-page-list" data-id="575857d3" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <div class="elementor-icon-list-items ">
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-ac26393 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Sous tire1 </span>
                                                                                  </span>
                                                                                </div>
                                                                                <span class="ekit_menu_label">
                                                                                  new </span>
                                                                              </a>
                                                                            </div>
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-03dccb7 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Sous tire2</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="" class="elementor-repeater-item-b1ac949 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">FAQs</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="" class="elementor-repeater-item-39d3f42 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Médiathèque</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                              <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-5daf1d7d" data-id="5daf1d7d" data-element_type="column">
                                                                <div class="elementor-column-wrap elementor-element-populated">
                                                                  <div class="elementor-widget-wrap">
                                                                    <div class="elementor-element elementor-element-1a314d48 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="1a314d48" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <!-- link opening -->
                                                                          <!-- end link opening -->

                                                                          <div class="elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media  ">
                                                                            <div class="elementskit-box-header elementor-animation-">
                                                                              <div class="elementskit-info-box-icon  text-center">
                                                                                <i aria-hidden="true" class="elementkit-infobox-icon fas fa-bolt"></i>
                                                                              </div>
                                                                            </div>
                                                                            <div class="box-body">
                                                                              <h3 class="elementskit-info-box-title">
                                                                                Patient
                                                                              </h3>
                                                                            </div>


                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                    <div class="elementor-element elementor-element-b2e5cd9 elementor-widget elementor-widget-elementskit-page-list" data-id="b2e5cd9" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <div class="elementor-icon-list-items ">
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-ac26393 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Hospitalisation</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>

                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-28aef60 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Mon séjours </span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>


                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-4cde5f1 ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Règlementation</span>
                                                                                  </span>
                                                                                </div>
                                                                                <span class="ekit_menu_label">
                                                                                  Hot </span>
                                                                              </a>
                                                                            </div>
                                                                            <div class="elementor-icon-list-item   ">
                                                                              <a target=_self rel="" href="#" class="elementor-repeater-item-ee4320f ekit_badge_left">
                                                                                <div class="ekit_page_list_content">
                                                                                  <span class="elementor-icon-list-text">
                                                                                    <span class="ekit_page_list_title_title">Assurances</span>
                                                                                  </span>
                                                                                </div>
                                                                              </a>
                                                                            </div>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                              <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6a8d2bc1" data-id="6a8d2bc1" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                                <div class="elementor-column-wrap elementor-element-populated">
                                                                  <div class="elementor-background-overlay"></div>
                                                                  <div class="elementor-widget-wrap">
                                                                    <div class="elementor-element elementor-element-72e92a1c elementor-widget elementor-widget-elementskit-heading" data-id="72e92a1c" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                                                            <h3 class="ekit-heading--title elementskit-section-title ">
                                                                              Informations Corona virus
                                                                            </h3>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                    <div class="elementor-element elementor-element-45e88c48 elementor-widget elementor-widget-elementskit-button" data-id="45e88c48" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-button.default">
                                                                      <div class="elementor-widget-container">
                                                                        <div class="ekit-wid-con">
                                                                          <div class="ekit-btn-wraper">
                                                                            <a href="" class="elementskit-btn  whitespace--normal">
                                                                              Infos covid</a>
                                                                          </div>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                        </section>
                                                      </div>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </section>
                                          </div>
                                        </div>
                                      </div>
                                    </ul>
                                  </li>
                                  <!--en li large-->

                                  <li id="menu-item-8098" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page menu-item-home
                                      current-menu-item
                                      page_item page-item-5
                                      current_page_item
                                      current-menu-ancestor
                                      current-menu-parent
                                      current_page_parent
                                      current_page_ancestor
                                      menu-item-has-children menu-item-8098
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                      active
                                    " data-vertical-menu="750px">
                                    <a href="#" class="
                                        ekit-menu-nav-link
                                        ekit-menu-dropdown-toggle
                                      ">Services<i class="
                                          icon icon-down-arrow1
                                          elementskit-submenu-indicator
                                        "></i></a>
                                    <ul class="
                                        elementskit-dropdown
                                        elementskit-submenu-panel
                                      ">
                                      <li id="menu-item-11" class="
                                          menu-item
                                          menu-item-type-post_type
                                          menu-item-object-page menu-item-home
                                          current-menu-item
                                          page_item page-item-5
                                          current_page_item
                                          menu-item-11
                                          nav-item
                                          elementskit-mobile-builder-content
                                          active
                                        " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item active" style="color: red;">
                                          <i class=" ekit-menu-icon icon icon-list-2 " style="color: #2878eb"></i>
                                          Urgences/Ambulances</a>


                                      </li>
                                      <li id="menu-item-8100" class="
                                          menu-item
                                          menu-item-type-post_type
                                          menu-item-object-page menu-item-8100
                                          nav-item
                                          elementskit-mobile-builder-content
                                        " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item">Laboratoire</a>
                                      </li>
                                      <li id="menu-item-8099" class="
                                          menu-item
                                          menu-item-type-post_type
                                          menu-item-object-page menu-item-8099
                                          nav-item
                                          elementskit-mobile-builder-content
                                        " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item">Imagerie</a>
                                      </li>
                                      <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                        <a href="public/neuro.php" class="dropdown-item">
                                          Neurochirurgie </a>
                                      </li>
                                      <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item">cardiologie </a>
                                      </li>
                                      <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item">Gynécologie/Obstétrique </a>
                                      </li>
                                      <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item">Kinésithérapie </a>
                                      </li>
                                      <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                        <a href="../public/labo.php" class="dropdown-item"> Services à venir </a>
                                      </li>
                                    </ul>
                                  </li>

                                  <li id="menu-item-1359" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page
                                      menu-item-has-children
                                      menu-item-1359
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                    " data-vertical-menu="750px">
                                    <a href="../public/contact.php" class=" ekit-menu-nav-link ">
                                      Contacts
                                    </a>
                                  </li>


                                </ul>
                                <div class="elementskit-nav-identity-panel">

                                  <button class="
                                      elementskit-menu-close
                                      elementskit-menu-toggler
                                    " type="button">
                                    X
                                  </button>
                                </div>
                              </div>
                              <div class="
                                  elementskit-menu-overlay
                                  elementskit-menu-offcanvas-elements
                                  elementskit-menu-toggler
                                  ekit-nav-menu--overlay
                                "></div>
                            </div>
                          </div>
                        </div>
                        <div class=" elementor-element elementor-element-5011564 elementor-widget__width-auto
                            elementor-hidden-tablet
                            elementor-hidden-phone
                            elementor-widget
                            elementor-widget-elementskit-button
                          " data-id="5011564" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-button.default">

                        </div>
                        <div class="
                            elementor-element elementor-element-3ba9b96
                            elementor-widget__width-auto
                            elementor-widget
                            elementor-widget-courselog-userlogin
                          " data-id="3ba9b96" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="courselog-userlogin.default">
                          <div class="elementor-widget-container">
                            <div class="
                            elementor-element elementor-element-3ba9b96
                            elementor-widget__width-auto
                            elementor-widget
                            elementor-widget-courselog-userlogin
                          " data-id="3ba9b96" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="courselog-userlogin.default">
                              <div class="elementor-widget-container">
                                <div class="elementskit-site-title">
                                  <a class="elementskit-nav-logo" href="../index.php" target="_self">
                                    <img src="" alt="logo CNPS" data-lazy-src="../assets/img/logo.jpg" />
                                    <noscript>
                                      <img src="../assets/img/logo.jpg" alt="logo " />
                                    </noscript>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>



    <script type="text/javascript">
      (function() {
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
      })();
    </script>
    <style id='etn-custom-css-inline-css' type='text/css'>
      .etn-event-single-content-wrap .etn-event-meta .etn-event-category span,
      .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border,
      .etn-btn.etn-btn-border,
      .attr-btn-primary.etn-btn-border,
      .etn-attendee-form .etn-btn.etn-btn-border,
      .etn-ticket-widget .etn-btn.etn-btn-border,
      .etn-settings-dashboard .button-primary.etn-btn-border,
      .etn-single-speaker-item .etn-speaker-content a:hover,
      .etn-event-style2 .etn-event-date,
      .etn-event-style3 .etn-event-content .etn-title a:hover,
      .etn-event-item:hover .etn-title a {
        color: #5D78FF;
      }

      .etn-event-item .etn-event-category span,
      .etn-btn,
      .attr-btn-primary,
      .etn-attendee-form .etn-btn,
      .etn-ticket-widget .etn-btn,
      .schedule-list-1 .schedule-header,
      .speaker-style4 .etn-speaker-content .etn-title a,
      .etn-speaker-details3 .speaker-title-info,
      .etn-event-slider .swiper-pagination-bullet,
      .etn-speaker-slider .swiper-pagination-bullet,
      .etn-event-slider .swiper-button-next,
      .etn-event-slider .swiper-button-prev,
      .etn-speaker-slider .swiper-button-next,
      .etn-speaker-slider .swiper-button-prev,
      .etn-single-speaker-item .etn-speaker-thumb .etn-speakers-social a,
      .etn-event-header .etn-event-countdown-wrap .etn-count-item,
      .schedule-tab-1 .etn-nav li a.etn-active,
      .etn-settings-dashboard .button-primary {
        background-color: #5D78FF;
      }

      .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border,
      .etn-btn.etn-btn-border,
      .attr-btn-primary.etn-btn-border,
      .etn-attendee-form .etn-btn.etn-btn-border,
      .etn-ticket-widget .etn-btn.etn-btn-border,
      .etn-settings-dashboard .button-primary.etn-btn-border {
        border-color: #5D78FF;
      }

      .schedule-tab-wrapper .etn-nav li a.etn-active {
        border-bottom-color: #5D78FF;
      }

      .schedule-tab-wrapper .etn-nav li a:after,
      .schedule-tab-1 .etn-nav li a.etn-active:after {
        border-color: #5D78FF transparent transparent transparent;
      }
    </style>