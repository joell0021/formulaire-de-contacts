<?php
$title = "Erreur 404";
include("../layout/header2.php");

include("../views/404.view.php");

include("../layout/footer2.php");

?>