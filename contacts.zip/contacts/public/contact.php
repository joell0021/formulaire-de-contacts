<?php
$title = "Contacts";
include("../layout/header2.php");

include("../views/contact.view.php");







include("../layout/footer2.php");

?>