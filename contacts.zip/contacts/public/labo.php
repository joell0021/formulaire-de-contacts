<?php
$title = "Laboratoire";
include("../layout/header2.php");

include("../views/labo.view.php");

include("../layout/footer2.php");

?>