
<style>
	.info-contact {
		width: 500px;
	}

	#post-6440 {
		background-color: rgba(0, 0, 0, 0.03);
	}
</style>

<!--<div data-bg="../assets/img/_DSC0959.jpg" class=" banner-bg banner-area rocket-lazyload" >-->
<div id="post-6440" class="full-width-content post-6440 page type-page status-publish hentry" role="main">
	<div class="builder-content">
		<div data-elementor-type="wp-page" data-elementor-id="6440" class="elementor elementor-6440" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">

					<section class="elementor-section elementor-top-section elementor-element elementor-element-248d863 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="248d863" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
						<div class="elementor-container elementor-column-gap-default">
							<div class="elementor-row">
								<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-90f9ee1" data-id="90f9ee1" data-element_type="column">
									<div class="elementor-column-wrap elementor-element-populated">
										<div class="elementor-widget-wrap">
											<div class="elementor-element elementor-element-74831ec elementor-widget elementor-widget-elementskit-heading" data-id="74831ec" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
												<div class="elementor-widget-container">
													<div class="ekit-wid-con">
														<div class="ekit-heading elementskit-section-title-wraper text_center   ekit_heading_tablet-   ekit_heading_mobile-">
															<h3 class="elementskit-section-subtitle  ">Envoyez nous un Message</h3>
															<h2 class="ekit-heading--title elementskit-section-title ">
																Nous Répondrons a toutes vos Questions
															</h2>
														</div>
													</div>
												</div>
											</div>
											<section class="elementor-section elementor-inner-section elementor-element elementor-element-976a92c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="976a92c" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
												<div class="elementor-container elementor-column-gap-default">
													<div class="elementor-row">
														<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3ec2984" data-id="3ec2984" data-element_type="column">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">
																	<div class="elementor-element elementor-element-437b1cd elementor-widget elementor-widget-image" data-id="437b1cd" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="image.default">
																		<div class="elementor-widget-container">
																			<div class="elementor-image">

																				<section style="margin-top: -130px;" class="elementor-section elementor-top-section elementor-element elementor-element-1ec6488a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1ec6488a" data-element_type="section" data-settings="{&quot;ekit_section_parallax_multi_items&quot;:[{&quot;_id&quot;:&quot;eb6b369&quot;,&quot;parallax_style&quot;:&quot;onscroll&quot;,&quot;image&quot;:{&quot;url&quot;:&quot;https:\/\/demo.themewinter.com\/wp\/courselog\/wp-content\/uploads\/2021\/01\/contact_pattern_1.png&quot;,&quot;id&quot;:6531},&quot;pos_x&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;pos_y&quot;:{&quot;unit&quot;:&quot;%&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;item_source&quot;:&quot;image&quot;,&quot;shape&quot;:null,&quot;shape_color&quot;:null,&quot;width_type&quot;:&quot;&quot;,&quot;width_type_tablet&quot;:&quot;&quot;,&quot;width_type_mobile&quot;:&quot;&quot;,&quot;custom_width&quot;:null,&quot;custom_width_tablet&quot;:null,&quot;custom_width_mobile&quot;:null,&quot;source_rotate&quot;:{&quot;unit&quot;:&quot;deg&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;source_rotate_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;source_rotate_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;parallax_blur_effect&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;parallax_blur_effect_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;parallax_blur_effect_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;pos_x_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;pos_x_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;pos_y_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;pos_y_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;animation&quot;:null,&quot;animation_tablet&quot;:null,&quot;animation_mobile&quot;:null,&quot;item_opacity&quot;:&quot;1&quot;,&quot;animation_speed&quot;:null,&quot;animation_iteration_count&quot;:null,&quot;animation_direction&quot;:null,&quot;parallax_speed&quot;:null,&quot;parallax_transform&quot;:&quot;translateY&quot;,&quot;parallax_transform_value&quot;:&quot;250&quot;,&quot;smoothness&quot;:&quot;700&quot;,&quot;offsettop&quot;:&quot;0&quot;,&quot;offsetbottom&quot;:&quot;0&quot;,&quot;maxtilt&quot;:null,&quot;scale&quot;:null,&quot;disableaxis&quot;:null,&quot;zindex&quot;:&quot;2&quot;}],&quot;ekit_section_parallax_multi&quot;:&quot;yes&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
																					<div class="elementor-container elementor-column-gap-default">
																						<div class="elementor-row">
																							<div class=" elementor-top-column elementor-element elementor-element-456d8200" data-id="456d8200" data-element_type="column">
																								<div class="elementor-column-wrap elementor-element-populated ">
																									<div class="elementor-widget-wrap">
																										<div class="elementor-element elementor-element-dcf9db7 elementor-widget elementor-widget-elementskit-heading" data-id="dcf9db7" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">

																										</div>
																										<div class="elementor-element elementor-element-d07493b ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="d07493b" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
																											<div class="elementor-widget-container">
																												<div class="ekit-wid-con">
																													<!-- link opening -->
																													<!-- end link opening -->

																													<div class="elementskit-infobox text-left text-left icon-lef-right-aligin elementor-animation- media info-contact">
																														<div class="elementskit-box-header elementor-animation-">
																															<div class="elementskit-info-box-icon  text-center">
																																<i aria-hidden="true" class="elementkit-infobox-icon tsicon tsicon-tsphone"></i>
																															</div>
																														</div>
																														<div class="box-body">
																															<h3 class="elementskit-info-box-title">
																																(+237) 111 111 222 / 758 785 695
																															</h3>
																															<p>24h / 24 & 7j / 7</p>
																														</div>


																													</div>
																												</div>
																											</div>
																										</div>
																										<div class="elementor-element elementor-element-59ac163 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="59ac163" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
																											<div class="elementor-widget-container">
																												<div class="ekit-wid-con">
																													<!-- link opening -->
																													<!-- end link opening -->

																													<div class="elementskit-infobox text-left text-left icon-lef-right-aligin elementor-animation- media  info-contact">
																														<div class="elementskit-box-header elementor-animation-">
																															<div class="elementskit-info-box-icon  text-center">
																																<i aria-hidden="true" class="elementkit-infobox-icon tsicon tsicon-envelope"></i>
																															</div>
																														</div>
																														<div class="box-body">
																															<h3 class="elementskit-info-box-title">
																																Ecrivez-nous à tout moment!
																															</h3>
																															<p>Admin@domain.com</p>
																														</div>


																													</div>
																												</div>
																											</div>
																										</div>
																										<div class="elementor-element elementor-element-8f94063 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="8f94063" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
																											<div class="elementor-widget-container">
																												<div class="ekit-wid-con">
																													<!-- link opening -->
																													<!-- end link opening -->

																													<div class="elementskit-infobox text-left text-left icon-lef-right-aligin elementor-animation- media  info-contact">
																														<div class="elementskit-box-header elementor-animation-">
																															<div class="elementskit-info-box-icon  text-center">
																																<i aria-hidden="true" class="elementkit-infobox-icon fas fa-map-marker-alt"></i>
																															</div>
																														</div>
																														<div class="box-body">
																															<h3 class="elementskit-info-box-title">
																																BP numero de boite DOUALA
																															</h3>
																															<p>localisation</p>
																														</div>


																													</div>
																												</div>
																											</div>
																										</div>
																										<section class="elementor-section elementor-inner-section elementor-element elementor-element-f1f140b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="f1f140b" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
																											<div class="elementor-container elementor-column-gap-default">
																												<div class="elementor-row">
																													<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c60e15c" data-id="c60e15c" data-element_type="column">
																														<div class="elementor-column-wrap elementor-element-populated">
																															<div class="elementor-widget-wrap">
																																<div class="elementor-element elementor-element-bacfeb6 elementor-widget elementor-widget-elementskit-button" data-id="bacfeb6" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-button.default">
																																	<div class="elementor-widget-container">
																																		<div class="ekit-wid-con">
																																			<div class="ekit-btn-wraper">
																																				<a href="" class="elementskit-btn  whitespace--normal">
																																					Rejoignez-nous
																																				</a>
																																			</div>
																																		</div>
																																	</div>
																																</div>
																															</div>
																														</div>
																													</div>
																													<div style="margin-left: 40px;" class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-cc0d15f" data-id="cc0d15f" data-element_type="column">
																														<div class="elementor-column-wrap elementor-element-populated">
																															<div class="elementor-widget-wrap">
																																<div class="elementor-element elementor-element-465a94b elementor-widget elementor-widget-elementskit-social-share" data-id="465a94b" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-social-share.default">
																																	<div class="elementor-widget-container">
																																		<div class="ekit-wid-con">
																																			<ul class="ekit_socialshare">
																																				<li class="elementor-repeater-item-454b1ef" data-social="facebook">
																																					<a class="facebook" href="">
																																						<i aria-hidden="true" class="icon icon-facebook"></i>
																																					</a>
																																				</li>
																																				<li class="elementor-repeater-item-53138ea" data-social="twitter">
																																					<a class="twitter" href="">
																																						<i aria-hidden="true" class="icon icon-twitter"></i>
																																					</a>
																																				</li>
																																				<li class="elementor-repeater-item-4aa1f8f" data-social="skype">
																																					<a class="skype" href="">
																																						<i aria-hidden="true" class="fab fa-instagram"></i>
																																					</a>
																																				</li>
																																			</ul>
																																		</div>
																																	</div>
																																</div>
																															</div>
																														</div>
																													</div>
																												</div>
																											</div>
																										</section>
																									</div>
																								</div>
																							</div>

																						</div>
																					</div>
																				</section>


																			</div>
																		</div>
																	</div>
																	
																</div>
															</div>
														</div>

														<style>
														form div .ip{
																border-radius:5px
															}
															form div textarea{
																width: 100%;
																height: 120px;
																border-radius:5px
															}
														</style>
														<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-897f56d" data-id="897f56d" data-element_type="column">
															<div class="elementor-column-wrap elementor-element-populated">
																<div class="elementor-widget-wrap">
																	<div class="elementor-element elementor-element-a5509f0 elementor-widget elementor-widget-metform" data-id="a5509f0" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="metform.default">
																		<div class="elementor-widget-container">
																			<div id="mf-response-props-id-6490" data-editswitchopen="" data-erroricon="fas fa-exclamation-triangle" data-successicon="fas fa-check" data-messageposition="top" class="   mf-scroll-top-no">
																				<div class="formpicker_warper formpicker_warper_editable" data-metform-formpicker-key="6490">

																					<div class="elementor-widget-container">

																						<div id="metform-wrap-a5509f0-6490" class="mf-form-wrapper" data-form-id="6490" data-action="../wp-json/metform/v1/entries/insert/6490.json" data-wp-nonce="5f14c258b8" data-form-nonce="a7b607e2a1" data-stop-vertical-effect=""></div>


																						<form id="contact-form" name="contact-form" action="send_mail.php" method="POST">

																							<div class="row">
																								<div class="col-md-12">
																									<div class="md-form">
																										<div class="md-form">
																											<input type="text" id="name" name="name" class="ip form-control" placeholder="Entrez votre nom">
																											<label for="name" class=""></label>
																										</div>
																									</div>
																								</div>
																							</div>
																							
																							<div class="row">
																								<div class="col-md-12">
																									<div class="md-form">
																										<div class="md-form">
																											<input type="text" id="email" name="name" class="ip form-control" placeholder="Entrez votre Email">
																											<label for="email" class=""></label>
																										</div>
																									</div>
																								</div>
																							</div>

																							<div class="row">
																								<div class="col-md-12">

																									<div class="md-form ">
																										<textarea type="textarea" id="message" name="message" class="md-textarea"  placeholder="Entrez votre Message">
																										</textarea>
																										
																									</div>

																								</div>
																							</div>

																						</form>
																						<label for="message" class=""></label>
																						<div class="center-on-small-only">
																							<button class="btn btn-primary text-white" onclick="document.getElementById('contact-form').submit();">
																								<i  class="fas fa-paper-plane"></i>	
																								Envoyer
																							</button>
																						</div>

																					</div>
																				</div>
																			</div>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</section>
										</div>
									</div>
								</div>
							</div>
						</div>

					</section>



			</div>
		</div>
	</div>
</div> <!-- end main-content -->
</div> <!-- end main-content -->

<!--</div>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 