<aside id="sidebar" class="sidebar" role="complementary">
	<div id="search-2" class="widget widget_search">
		<div action="  " class="courselog-serach">
			<div class="input-group" onclick="FindNext ();">
				<input type="search" class="form-control" name="s" placeholder="Rechercher.." value="" id="">
				<button type="submit" class="input-group-btn"><i class="fas fa-search"></i></button>
			</div>
		</div>
	</div>

	<div id="xs-recent-post-2" class="widget courselog-widget">
		<h4 class="widget-title">Actualité</h4>
		<div class="widget-posts recent-post-widget">
			<div class="widget-post media">
				<a href="#" class="post-thumb">
					<span data-bg="../assets/img/actu1.jpg" class="rocket-lazyload" style=""></span>
				</a>
				<div class="media-body">

					<h6 class="post-title">
						<a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=newssearch&cd=&cad=rja&uact=8&ved=0ahUKEwj2rZXe2cbwAhWQxIUKHWe5CkkQxfQBCDowAQ&url=https%3A%2F%2Fwww.lesechos.fr%2Findustrie-services%2Fpharmacie-sante%2Fcomment-larn-messager-pourrait-revolutionner-la-medecine-1314557&usg=AOvVaw0l6lEDW102UGzjROATB-tQ">
							Depistage gratuit</a>

					</h6>
					<div class="post-meta">
						<span class="post-meta-date">
							<i class="far fa-clock"></i>
							depus 2 heures </span>
					</div>
				</div>
			</div>

			<div class="widget-post media">
				<a href="https://www.france24.com/fr/amériques/20210513-face-au-rebond-de-cas-de-covid-19-cuba-accélère-et-vaccine-avant-la-fin-des-essais" class="post-thumb">
					<span data-bg="../assets/img/actu3.jpg" class="rocket-lazyload" style=""></span>
				</a>
				<div class="media-body">

					<h6 class="post-title">
						<a href="">Corona virus</a>

					</h6>
					<div class="post-meta">
						<span class="post-meta-date">
							<i class="far fa-clock"></i>
							depus 2 heures </span>
					</div>
				</div>
			</div>

			<div class="widget-post media">
				<a href="" class="post-thumb">
					<span data-bg="../assets/img/actu2.jpg" class="rocket-lazyload" style=""></span>
				</a>
				<div class="media-body">

					<h6 class="post-title">
						<a href="https://www.france24.com/fr/%C3%A9missions/afrique-hebdo/20210504-cameroun-xaviera-kowo-cr%C3%A9atrice-d-un-robot-capable-de-recycler-les-d%C3%A9chets">Activité scientifique</a>

					</h6>
					<div class="post-meta">
						<span class="post-meta-date">
							<i class="far fa-clock"></i>
							depus 2 heures </span>
					</div>
				</div>
			</div>


		</div>
	</div>


	<div class="col-lg-12">
		<div class="course-sidebar">
			<div class="course-single-info course-widget">
				<h4 class="widget-title">Horaires de visites</h4>
				<div class="course-price-details">
					<div class="course-price">
						<span class="price">Jours ordinaires</span>
					</div>
				</div>
				<div class="course-intro">
					<ul>
						<li class="course-skill-level"> Matin <span>07h00-08h00</span></li>
						<li class="course-duration"> Midi<span> 12h00-14h00</span></li>
						<li class="course-lectures"> Soir <span> 18h00-20h00</span></li>
					</ul>
				</div>

				<div class="course-price-details">
					<div class="course-price">
						<span class="price">Fériés & weekend </span>
					</div>
				</div>
				<div class="course-intro">
					<ul>
						<li class="course-skill-level"> Heure <span>08h00-20h00</span></li>
					</ul>
				</div>

			</div>
		</div>
	</div>


	</div><!-- Sidebar col end -->




	<script type="text/JavaScript">
		function FindNext () {
            var str = document.getElementById ("findField").value;
            if (str == "") {
                alert ("Veillez entrer un text a rechercher!");
                return;
            }

            var supported = false;
            var found = false;
            if (window.find) {        // Firefox, Google Chrome, Safari
                supported = true;
                    // si du contenu est sélectionné, la position de départ de la recherche
                    // sera la position finale de la sélection
                found = window.find (str);
            }
            else {
                if (document.selection && document.selection.createRange) { // Internet Explorer, Opera before version 10.5
                    var textRange = document.selection.createRange ();
                    if (textRange.findText) {   // Internet Explorer
                        supported = true;
                           // si du contenu est sélectionné, la position de départ de la recherche
                    // sera la position finale de la sélection
                        if (textRange.text.length > 0) {
                            textRange.collapse (true);
                            textRange.move ("character", 1);
                        }

                        found = textRange.findText (str);
                        if (found) {
                            textRange.select ();
                        }
                    }
                }
            }

            if (supported) {
                if (!found) {
                    alert ("Le texte suivant n'a pas été trouvé:\n" + str);
                }
            }
            else {
                alert ("Votre navigateur ne supporte pas cet exemple!");
            }
        }
    </script>