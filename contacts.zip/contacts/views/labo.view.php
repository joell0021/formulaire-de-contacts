
	<div id="main-content" class="course-single"  role="main">
	<div id="post-163" class="course-full-width-content post-163 lp_course type-lp_course status-publish has-post-thumbnail hentry course_category-business-management course_category-computer-science course_category-data-science-analytics course_category-learning-management course_category-psychology course_category-software-architecture course_tag-art course_tag-design course_tag-tech ts-skill-label-intermediate course_language-english course" role="main">
	<div class="banner banner-course">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="content-area">
					<div class="course-breadcumb">
						<ol class="breadcrumb" data-wow-duration="2s"><li><a href="../../index.php">Accueil</a></li> <i class="fas fa-chevron-right"></i><li>Services</li>  <i class='fas fa-chevron-right'></i><li>  Laboratoire</li></ol>					</div>
						<h2  class="titre"> Laboratoire </h2>
				</div>
			</div><!-- ./col -->
			<div class="col-lg-6">
				<div class="feature-image">
					
					<div class="thumbnail">
						<img width="730" height="438" src="../assets/img/scan1.png" class="attachment- size- wp-post-image" alt="test" data-lazy-src="../assets/img/scan1.png" />
						<noscript><img width="730" height="438" src="../assets/img/scan1.png" class="attachment- size- wp-post-image" alt="test" />
					</noscript>				
					</div>
				</div>
			</div><!-- ./col -->
		</div><!-- ./row -->
	</div><!-- /.container -->
</div>
<!-- ./course-banner --> 
  
     
<section id="main-content" class="blog main-container" role="main">
	<div class="container">
		<div class="row">
      			<div class="col-lg-8 col-md-12">
								
											<article class="post-322 post type-post status-publish format-standard has-post-thumbnail hentry category-english">
   <div class="post-media post-image">
      
      <a href="#">
        <img class="img-fluid" src="../assets/img/_DSC0391.jpg" alt=" Find the Right Learning Path for your Group Course online" data-lazy-src="../assets/img/_DSC0391.jpg"><noscript>
			<img class="img-fluid" src="../assets/img/_DSC0391.jpg" alt=" Find the Right Learning Path for your Group Course online"></noscript>
      </a>
            
</div>
   
<div class="post-body clearfix">
      <div class="entry-header">
        	
        <h2 class="entry-title titre2">Laboratoire
        </h2>
      </div>
        
      <div class="post-content">
         <div class="entry-content">
			  <p>
				La cardiologie est la spécialité médicale qui étudie le cœur et ses maladies. Le service est composé d'un important secteur d'hospitalisation doté d'une unité spécialisée pour la prise en charge des pathologies cardiaques aiguës. Les examens techniques jouent un rôle primordial pour le diagnostic et la prise en charge des affections cardiaques : ils se divisent en actes non invasifs (échographie cardiaque, épreuves d'effort par exemple) et en actes invasifs principalement les coronarographies. 
			 </p>
			
			
		Activité de dépistage et activité de soins Diagnostic et dépistage d'éventuelles difficultés développementales chez les enfants de 0 à 6 ans. Surveillance des enfants présentant des facteurs de risques développementaux, suivi thérapeutique des touts-petits (0-3 ans).
		 </p>
			 <h3 class="titre3">Pathologies prises en charge:</h3>
			 
				<ul>
					<li>Maladies coronaires : infarctus du myocarde, angine de poitrine </li>
					<li>Insuffisance Cardiaque </li>
					<li>Hypertension artérielle</li>
					<li>Troubles du rythme cardiaque</li>
					<li>Valvulopathies </li>
					<li>Maladies vasculaires veineuses et artérielles</li>
					<li>Cardiomyopathie hypertrophique et amylose cardiaque</li>
				</ul>
				<h3 class="titre3">Techniques utilisées:</h3>
				<ul>
					<li>Coronarographie et angioplastie coronaire</li>
					<li>Pose de stimulateurs et défibrillateurs cardiaques</li>
					<li>Ablation endocavitaire d’arythmies cardiaques (fibrillation auriculaire,…)</li>
					<li>Echographie cardiaque</li>
					<li>Epreuve d’effort</li>
					<li>Holter ECG et tensionnel</li>
					<li>Scanner et IRM cardiaque; ...</li>
				</ul>
			 </p>
			 
         </div>
  
</div>
<!-- post-body end-->       
</article>										
					
												</div><!-- .col-md-8 -->

         
	<div class="col-lg-4 col-md-12">
     <?php
	 include("../views/gauche.view.php")
	 ?>
		</div><!-- .row -->
	</div><!-- .container -->
</section><!-- #main-content -->


