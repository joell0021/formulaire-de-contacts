<section id="main-container" class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <div class="error-page text-center">
                    <div class="error-code">
                        <h2><strong>404</strong></h2>
                    </div>
                    <div class="error-message">
                        <h3>Oops... Page Non Trouvée!</h3>
                    </div>
                    <div class="error-body">
                        Utiliser ce boutton pour revenir à l'accueil du site <br>
                        <a href="../index.php" class="btn btn-primary">Retourner à l'Accueil</a>
                    </div>
                </div>
            </div>
        </div><!-- Content row -->
    </div><!-- Container end -->
</section><!-- Main container end -->