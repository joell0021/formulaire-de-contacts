<?php
include("layout/header1.php");
?>
<div class="
        ekit-template-content-markup
        ekit-template-content-header
        ekit-template-content-theme-support
      ">
  <div data-elementor-type="wp-post" data-elementor-id="138" class="elementor elementor-138" data-elementor-settings="[]">
    <div class="elementor-inner">
      <div class="elementor-section-wrap">
        <section class="
                elementor-section
                elementor-top-section
                elementor-element
                elementor-element-8ba937a
                elementor-section-full_width
                elementor-section-height-default
                elementor-section-height-default
              " data-id="8ba937a" data-element_type="section" data-settings='{"background_background":"classic","ekit_has_onepagescroll_dot":"yes"}' style="background-color:#f14d5d;">
          <div class="elementor-container elementor-column-gap-default container">
            <div class="elementor-row">
              <div class="
                      elementor-column
                      elementor-col-50
                      elementor-top-column
                      elementor-element
                      elementor-element-a5fcde8
                    " data-id="a5fcde8" data-element_type="column">
                <div class="elementor-column-wrap elementor-element-populated">
                  <div class="elementor-widget-wrap">
                    <div class="
                            elementor-element elementor-element-6b930f1
                            top-header-text
                            elementor-widget elementor-widget-text-editor
                          " data-id="6b930f1" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="text-editor.default">
                      <div class="elementor-widget-container">
                        <div class="elementor-text-editor elementor-clearfix"> <b style="font-size: 2.3em; font-weight:bolder">Centre de sante</b>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="
                      elementor-column
                      elementor-col-50
                      elementor-top-column
                      elementor-element
                      elementor-element-361bc0b
                    " data-id="361bc0b" data-element_type="column">
                <div class="elementor-column-wrap elementor-element-populated">
                  <div class="elementor-widget-wrap">
                    <div class="
                            elementor-element
                            elementor-element-31a3327
                            elementor-widget
                            elementor-widget-elementskit-social-media
                          " data-id="31a3327" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-social-media.default">
                      <div class="elementor-widget-container">
                        <div class="ekit-wid-con">
                          <ul class="ekit_social_media">
                            <li class="elementor-repeater-item-0745300">
                              <a href="" class="facebook">
                                <i aria-hidden="true" class="icon icon-facebook"></i>
                              </a>
                            </li>
                            <li class="elementor-repeater-item-b5cd8a5">
                              <a href="" class="1">
                                <i aria-hidden="true" class="icon icon-instagram-1"></i>
                              </a>
                            </li>

                            <li class="elementor-repeater-item-9cd60b5">
                              <a href="" class="twitter">
                                <i aria-hidden="true" class="icon icon-twitter"></i>
                              </a>
                            </li>
                            <li class="elementor-repeater-item-9cd60b5">
                              <select name="category">
                                <option value="lien"> FR </option>
                                <option value="lien">EN</option>
                              </select>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="
                elementor-section
                elementor-top-section
                elementor-element
                elementor-element-db3f74d
                elementor-section-full_width
                cl-main-header
                elementor-section-height-default
                elementor-section-height-default
              " data-id="db3f74d" data-element_type="section" data-settings='{"background_background":"classic","ekit_sticky":"top","ekit_has_onepagescroll_dot":"yes","ekit_sticky_on":["desktop","tablet","mobile"],"ekit_sticky_offset":{"unit":"px","size":0,"sizes":[]},"ekit_sticky_effect_offset":{"unit":"px","size":0,"sizes":[]}}'>
          <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-row">
              <div style="width: 10%" class="
                      elementor-column
                      elementor-col-10
                      elementor-top-column
                      elementor-element
                      elementor-element-3189300
                      hide-search-and--------button
                    " data-id="3189300" data-element_type="column">
                <div class="elementor-column-wrap elementor-element-populated">
                  <div class="elementor-widget-wrap">
                    <div class="
                            elementor-element elementor-element-43eeffd
                            elementor-widget__width-auto
                            elementor-widget elementor-widget-courselog-logo
                          " data-id="43eeffd" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="courselog-logo.default">
                      <div class="elementor-widget-container">
                        <div class="courselog-widget-logo">
                          <a href="index.php">
                            <img src="assets/img/logoprim.jpg" alt="logo" />
                          </a>
                        </div>
                      </div>
                    </div>


                  </div>
                </div>
              </div>


              <div style="width: 90%" class="
                      elementor-column
                      elementor-col-90
                      elementor-top-column
                      elementor-element
                      elementor-element-ac77f67
                      course-log-nav
                    " data-id="ac77f67" data-element_type="column">
                <div class="elementor-column-wrap elementor-element-populated">
                  <div class="elementor-widget-wrap">
                    <div class="
                            elementor-element elementor-element-de707fc
                            elementor-widget__width-auto
                            ts-color-nav
                            elementor-widget elementor-widget-ekit-nav-menu
                          " data-id="de707fc" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="ekit-nav-menu.default">
                      <div class="elementor-widget-container">
                        <div class="ekit-wid-con ekit_menu_responsive_tablet" data-hamburger-icon="icon icon-menu-9" data-hamburger-icon-type="icon" data-responsive-breakpoint="1024">
                          <button class="
                                  elementskit-menu-hamburger
                                  elementskit-menu-toggler
                                ">
                            <i aria-hidden="true" class="ekit-menu-icon icon icon-menu-9"></i>
                          </button>
                          <div id="ekit-megamenu-main-menu" class="
                                  elementskit-menu-container
                                  elementskit-menu-offcanvas-elements
                                  elementskit-navbar-nav-default
                                  elementskit_line_arrow
                                  ekit-nav-menu-one-page-yes
                                ">

                            <ul id="main-menu" class=" elementskit-navbar-nav
                                    elementskit-menu-po-left
                                    submenu-click-on-icon
                                  " style="margin-left: px;">


                              <li id="menu-item-1359" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page
                                      menu-item-has-children
                                      menu-item-1359
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                    " data-vertical-menu="750px">
                                <a href="index.php" class=" ekit-menu-nav-link ">
                                  Accueil
                                </a>
                              </li>
                              <li id="menu-item-1359" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page
                                      menu-item-has-children
                                      menu-item-1359
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                    " data-vertical-menu="750px">
                                <a href="public/labo.php" class=" ekit-menu-nav-link ">
                                  A Propos
                                </a>
                              </li>
                              <!--li diferent large-->
                              <li id="menu-item-1027" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1027 nav-item elementskit-dropdown-has top_position elementskit-dropdown-menu-full_width elementskit-megamenu-has elementskit-mobile-builder-content" data-vertical-menu=""><a href="#" class="ekit-menu-nav-link ekit-menu-dropdown-toggle">
                                Hôpital<i class="icon icon-down-arrow1 elementskit-submenu-indicator"></i></a>

                                <ul class="elementskit-megamenu-panel">
                                  <div data-elementor-type="wp-post" data-elementor-id="8202" class="elementor elementor-8202" data-elementor-settings="[]">
                                    <div class="elementor-inner">
                                      <div class="elementor-section-wrap">
                                        <section class="elementor-section elementor-top-section elementor-element elementor-element-51987094 megamenu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="51987094" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
                                          <div class="elementor-container elementor-column-gap-no">
                                            <div class="elementor-row">
                                              <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5fada50a" data-id="5fada50a" data-element_type="column">
                                                <div class="elementor-column-wrap elementor-element-populated">
                                                  <div class="elementor-widget-wrap">
                                                    <section class="elementor-section elementor-inner-section elementor-element elementor-element-e857c1e elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="e857c1e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
                                                      <div class="elementor-container elementor-column-gap-no">
                                                        <div class="elementor-row">
                                                          <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-56011e30" data-id="56011e30" data-element_type="column">
                                                            <div class="elementor-column-wrap elementor-element-populated">
                                                              <div class="elementor-widget-wrap">
                                                                <div class="elementor-element elementor-element-8f0e9b6 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="8f0e9b6" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <!-- link opening -->
                                                                      <!-- end link opening -->

                                                                      <div class="elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media  ">
                                                                        <div class="elementskit-box-header elementor-animation-">
                                                                          <div class="elementskit-info-box-icon  text-center">
                                                                            <i aria-hidden="true" class="elementkit-infobox-icon fas fa-clipboard-list"></i>
                                                                          </div>
                                                                        </div>
                                                                        <div class="box-body">
                                                                          <h3 class="elementskit-info-box-title">
                                                                            CHP/GSA </h3>
                                                                        </div>


                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-18c1e897 elementor-widget elementor-widget-elementskit-page-list" data-id="18c1e897" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <div class="elementor-icon-list-items ">
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="public/labo.php" class="elementor-repeater-item-ac26393 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Equipe médicale</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>


                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-c8da05e ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Plateau technique</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-46b5541 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Sous tire2</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-395176d ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Sous tire3</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3ecb29ae" data-id="3ecb29ae" data-element_type="column">
                                                            <div class="elementor-column-wrap elementor-element-populated">
                                                              <div class="elementor-widget-wrap">
                                                                <div class="elementor-element elementor-element-575857d3 elementor-widget elementor-widget-elementskit-page-list" data-id="575857d3" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <div class="elementor-icon-list-items ">
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-ac26393 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Sous tire1 </span>
                                                                              </span>
                                                                            </div>
                                                                            <span class="ekit_menu_label">
                                                                              new </span>
                                                                          </a>
                                                                        </div>
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-03dccb7 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Sous tire2</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="public/faq.php" class="elementor-repeater-item-b1ac949 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">FAQs</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="public/picture.php" class="elementor-repeater-item-39d3f42 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Médiathèque</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-5daf1d7d" data-id="5daf1d7d" data-element_type="column">
                                                            <div class="elementor-column-wrap elementor-element-populated">
                                                              <div class="elementor-widget-wrap">
                                                                <div class="elementor-element elementor-element-1a314d48 ekit-equal-height-disable elementor-widget elementor-widget-elementskit-icon-box" data-id="1a314d48" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-icon-box.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <!-- link opening -->
                                                                      <!-- end link opening -->

                                                                      <div class="elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media  ">
                                                                        <div class="elementskit-box-header elementor-animation-">
                                                                          <div class="elementskit-info-box-icon  text-center">
                                                                            <i aria-hidden="true" class="elementkit-infobox-icon fas fa-bolt"></i>
                                                                          </div>
                                                                        </div>
                                                                        <div class="box-body">
                                                                          <h3 class="elementskit-info-box-title">
                                                                            Patient
                                                                          </h3>
                                                                        </div>


                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-b2e5cd9 elementor-widget elementor-widget-elementskit-page-list" data-id="b2e5cd9" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <div class="elementor-icon-list-items ">
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-ac26393 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Hospitalisation</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>

                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-28aef60 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Mon séjours </span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>


                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-4cde5f1 ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Règlementation</span>
                                                                              </span>
                                                                            </div>
                                                                            <span class="ekit_menu_label">
                                                                              Hot </span>
                                                                          </a>
                                                                        </div>
                                                                        <div class="elementor-icon-list-item   ">
                                                                          <a target=_self rel="" href="#" class="elementor-repeater-item-ee4320f ekit_badge_left">
                                                                            <div class="ekit_page_list_content">
                                                                              <span class="elementor-icon-list-text">
                                                                                <span class="ekit_page_list_title_title">Assurances</span>
                                                                              </span>
                                                                            </div>
                                                                          </a>
                                                                        </div>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                          <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6a8d2bc1" data-id="6a8d2bc1" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                            <div class="elementor-column-wrap elementor-element-populated">
                                                              <div class="elementor-background-overlay"></div>
                                                              <div class="elementor-widget-wrap">
                                                                <div class="elementor-element elementor-element-72e92a1c elementor-widget elementor-widget-elementskit-heading" data-id="72e92a1c" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                                                        <h3 class="ekit-heading--title elementskit-section-title ">
                                                                          Informations Corona virus
                                                                        </h3>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                                <div class="elementor-element elementor-element-45e88c48 elementor-widget elementor-widget-elementskit-button" data-id="45e88c48" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-button.default">
                                                                  <div class="elementor-widget-container">
                                                                    <div class="ekit-wid-con">
                                                                      <div class="ekit-btn-wraper">
                                                                        <a href="p" class="elementskit-btn  whitespace--normal">
                                                                          cliquez ici! </a>
                                                                      </div>
                                                                    </div>
                                                                  </div>
                                                                </div>
                                                              </div>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </section>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </section>
                                      </div>
                                    </div>
                                  </div>
                                </ul>
                              </li>
                              <!--en li large-->

                              <li id="menu-item-8098" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page menu-item-home
                                      current-menu-item
                                      page_item page-item-5
                                      current_page_item
                                      current-menu-ancestor
                                      current-menu-parent
                                      current_page_parent
                                      current_page_ancestor
                                      menu-item-has-children menu-item-8098
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                      active
                                    " data-vertical-menu="750px">
                                <a href="#" class="
                                        ekit-menu-nav-link
                                        ekit-menu-dropdown-toggle
                                      ">Services<i class="
                                          icon icon-down-arrow1
                                          elementskit-submenu-indicator
                                        "></i></a>
                                <ul class="
                                        elementskit-dropdown
                                        elementskit-submenu-panel
                                      ">
                                  <li id="menu-item-11" class="
                                          menu-item
                                          menu-item-type-post_type
                                          menu-item-object-page menu-item-home
                                          current-menu-item
                                          page_item page-item-5
                                          current_page_item
                                          menu-item-11
                                          nav-item
                                          elementskit-mobile-builder-content
                                          active
                                        " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item active" style="color: red;">
                                      <i class=" ekit-menu-icon icon icon-list-2 " style="color: #2878eb"></i>
                                      Urgences/Ambulances</a>


                                  </li>
                                  <li id="menu-item-8100" class="
                                          menu-item
                                          menu-item-type-post_type
                                          menu-item-object-page menu-item-8100
                                          nav-item
                                          elementskit-mobile-builder-content
                                        " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item">Laboratoire</a>
                                  </li>
                                  <li id="menu-item-8099" class="
                                          menu-item
                                          menu-item-type-post_type
                                          menu-item-object-page menu-item-8099
                                          nav-item
                                          elementskit-mobile-builder-content
                                        " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item">Imagerie</a>
                                  </li>
                                  <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item">
                                      Neurochirurgie </a>
                                  </li>
                                  <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item">cardiologie </a>
                                  </li>
                                  <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item">Gynécologie/Obstétrique </a>
                                  </li>
                                  <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item">Kinésithérapie </a>
                                  </li>
                                  <li id="menu-item-9709" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-9709 nav-item elementskit-mobile-builder-content " data-vertical-menu="750px">
                                    <a href="public/labo.php" class="dropdown-item"> Services à venir </a>
                                  </li>
                                </ul>
                              </li>

                              <li id="menu-item-1359" class="
                                      menu-item
                                      menu-item-type-post_type
                                      menu-item-object-page
                                      menu-item-has-children
                                      menu-item-1359
                                      nav-item
                                      elementskit-dropdown-has
                                      relative_position
                                      elementskit-dropdown-menu-default_width
                                      elementskit-mobile-builder-content
                                    " data-vertical-menu="750px">
                                <a href="public/contact.php" class=" ekit-menu-nav-link ">
                                  Contacts
                                </a>
                              </li>


                            </ul>
                            <div class="elementskit-nav-identity-panel">

                              <button class="
                                      elementskit-menu-close
                                      elementskit-menu-toggler
                                    " type="button">
                                X
                              </button>
                            </div>
                          </div>
                          <div class="
                                  elementskit-menu-overlay
                                  elementskit-menu-offcanvas-elements
                                  elementskit-menu-toggler
                                  ekit-nav-menu--overlay
                                "></div>
                        </div>
                      </div>
                    </div>
                    <div class=" elementor-element elementor-element-5011564 elementor-widget__width-auto
                            elementor-hidden-tablet
                            elementor-hidden-phone
                            elementor-widget
                            elementor-widget-elementskit-button
                          " data-id="5011564" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-button.default">

                    </div>
                    <div class="
                            elementor-element elementor-element-3ba9b96
                            elementor-widget__width-auto
                            elementor-widget
                            elementor-widget-courselog-userlogin
                          " data-id="3ba9b96" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="courselog-userlogin.default">
                      <div class="elementor-widget-container">
                        <div class="
                            elementor-element elementor-element-3ba9b96
                            elementor-widget__width-auto
                            elementor-widget
                            elementor-widget-courselog-userlogin
                          " data-id="3ba9b96" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="courselog-userlogin.default">
                          <div class="elementor-widget-container">
                            <div class="elementskit-site-title">
                              <a class="elementskit-nav-logo" href="index.php" target="_self">
                                <img src="" alt="logoprim" data-lazy-src="assets/img/logo.jpg" />
                                <noscript>
                                  <img src="assets/img/logo.jpg" alt="logo " />
                                </noscript>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</div>


<div data-elementor-type="wp-page" data-elementor-id="10156" class="elementor elementor-10156" data-elementor-settings="[]">
  <div class="elementor-inner">
    <div class="elementor-section-wrap">
      <section class="elementor-section elementor-top-section elementor-element elementor-element-dd5bde0 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="dd5bde0" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
        <div class="elementor-container elementor-column-gap-no">
          <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-c95604f" data-id="c95604f" data-element_type="column">
              <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                  <div class="elementor-element elementor-element-99150d1 elementor-widget elementor-widget-courselog-main-slider" data-id="99150d1" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="courselog-main-slider.default">
                    <div class="elementor-widget-container">
                      <div class="hero-area main-slider main-slider-style1 owl-carousel owl-theme" data-controls="{&quot;show_nav&quot;:false,&quot;dot_nav_show&quot;:&quot;yes&quot;,&quot;auto_nav_slide&quot;:&quot;yes&quot;,&quot;ts_slider_speed&quot;:5000}">

                        <div class="banner-item" style=background-image:url(wp-content/uploads/2021/03/slider-image1.jpg)>
                          <div class="container">
                            <div class="row align-items-center ">
                              <div class="col-lg-8 mr-auto">
                                <div class="slider-content mr-auto">
                                  <h1 class="main-title ts-animate">

                                    beieeuu dbegge de titre <span>avec titre</span>
                                  </h1>

                                  <p class="sub-title ts-animate">
                                  </p>
                                  <div class="btn-wrapper ts-animate">
                                    <a target="_self" href="../courses/index.html" class="btn">
                                      Service1 </a>

                                    <a target="_self" href="../register/index.html" class="btn btn-border">
                                      Service2 </a>

                                  </div>
                                  <p class="slider-desc ts-animate">
                                    545,jdjdjjjdjjjjjjjjjjjjsssssssssssssss </p>
                                </div><!-- Slider content end -->
                              </div><!-- col end-->

                            </div><!-- row end-->
                          </div>
                          <!-- Container end -->
                        </div>
                        <!-- end  banner item -->


                        <div class="banner-item" style=background-image:url(wp-content/uploads/2021/03/slider-image2.jpg)>
                          <div class="container">
                            <div class="row align-items-center ">
                              <div class="col-lg-8 mr-auto">
                                <div class="slider-content mr-auto">
                                  <h1 class="main-title ts-animate">

                                    beieeuu dbegge de <span>avec titre</span>
                                  </h1>

                                  <p class="sub-title ts-animate">
                                  </p>
                                  <div class="btn-wrapper ts-animate">
                                    <a target="_self" href="../courses/index.html" class="btn">
                                      Autre service </a>

                                    <a target="_self" href="../register/index.html" class="btn btn-border">
                                      titre serv </a>

                                  </div>
                                  <p class="slider-desc ts-animate">
                                    1dhhhhhhhhhhhhhhhhhhhh.hdhdg </p>
                                </div><!-- Slider content end -->
                              </div><!-- col end-->

                            </div><!-- row end-->
                          </div>
                          <!-- Container end -->
                        </div>
                        <!-- end  banner item -->


                        <div class="banner-item" style=background-image:url(wp-content/uploads/2021/03/slider-image3.jpg)>
                          <div class="container">
                            <div class="row align-items-center ">
                              <div class="col-lg-8 mr-auto">
                                <div class="slider-content mr-auto">
                                  <h1 class="main-title ts-animate">
                                    beieeuu dbegge de titre <span>avec titre</span>
                                  </h1>
                                  <div class="btn-wrapper ts-animate">
                                    <a target="_self" href="../courses/index.html" class="btn">
                                      text
                                    </a>
                                    <a target="_self" href="../register/index.html" class="btn btn-border">
                                      testtf
                                    </a>

                                  </div>
                                  <p class="slider-desc ts-animate">
                                    545,716 people are learning on Courselog today. </p>
                                </div><!-- Slider content end -->
                              </div><!-- col end-->

                            </div><!-- row end-->
                          </div>
                          <!-- Container end -->
                        </div>
                        <!-- end  banner item -->


                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</div>


<section class="elementor-section elementor-top-section elementor-element elementor-element-62c3fd6 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="62c3fd6" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
  <div class="elementor-container elementor-column-gap-default">
    <div class="elementor-row">
      <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-babe388" data-id="babe388" data-element_type="column">
        <div class="elementor-column-wrap elementor-element-populated">
          <div class="elementor-widget-wrap">
            <div class="elementor-element elementor-element-3c7723c elementor-widget elementor-widget-elementskit-heading" data-id="3c7723c" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
              <div class="elementor-widget-container">
                <div class="ekit-wid-con">
                  <div class="ekit-heading elementskit-section-title-wraper text_center   ekit_heading_tablet-   ekit_heading_mobile-">
                    <h2 class="ekit-heading--title elementskit-section-title ">
                      Evènnements recents.
                    </h2>
                  </div>
                </div>
              </div>
            </div>
            <div class="elementor-element elementor-element-91146c2 woo-courselog-event elementor-widget elementor-widget-etn-event" data-id="91146c2" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="etn-event.default">
              <div class="elementor-widget-container">
                <div class='etn-row etn-event-wrapper'>
                  <div class="etn-col-md-6 etn-col-lg-4">
                    <div class="etn-event-item">
                      <!-- thumbnail -->
                      <div class="etn-event-thumb">
                        <a href="">
                          <img src="assets/img/actu1.jpg" data-lazy-src="assets/img/actu1.jpg">
                          <noscript><img src="assets/img/actu1.jpg" alt="actualité"></noscript>
                        </a>
                        <div class="etn-event-category">
                          <span>medecine</span> <span>vaccin</span>
                        </div>
                      </div>
                      <!-- thumbnail start-->

                      <!-- content start-->
                      <div class="etn-event-content">
                        <div class="etn-event-location"><i class="fas fa-map-marker-alt"></i> Pays, Ville, lieu</div>
                        <h3 class="etn-title etn-event-title">
                          <a href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=newssearch&cd=&cad=rja&uact=8&ved=0ahUKEwj2rZXe2cbwAhWQxIUKHWe5CkkQxfQBCDowAQ&url=https%3A%2F%2Fwww.lesechos.fr%2Findustrie-services%2Fpharmacie-sante%2Fcomment-larn-messager-pourrait-revolutionner-la-medecine-1314557&usg=AOvVaw0l6lEDW102UGzjROATB-tQ">
                            Prise en charge des patients</a>
                        </h3>
                        <div class="etn-event-footer">
                          <div class="etn-event-date">
                            <i class="far fa-calendar-alt"></i>
                            14/07/2021
                          </div>
                          <div class="etn-atend-btn">
                            <a href="" class="etn-btn etn-btn-border">plus <i class="fas fa-arrow-right"></i></a>
                          </div>
                        </div>
                      </div>
                      <!-- content end-->
                    </div>
                    <!-- etn event item end-->
                  </div>
                  <div class="etn-col-md-6 etn-col-lg-4">
                    <div class="etn-event-item">
                      <!-- thumbnail -->
                      <div class="etn-event-thumb">
                        <a href="https://www.france24.com/fr/amériques/20210513-face-au-rebond-de-cas-de-covid-19-cuba-accélère-et-vaccine-avant-la-fin-des-essais">
                          <img src="assets/img/actu4.jpg" alt="actuallite" data-lazy-src="assets/img/actu4.jpg">
                          <noscript><img src="assets/img/actu4.jpg" alt=""></noscript>
                        </a>
                        <div class="etn-event-category">
                          <span>Education</span>
                        </div>
                      </div>
                      <!-- thumbnail start-->

                      <!-- content start-->
                      <div class="etn-event-content">
                        <div class="etn-event-location"><i class="fas fa-map-marker-alt"></i> Pays, Ville, lieu</div>
                        <h3 class="etn-title etn-event-title"><a href=""> Titre ou resumé de l'actualité</a> </h3>
                        <p></p>
                        <div class="etn-event-footer">
                          <div class="etn-event-date">
                            <i class="far fa-calendar-alt"></i>
                            14/07/2021
                          </div>
                          <div class="etn-atend-btn">
                            <a href="" class="etn-btn etn-btn-border"> plus <i class="fas fa-arrow-right"></i></a>
                          </div>
                        </div>
                      </div>
                      <!-- content end-->
                    </div>
                    <!-- etn event item end-->
                  </div>
                  <div class="etn-col-md-6 etn-col-lg-4">
                    <div class="etn-event-item">
                      <!-- thumbnail -->
                      <div class="etn-event-thumb">
                        <a href="">
                          <img src="assets/img/menu2.jpg" alt="" data-lazy-src="assets/img/menu2.jpg"><noscript><img src="assets/img/menu2.jpg" alt=""></noscript>
                        </a>
                        <div class="etn-event-category">
                          <span>Activité scientifique</span>
                        </div>
                      </div>
                      <!-- thumbnail start-->

                      <!-- content start-->
                      <div class="etn-event-content">
                        <div class="etn-event-location"><i class="fas fa-map-marker-alt"></i> Pays, ville, lieu</div>
                        <h3 class="etn-title etn-event-title"><a href="">Titre ou resumé de l'actualité</a> </h3>
                        <p></p>
                        <div class="etn-event-footer">
                          <div class="etn-event-date">
                            <i class="far fa-calendar-alt"></i>
                            14/01/2023
                          </div>
                          <div class="etn-atend-btn">
                            <a href="https://www.france24.com/fr/%C3%A9missions/afrique-hebdo/20210504-cameroun-xaviera-kowo-cr%C3%A9atrice-d-un-robot-capable-de-recycler-les-d%C3%A9chets" class="etn-btn etn-btn-border">
                              plus <i class="fas fa-arrow-right"></i></a>
                          </div>
                        </div>
                      </div>
                      <!-- content end-->
                    </div>
                    <!-- etn event item end-->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<br><br><br>

<div data-elementor-type="wp-page" data-elementor-id="5" class="elementor elementor-5 " data-elementor-settings="[]">
  <div class="elementor-inner">
    <div class="elementor-section-wrap">

      <section class="
              elementor-section
              elementor-top-section
              elementor-element
              elementor-element-862cc1f
              section-half
              elementor-section-boxed
              elementor-section-height-default
              elementor-section-height-default
            " data-id="862cc1f" data-element_type="section">
        <div class="elementor-container elementor-column-gap-default">
          <div class="elementor-row">
            <div class="
                    elementor-column
                    elementor-col-50
                    elementor-top-column
                    elementor-element
                    elementor-element-b2c634d
                  " data-id="b2c634d" data-element_type="column">
              <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                  <div class="
                          elementor-element
                          elementor-element-9b8f04e
                          elementor-widget
                          elementor-widget-elementskit-heading
                        " data-id="9b8f04e" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-heading.default">
                    <div class="elementor-widget-container">
                      <div class="ekit-wid-con">
                        <div class="
                                ekit-heading
                                elementskit-section-title-wraper
                                text_left
                                ekit_heading_tablet- ekit_heading_mobile-
                              ">
                          <h2 class="
                                  ekit-heading--title
                                  elementskit-section-title
                                ">
                            Pourquoi nous choisir?
                          </h2>
                          <div class="ekit-heading__description">
                            <p>

                              Notre equipe pluri-professionnelle pour permettre une prise en charge de toutes les situations des patients.
                              Assure le parcours des patients dès leurs conditions d’arrivée jusqu’aux suites.

                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="
                          elementor-element
                          elementor-element-8b34343
                          elementor-widget
                          elementor-widget-elementskit-button
                        " data-id="8b34343" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-button.default">
                    <div class="elementor-widget-container">
                      <div class="ekit-wid-con">
                        <div class="ekit-btn-wraper">
                          <a href="#" class="elementskit-btn whitespace--normal">
                            Voir la gallerie
                            <i aria-hidden="true" class="tsicon tsicon-right_arrow"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="
                    elementor-column
                    elementor-col-50
                    elementor-top-column
                    elementor-element
                    elementor-element-1c33e01
                    journey-feature
                  " data-id="1c33e01" data-element_type="column" data-settings='{"background_background":"classic"}'>
              <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                  <section class="
                          elementor-section
                          elementor-inner-section
                          elementor-element
                          elementor-element-4d6889b
                          elementor-section-boxed
                          elementor-section-height-default
                          elementor-section-height-default
                        " data-id="4d6889b" data-element_type="section" data-settings='{"ekit_has_onepagescroll_dot":"yes"}'>
                    <div class="
                            elementor-container elementor-column-gap-default
                          ">
                      <div class="elementor-row">
                        <div class="
                                elementor-column
                                elementor-col-50
                                elementor-inner-column
                                elementor-element
                                elementor-element-70a29a4
                              " data-id="70a29a4" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-7b19908
                                      elementor-view-stacked
                                      elementor-position-left
                                      elementor-vertical-align-middle
                                      elementor-shape-circle
                                      elementor-widget
                                      elementor-widget-icon-box
                                    " data-id="7b19908" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-box-wrapper">
                                    <div class="elementor-icon-box-icon">
                                      <span class="
                                              elementor-icon
                                              elementor-animation-
                                            ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="33" height="35.324" viewBox="0 0 33 35.324">
                                          <g id="faeture_icon1" transform="translate(-3 -2)">
                                            <path id="Path_473" data-name="Path 473" d="M16.038,2,6.5,17.608H25.577Z" transform="translate(2.57)" fill="#1dc295"></path>
                                            <circle id="Ellipse_72" data-name="Ellipse 72" cx="8" cy="8" r="8" transform="translate(20 21.324)" fill="#1dc295"></circle>
                                            <path id="Path_474" data-name="Path 474" d="M3,13.5H16.874V27.374H3Z" transform="translate(0 8.444)" fill="#1dc295"></path>
                                          </g>
                                        </svg>
                                      </span>
                                    </div>
                                    <div class="elementor-icon-box-content">
                                      <h3 class="elementor-icon-box-title">
                                        <span>Prise en charge des patients</span>
                                      </h3>
                                      <p class="
                                              elementor-icon-box-description
                                            ">
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="
                                elementor-column
                                elementor-col-50
                                elementor-inner-column
                                elementor-element
                                elementor-element-4ef7388
                              " data-id="4ef7388" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-b5c3470
                                      elementor-view-stacked
                                      elementor-position-left
                                      elementor-vertical-align-middle
                                      elementor-shape-circle
                                      elementor-widget
                                      elementor-widget-icon-box
                                    " data-id="b5c3470" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-box-wrapper">
                                    <div class="elementor-icon-box-icon">
                                      <span class="
                                              elementor-icon
                                              elementor-animation-
                                            ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="23" height="28" viewBox="0 0 23 28">
                                          <path id="faeture_icon2" d="M20.588,3.882H14.016V-6H4.16V3.882H-2.412l11.5,11.53Zm-23,14.823V22h23V18.706Z" transform="translate(2.412 6)" fill="#6857ff"></path>
                                        </svg>
                                      </span>
                                    </div>
                                    <div class="elementor-icon-box-content">
                                      <h3 class="elementor-icon-box-title">
                                        <span>La recherche </span>
                                      </h3>
                                      <p class="
                                              elementor-icon-box-description
                                            ">
                                        La recherche
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                  <section class="
                          elementor-section
                          elementor-inner-section
                          elementor-element
                          elementor-element-11a767d
                          elementor-section-boxed
                          elementor-section-height-default
                          elementor-section-height-default
                        " data-id="11a767d" data-element_type="section" data-settings='{"ekit_has_onepagescroll_dot":"yes"}'>
                    <div class="
                            elementor-container elementor-column-gap-default
                          ">
                      <div class="elementor-row">
                        <div class="
                                elementor-column
                                elementor-col-50
                                elementor-inner-column
                                elementor-element
                                elementor-element-c89bb6d
                              " data-id="c89bb6d" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-99ff428
                                      elementor-view-stacked
                                      elementor-position-left
                                      elementor-vertical-align-middle
                                      elementor-shape-circle
                                      elementor-widget
                                      elementor-widget-icon-box
                                    " data-id="99ff428" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-box-wrapper">
                                    <div class="elementor-icon-box-icon">
                                      <span class="
                                              elementor-icon
                                              elementor-animation-
                                            ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20.571" height="24" viewBox="0 0 20.571 24">
                                          <path id="faeture_icon3" d="M6,29h6.857V5H6ZM19.714,5V29h6.857V5Z" transform="translate(-6 -5)" fill="#f14d5d"></path>
                                        </svg>
                                      </span>
                                    </div>
                                    <div class="elementor-icon-box-content">
                                      <h3 class="elementor-icon-box-title">
                                        <span>Notre equipe</span>
                                      </h3>
                                      <p class="
                                              elementor-icon-box-description
                                            ">
                                        Notre equipe
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="
                                elementor-column
                                elementor-col-50
                                elementor-inner-column
                                elementor-element
                                elementor-element-1f8a3c9
                              " data-id="1f8a3c9" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-43b6ad8
                                      elementor-view-stacked
                                      elementor-position-left
                                      elementor-vertical-align-middle
                                      elementor-shape-circle
                                      elementor-widget
                                      elementor-widget-icon-box
                                    " data-id="43b6ad8" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="icon-box.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-box-wrapper">
                                    <div class="elementor-icon-box-icon">
                                      <span class="
                                              elementor-icon
                                              elementor-animation-
                                            ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="35.312" height="31.781" viewBox="0 0 35.312 31.781">
                                          <g id="faeture_icon4" transform="translate(-2 -3)">
                                            <g id="Group_598" data-name="Group 598" transform="translate(2 3)">
                                              <path id="Path_477" data-name="Path 477" d="M35.546,19.279a15.9,15.9,0,1,0-31.781.106A3.474,3.474,0,0,0,2,22.422v3.531a3.542,3.542,0,0,0,3.531,3.531H7.3V18.714a12.359,12.359,0,0,1,24.718,0V31.25H17.89v3.531H32.015a3.542,3.542,0,0,0,3.531-3.531V29.1a3.264,3.264,0,0,0,1.766-2.9V22.139A3.251,3.251,0,0,0,35.546,19.279Z" transform="translate(-2 -3)" fill="#f5ac00"></path>
                                              <circle id="Ellipse_76" data-name="Ellipse 76" cx="1.638" cy="1.638" r="1.638" transform="translate(11.102 15.89)" fill="#f5ac00"></circle>
                                              <circle id="Ellipse_77" data-name="Ellipse 77" cx="1.638" cy="1.638" r="1.638" transform="translate(20.933 15.89)" fill="#f5ac00"></circle>
                                              <path id="Path_478" data-name="Path 478" d="M27.183,14.881A10.663,10.663,0,0,0,6.031,17.388a14.257,14.257,0,0,0,8.581-10.4A14.19,14.19,0,0,0,27.183,14.881Z" transform="translate(1.067 -0.703)" fill="#f5ac00"></path>
                                            </g>
                                          </g>
                                        </svg>
                                      </span>
                                    </div>
                                    <div class="elementor-icon-box-content">
                                      <h3 class="elementor-icon-box-title">
                                        <span>Soins et A ssistance </span>
                                      </h3>
                                      <p class="
                                              elementor-icon-box-description
                                            ">
                                        Soins et A ssistance
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="
                                      elementor-element
                                      elementor-element-6862dc6
                                      elementor-absolute
                                      elementor-hidden-tablet
                                      elementor-hidden-phone
                                      parallax-star
                                      elementor-view-default
                                      elementor-widget
                                      elementor-widget-icon
                                    " data-id="6862dc6" data-element_type="widget" data-settings='{"ekit_we_effect_on":"css","_position":"absolute"}' data-widget_type="icon.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-wrapper">
                                    <div class="elementor-icon">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="20.097" height="19.953" viewBox="0 0 20.097 19.953">
                                        <path id="shape4" d="M18.45,14.082a7.975,7.975,0,0,1-6.48-6.336A1.861,1.861,0,0,0,9.81,6.019,2,2,0,0,0,8.226,7.6a8.136,8.136,0,0,1-6.48,6.48,2.069,2.069,0,0,0-1.728,2.3A2,2,0,0,0,1.6,17.97a7.975,7.975,0,0,1,6.48,6.336,1.868,1.868,0,0,0,2.3,1.584,2,2,0,0,0,1.584-1.584,7.637,7.637,0,0,1,6.48-6.336,1.868,1.868,0,0,0,1.584-2.3A1.828,1.828,0,0,0,18.45,14.082Z" transform="translate(0 -6)" fill="#f14d5d"></path>
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="
                                      elementor-element
                                      elementor-element-6b86888
                                      elementor-absolute
                                      elementor-hidden-tablet
                                      elementor-hidden-phone
                                      parallax-star
                                      elementor-view-default
                                      elementor-widget
                                      elementor-widget-icon
                                    " data-id="6b86888" data-element_type="widget" data-settings='{"ekit_we_effect_on":"css","_position":"absolute"}' data-widget_type="icon.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-wrapper">
                                    <div class="elementor-icon">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="9.725" height="9.656" viewBox="0 0 9.725 9.656">
                                        <path id="shape6" d="M8.928,9.911A3.859,3.859,0,0,1,5.793,6.845a.9.9,0,0,0-1.045-.836.966.966,0,0,0-.766.766A3.937,3.937,0,0,1,.845,9.911a1,1,0,0,0-.836,1.115.966.966,0,0,0,.766.766,3.859,3.859,0,0,1,3.136,3.066.9.9,0,0,0,1.115.766.966.966,0,0,0,.766-.766,3.7,3.7,0,0,1,3.136-3.066.9.9,0,0,0,.766-1.115A.884.884,0,0,0,8.928,9.911Z" transform="translate(0 -6)" fill="#f5ac00"></path>
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="
                                      elementor-element
                                      elementor-element-e030cbc
                                      elementor-absolute
                                      elementor-hidden-tablet
                                      elementor-hidden-phone
                                      parallax-star
                                      elementor-view-default
                                      elementor-widget
                                      elementor-widget-icon
                                    " data-id="e030cbc" data-element_type="widget" data-settings='{"ekit_we_effect_on":"css","_position":"absolute"}' data-widget_type="icon.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-icon-wrapper">
                                    <div class="elementor-icon">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13">
                                        <path id="shape5" d="M11.935,11.266A5.176,5.176,0,0,1,7.743,7.138a1.206,1.206,0,0,0-1.4-1.126A1.3,1.3,0,0,0,5.321,7.044,5.282,5.282,0,0,1,1.13,11.266a1.346,1.346,0,0,0-1.118,1.5A1.3,1.3,0,0,0,1.037,13.8a5.176,5.176,0,0,1,4.192,4.128,1.209,1.209,0,0,0,1.49,1.032,1.3,1.3,0,0,0,1.025-1.032A4.957,4.957,0,0,1,11.935,13.8a1.217,1.217,0,0,0,1.025-1.5A1.187,1.187,0,0,0,11.935,11.266Z" transform="translate(0 -6)" fill="#2878eb"></path>
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="
              elementor-section
              elementor-top-section
              elementor-element
              elementor-element-3574274
              elementor-section-boxed
              elementor-section-height-default
              elementor-section-height-default
            " data-id="3574274" data-element_type="section" data-settings='{"ekit_has_onepagescroll_dot":"yes"}'>
        <div class="elementor-container elementor-column-gap-default">
          <div class="elementor-row">
            <div class="
                    elementor-column
                    elementor-col-100
                    elementor-top-column
                    elementor-element
                    elementor-element-0cbe9bb
                  " data-id="0cbe9bb" data-element_type="column">
              <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                  <div class="
                          elementor-element
                          elementor-element-9c60ba7
                          elementor-widget
                          elementor-widget-elementskit-heading
                        " data-id="9c60ba7" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-heading.default">
                    <div class="elementor-widget-container">
                      <div class="ekit-wid-con">
                        <div class="
                                ekit-heading
                                elementskit-section-title-wraper
                                text_center
                                ekit_heading_tablet- ekit_heading_mobile-
                              ">
                          <h2 class="
                                  ekit-heading--title
                                  elementskit-section-title
                                ">
                            Nos chiffres
                          </h2>
                        </div>
                      </div>
                    </div>
                  </div>
                  <section class="
                          elementor-section
                          elementor-inner-section
                          elementor-element
                          elementor-element-ab9877b
                          elementor-section-boxed
                          elementor-section-height-default
                          elementor-section-height-default
                        " data-id="ab9877b" data-element_type="section" data-settings='{"ekit_has_onepagescroll_dot":"yes"}'>
                    <div class="
                            elementor-container elementor-column-gap-default
                          ">
                      <div class="elementor-row">
                        <div class="
                                elementor-column
                                elementor-col-25
                                elementor-inner-column
                                elementor-element
                                elementor-element-21fc94c
                              " data-id="21fc94c" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-ed61fe5
                                      elementor-widget
                                      elementor-widget-counter
                                    " data-id="ed61fe5" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="counter.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-counter">
                                    <div class="
                                            elementor-counter-number-wrapper
                                          ">
                                      <span class="
                                              elementor-counter-number-prefix
                                            "></span>
                                      <span class="elementor-counter-number" data-duration="2000" data-to-value="100" data-from-value="0" data-delimiter=",">0</span>
                                      <span class="
                                              elementor-counter-number-suffix
                                            ">+</span>
                                    </div>
                                    <div class="elementor-counter-title">
                                      lits
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="
                                elementor-column
                                elementor-col-25
                                elementor-inner-column
                                elementor-element
                                elementor-element-49a7906
                              " data-id="49a7906" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-15a3bff
                                      elementor-widget
                                      elementor-widget-counter
                                    " data-id="15a3bff" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="counter.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-counter">
                                    <div class="
                                            elementor-counter-number-wrapper
                                          ">
                                      <span class="
                                              elementor-counter-number-prefix
                                            "></span>
                                      <span class="elementor-counter-number" data-duration="2000" data-to-value="06" data-from-value="0" data-delimiter=",">0</span>
                                      <span class="
                                              elementor-counter-number-suffix
                                            "></span>
                                    </div>
                                    <div class="elementor-counter-title">
                                      Suites VIP
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="
                                elementor-column
                                elementor-col-25
                                elementor-inner-column
                                elementor-element
                                elementor-element-b99a38d
                              " data-id="b99a38d" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-b040f19
                                      elementor-widget
                                      elementor-widget-counter
                                    " data-id="b040f19" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="counter.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-counter">
                                    <div class="
                                            elementor-counter-number-wrapper
                                          ">
                                      <span class="
                                              elementor-counter-number-prefix
                                            "></span>
                                      <span class="elementor-counter-number" data-duration="2000" data-to-value="7" data-from-value="0" data-delimiter=",">0</span>
                                      <span class="
                                              elementor-counter-number-suffix
                                            "></span>
                                    </div>
                                    <div class="elementor-counter-title">
                                      Salles d’opérations
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="
                                elementor-column
                                elementor-col-25
                                elementor-inner-column
                                elementor-element
                                elementor-element-4d8d349
                              " data-id="4d8d349" data-element_type="column">
                          <div class="
                                  elementor-column-wrap
                                  elementor-element-populated
                                ">
                            <div class="elementor-widget-wrap">
                              <div class="
                                      elementor-element
                                      elementor-element-e106d63
                                      elementor-widget
                                      elementor-widget-counter
                                    " data-id="e106d63" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="counter.default">
                                <div class="elementor-widget-container">
                                  <div class="elementor-counter">
                                    <div class="
                                            elementor-counter-number-wrapper
                                          ">
                                      <span class="
                                              elementor-counter-number-prefix
                                            "></span>
                                      <span class="elementor-counter-number" data-duration="2000" data-to-value="1" data-from-value="0" data-delimiter=",">0</span>
                                      <span class="
                                              elementor-counter-number-suffix
                                            "></span>
                                    </div>
                                    <div class="elementor-counter-title">
                                      Centre de formation
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <br><br>

      <section class="elementor-section elementor-top-section elementor-element elementor-element-913478e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="913478e" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
        <div class="elementor-container elementor-column-gap-default">
          <div class="elementor-row">
            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-8a50df6" data-id="8a50df6" data-element_type="column">
              <div class="elementor-column-wrap elementor-element-populated">
                <div class="elementor-widget-wrap">
                  <div class="elementor-element elementor-element-67c606f elementor-widget elementor-widget-elementskit-heading" data-id="67c606f" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                    <div class="elementor-widget-container">
                      <div class="ekit-wid-con">
                        <div class="ekit-heading elementskit-section-title-wraper text_center   ekit_heading_tablet-   ekit_heading_mobile-">



                          <div class="elementor-widget-wrap">
                            <div class="
                          elementor-element
                          elementor-element-2ca2b7f
                          elementor-widget
                          elementor-widget-elementskit-heading
                        " data-id="2ca2b7f" data-element_type="widget" data-settings='{"ekit_we_effect_on":"none"}' data-widget_type="elementskit-heading.default">
                              <div class="elementor-widget-container">
                                <div class="ekit-wid-con">
                                  <div class="
                                ekit-heading
                                elementskit-section-title-wraper
                                text_left
                                ekit_heading_tablet- ekit_heading_mobile-
                              ">
                                    <h2 class=" text-center
                                  ekit-heading--title
                                  elementskit-section-title
                                ">
                                      Nos partenaires!
                                    </h2>
                                  </div>
                                </div>
                              </div>
                            </div> <br><br>
                          </div>
                        </div>
                      </div>
                    </div>


                    <style>
                      .partners {
                        padding: 30px;
                      }
                    </style>
                    <div class="elementor-element elementor-element-beb648f elementor-widget elementor-widget-courselog-instructor" data-id="beb648f" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="courselog-instructor.default">
                      <div class="elementor-widget-container container">
                        <div class="instructor-list row ">

                          <div class="col-sm-6 col-md-4 col-lg-2 ">
                            <div class="instructor-list-wrap ">

                              <!-- hover item -->
                              <div class="single-instructor-item">
                                <div class="insturctor-img-area">
                                  <div class="instructor-profile-pic">
                                    <img src="assets/img/gsa-logo.png" alt="partenaire" class="partners" data-lazy-src="assets/img/logo.jpg"><noscript>
                                      <img src="assets/img/logo.jpg" class="partners"></noscript>
                                    <div class="instructor-social">
                                      <a href="#"><i class='fab fa-facebook-f'> </i></a>
                                      <a href="#"><i class='fab fa-twitter'> </i></a>
                                      <a href="#"><i class='fab fa-linkedin-in'> </i></a>
                                    </div>
                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>


                          <div class="col-sm-6 col-md-4 col-lg-2 ">
                            <div class="instructor-list-wrap ">

                              <!-- hover item -->
                              <div class="single-instructor-item">
                                <div class="insturctor-img-area">
                                  <div class="instructor-profile-pic">
                                    <img src="assets/img/trans.jpg" alt="margaret" class="partners" data-lazy-src="assets/img/logoprim.jpg"><noscript>
                                      <img src="assets/img/logoprim.jpg" alt="partenaire" class="partners"></noscript>
                                    <div class="instructor-social">
                                      <a href="#"><i class='fab fa-facebook-f'> </i></a>
                                      <a href="#"><i class='fab fa-twitter'> </i></a>
                                      <a href="#"><i class='fab fa-linkedin'> </i></a>
                                    </div>

                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>


                          <div class="col-sm-6 col-md-4 col-lg-2 ">
                            <div class="instructor-list-wrap ">

                              <!-- hover item -->
                              <div class="single-instructor-item">
                                <div class="insturctor-img-area">
                                  <div class="instructor-profile-pic">
                                    <img src="assets/img/logoprim.jpg" alt="partenaire" class="partners" data-lazy-src="assets/img/logoprim.jpg"><noscript>
                                      <img src="assets/img/logoprim.jpg" class="partners"></noscript>
                                    <div class="instructor-social">
                                      <a href="#"><i class='fab fa-facebook-f'> </i></a>
                                      <a href="#"><i class='fab fa-twitter'> </i></a>
                                      <a href="#"><i class='fab fa-linkedin-in'> </i></a>
                                    </div>
                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>

                          <div class="col-sm-6 col-md-4 col-lg-2 ">
                            <div class="instructor-list-wrap ">

                              <!-- hover item -->
                              <div class="single-instructor-item">
                                <div class="insturctor-img-area">
                                  <div class="instructor-profile-pic">
                                    <img src="assets/img/logo.jpg" alt="partenaire" class="partners" data-lazy-src="assets/img/logo.jpg"><noscript>
                                      <img src="assets/img/logo.jpg" class="partners"></noscript>
                                    <div class="instructor-social">
                                      <a href="#"><i class='fab fa-facebook-f'> </i></a>
                                      <a href="#"><i class='fab fa-twitter'> </i></a>
                                      <a href="#"><i class='fab fa-linkedin-in'> </i></a>
                                    </div>
                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>

                          <div class="col-sm-6 col-md-4 col-lg-2 ">
                            <div class="instructor-list-wrap ">

                              <!-- hover item -->
                              <div class="single-instructor-item">
                                <div class="insturctor-img-area">
                                  <div class="instructor-profile-pic">
                                    <img src="assets/img/logoprim.jpg" alt="partenaire" class="partners" data-lazy-src="assets/img/logoprim.jpg"><noscript>
                                      <img src="assets/img/logoprim.jpg" class="partners"></noscript>
                                    <div class="instructor-social">
                                      <a href="#"><i class='fab fa-facebook-f'> </i></a>
                                      <a href="#"><i class='fab fa-twitter'> </i></a>
                                      <a href="#"><i class='fab fa-linkedin-in'> </i></a>
                                    </div>
                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>


                          <div class="col-sm-6 col-md-4 col-lg-2 ">
                            <div class="instructor-list-wrap ">

                              <!-- hover item -->
                              <div class="single-instructor-item">
                                <div class="insturctor-img-area">
                                  <div class="instructor-profile-pic">
                                    <img src="assets/img/logo.jpg" alt="margaret" class="partners" data-lazy-src="assets/img/logo.jpg"><noscript>
                                      <img src="assets/img/logo.jpg" alt="partenaire" class="partners"></noscript>
                                    <div class="instructor-social">
                                      <a href="#"><i class='fab fa-facebook-f'> </i></a>
                                      <a href="#"><i class='fab fa-twitter'> </i></a>
                                      <a href="#"><i class='fab fa-linkedin'> </i></a>
                                    </div>

                                  </div>
                                </div>

                              </div>

                            </div>
                          </div>



                        </div>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </section>




























    </div>
  </div>
</div>

<!--ascenceur-->
<div id="scrollUp">
  <a href="">
    <i class="fas fa-arrow-up"> </i>
  </a>
</div>

<style>
  #scrollUp {
    position: fixed;
    bottom: 10px;
    right: 40px;
    opacity: 0.6;
    z-index: 1;
  }

  #scrollUp i {
    font-size: 40px;
    z-index: 1;
    color: red;
    background-color: black;
  }
</style>

<script>
  //function boutton ascenceur
  jQuery(function() {
    $(function() {
      $(window).scroll(function() {
        if ($(this).scrollTop() > 200) {
          $('#scrollUp').css('right', '10px');
        } else {
          $('#scrollUp').removeAttr('style');
        }

      });
    });
  });

  //fonction barre de recherche-->
  function FindNext() {
    var str = document.getElementById("findField").value;
    if (str == "") {
      alert("Veillez entrer un text a rechercher!");
      return;
    }

    var supported = false;
    var found = false;
    if (window.find) { // Firefox, Google Chrome, Safari
      supported = true;
      // si du contenu est sélectionné, la position de départ de la recherche
      // sera la position finale de la sélection
      found = window.find(str);
    } else {
      if (document.selection && document.selection.createRange) { // Internet Explorer, Opera before version 10.5
        var textRange = document.selection.createRange();
        if (textRange.findText) { // Internet Explorer
          supported = true;
          // si du contenu est sélectionné, la position de départ de la recherche
          // sera la position finale de la sélection
          if (textRange.text.length > 0) {
            textRange.collapse(true);
            textRange.move("character", 1);
          }

          found = textRange.findText(str);
          if (found) {
            textRange.select();
          }
        }
      }
    }

    if (supported) {
      if (!found) {
        alert("Le texte suivant n'a pas été trouvé:\n" + str);
      }
    } else {
      alert("Votre navigateur ne supporte pas cet exemple!");
    }
  }
</script>

<!--footer-->
<div class="ekit-template-content-markup ekit-template-content-footer ekit-template-content-theme-support" style="background-color: #2878eb;">
  <div data-elementor-type="wp-post" data-elementor-id="8566" class="elementor elementor-8566" data-elementor-settings="[]">
    <div class="elementor-inner">
      <div class="elementor-section-wrap">
        <section class="elementor-section elementor-top-section elementor-element elementor-element-c2193ea elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c2193ea" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
          <div class="elementor-background-overlay"></div>
          <div class="elementor-container elementor-column-gap-default">
            <div class="elementor-row">
              <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9690007" data-id="9690007" data-element_type="column">
                <div class="elementor-column-wrap elementor-element-populated">
                  <div class="elementor-widget-wrap">
                    <section class="elementor-section elementor-inner-section elementor-element elementor-element-26553ce elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="26553ce" data-element_type="section" data-settings="{&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
                      <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-row">
                          <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-9b6bfe5" data-id="9b6bfe5" data-element_type="column">
                            <div class="elementor-column-wrap elementor-element-populated">
                              <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-4f0153e elementor-widget elementor-widget-courselog-logo" data-id="4f0153e" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="courselog-logo.default">
                                  <div class="elementor-widget-container">
                                    <div class="courselog-widget-logo">
                                      <a href="">
                                        <img src="assets/img/logoprim.jpg" alt="logo" data-lazy-src="assets/img/logoprim.jpg">
                                        <noscript><img src="assets/img/logoprim.jpg" alt="logo"></noscript>
                                      </a>
                                    </div>

                                  </div>
                                </div>


                              </div>
                            </div>
                          </div>
                          <div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b2b6e77" data-id="b2b6e77" data-element_type="column">
                            <div class="elementor-column-wrap elementor-element-populated">
                              <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3a91400 elementor-widget elementor-widget-elementskit-heading" data-id="3a91400" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                                  <div class="elementor-widget-container">
                                    <div class="ekit-wid-con">
                                      <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                        <ul class="ekit_social_media">

                                          <li class="elementor-repeater-item-d580217" style="display: inline-block; padding: 14px;">
                                            <a href="" class="facebook">

                                              <i aria-hidden="true" class="icon icon-facebook "></i>
                                            </a>
                                          </li>
                                          <li class="elementor-repeater-item-76ac81f" style="display: inline-block; padding: 14px;">
                                            <a href="" class="1 ">
                                              <i aria-hidden="true" class="icon icon-instagram-1 "></i>
                                            </a>
                                          </li>

                                          <li class="elementor-repeater-item-d5286e9" style="display: inline-block; padding: 14px;">
                                            <a href="" class="twitter">
                                              <i aria-hidden="true" class="icon icon-twitter"></i>
                                            </a>
                                          </li>

                                          <li class="elementor-repeater-item-d5286e9" style="display: inline-block; padding: 14px;">
                                            <a href="" class="">
                                              <i aria-hidden="true" class="icon icon-location">MAP</i>
                                            </a>
                                          </li>

                                        </ul>

                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div class="elementor-element elementor-element-648929d elementor-widget elementor-widget-elementskit-page-list" data-id="648929d" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
                                  <div class="elementor-widget-container">
                                    <div class="ekit-wid-con">
                                      <div class="elementor-icon-list-items ">


                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <!--newsletter-->
                          <div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-b2b6e77" data-id="b2b6e77" data-element_type="column">
                            <div class="elementor-column-wrap elementor-element-populated">
                              <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-3a91400 elementor-widget elementor-widget-elementskit-heading" data-id="3a91400" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
                                  <div class="elementor-widget-container">
                                    <div class="ekit-wid-con">
                                      <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                                        <h6 style="color:black">Souscrivez A
                                          Notre Newsletter</h6>
                                        <div class="elementor-element elementor-element-aa9c61b elementor-widget elementor-widget-courselog-course-search" data-id="aa9c61b" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="courselog-course-search.default">
                                          <div class="elementor-widget-container">

                                            <div class="courselog-course-search header-course-search">
                                              <form method="get" name="search-course" class="courselog-search-course-form" action="send_mail.php">
                                                <input type="text" name="okns" class="search-course-input" placeholder="Email..." />
                                                <input type="hidden" name="ref" value="course" />
                                                <button class="lp-button button search-course-button">ok</button>
                                              </form>
                                            </div>

                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                        </div>
                      </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>

<section style="background-color: black;" class="elementor-section elementor-top-section elementor-element elementor-element-55945e6 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="55945e6" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;ekit_has_onepagescroll_dot&quot;:&quot;yes&quot;}">
  <div class="elementor-container elementor-column-gap-default">
    <div class="elementor-row">
      <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-24a6fc3" data-id="24a6fc3" data-element_type="column">
        <div class="elementor-column-wrap elementor-element-populated">
          <div class="elementor-widget-wrap">
            <div class="elementor-element elementor-element-6806583 elementor-widget elementor-widget-elementskit-heading" data-id="6806583" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-heading.default">
              <div class="elementor-widget-container">
                <div class="ekit-wid-con">
                  <div class="ekit-heading elementskit-section-title-wraper text_left   ekit_heading_tablet-   ekit_heading_mobile-">
                    <div class='ekit-heading__description'>
                      <p class="text-white">&copy; <?php echo date('Y'); ?> . All Rights Reserved.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-bce67fd" data-id="bce67fd" data-element_type="column">
        <div class="elementor-column-wrap elementor-element-populated">
          <div class="elementor-widget-wrap">
            <div class="elementor-element elementor-element-8cfdf1d elementor-align-right elementor-mobile-align-left elementor-tablet-align-left elementor-widget elementor-widget-elementskit-page-list" data-id="8cfdf1d" data-element_type="widget" data-settings="{&quot;ekit_we_effect_on&quot;:&quot;none&quot;}" data-widget_type="elementskit-page-list.default">
              <div class="elementor-widget-container">
                <div class="ekit-wid-con">
                  <div class="elementor-icon-list-items  elementor-inline-items">
                    <div class="elementor-icon-list-item   ">
                      <a target=_blank rel="" href="index.php" class="elementor-repeater-item-7403058 ">
                        <div class="ekit_page_list_content">
                          <span class="elementor-icon-list-text">
                            <span class="ekit_page_list_title_title text-white">Accueil</span>
                          </span>
                        </div>
                      </a>
                    </div>
                    <div class="elementor-icon-list-item   ">
                      <a target=_blank rel="" href="public/labo.php" class="elementor-repeater-item-a088a2b ">
                        <div class="ekit_page_list_content">
                          <span class="elementor-icon-list-text">
                            <span class="ekit_page_list_title_title text-white">A propos</span>
                          </span>
                        </div>
                      </a>
                    </div>
                    <div class="elementor-icon-list-item   ">
                      <a target=_blank rel="" href="public/contact.php " class="elementor-repeater-item-baf2a8d ">
                        <div class="ekit_page_list_content">
                          <span class="elementor-icon-list-text">
                            <span class="ekit_page_list_title_title text-white">Contacts</span>
                          </span>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--end footer-->


<script type="text/javascript">
  (function() {
    var c = document.body.className;
    c = c.replace(/woocommerce-no-js/, "woocommerce-js");
    document.body.className = c;
  })();
</script>
<style id="etn-custom-css-inline-css" type="text/css">
  .etn-event-single-content-wrap .etn-event-meta .etn-event-category span,
  .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border,
  .etn-btn.etn-btn-border,
  .attr-btn-primary.etn-btn-border,
  .etn-attendee-form .etn-btn.etn-btn-border,
  .etn-ticket-widget .etn-btn.etn-btn-border,
  .etn-settings-dashboard .button-primary.etn-btn-border,
  .etn-single-speaker-item .etn-speaker-content a:hover,
  .etn-event-style2 .etn-event-date,
  .etn-event-style3 .etn-event-content .etn-title a:hover,
  .etn-event-item:hover .etn-title a {
    color: #5d78ff;
  }

  .etn-event-item .etn-event-category span,
  .etn-btn,
  .attr-btn-primary,
  .etn-attendee-form .etn-btn,
  .etn-ticket-widget .etn-btn,
  .schedule-list-1 .schedule-header,
  .speaker-style4 .etn-speaker-content .etn-title a,
  .etn-speaker-details3 .speaker-title-info,
  .etn-event-slider .swiper-pagination-bullet,
  .etn-speaker-slider .swiper-pagination-bullet,
  .etn-event-slider .swiper-button-next,
  .etn-event-slider .swiper-button-prev,
  .etn-speaker-slider .swiper-button-next,
  .etn-speaker-slider .swiper-button-prev,
  .etn-single-speaker-item .etn-speaker-thumb .etn-speakers-social a,
  .etn-event-header .etn-event-countdown-wrap .etn-count-item,
  .schedule-tab-1 .etn-nav li a.etn-active,
  .etn-settings-dashboard .button-primary {
    background-color: #5d78ff;
  }

  .etn-event-item .etn-event-footer .etn-atend-btn .etn-btn-border,
  .etn-btn.etn-btn-border,
  .attr-btn-primary.etn-btn-border,
  .etn-attendee-form .etn-btn.etn-btn-border,
  .etn-ticket-widget .etn-btn.etn-btn-border,
  .etn-settings-dashboard .button-primary.etn-btn-border {
    border-color: #5d78ff;
  }

  .schedule-tab-wrapper .etn-nav li a.etn-active {
    border-bottom-color: #5d78ff;
  }

  .schedule-tab-wrapper .etn-nav li a:after,
  .schedule-tab-1 .etn-nav li a.etn-active:after {
    border-color: #5d78ff transparent transparent transparent;
  }


</style>

<script type="text/javascript" src="wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min44fd.js?ver=2.70" id="jquery-blockui-js"></script>
<script type="text/javascript" id="wc-add-to-cart-js-extra">
  /* <![CDATA[ */
  var wc_add_to_cart_params = {
    ajax_url: "\/wp\/courselog\/wp-admin\/admin-ajax.php",
    wc_ajax_url: "\/wp\/courselog\/?wc-ajax=%%endpoint%%",
    i18n_view_cart: "View cart",
    cart_url: "https:\/\/demo.themewinter.com\/wp\/courselog\/cart\/",
    is_cart: "",
    cart_redirect_after_add: "no",
  };
  /* ]]> */
</script>
<script type="text/javascript" src="wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.minbb49.js?ver=5.2.2" id="wc-add-to-cart-js"></script>
<script type="text/javascript" src="wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min6b25.js?ver=2.1.4" id="js-cookie-js"></script>
<script type="text/javascript" id="woocommerce-js-extra">
  /* <![CDATA[ */
  var woocommerce_params = {
    ajax_url: "\/wp\/courselog\/wp-admin\/admin-ajax.php",
    wc_ajax_url: "\/wp\/courselog\/?wc-ajax=%%endpoint%%",
  };
  /* ]]> */
</script>
<script type="text/javascript" src="wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.minbb49.js?ver=5.2.2" id="woocommerce-js"></script>
<script type="text/javascript" id="wc-cart-fragments-js-extra">
  /* <![CDATA[ */
  var wc_cart_fragments_params = {
    ajax_url: "\/wp\/courselog\/wp-admin\/admin-ajax.php",
    wc_ajax_url: "\/wp\/courselog\/?wc-ajax=%%endpoint%%",
    cart_hash_key: "wc_cart_hash_6915161f49948399f91c6d7efb168b53",
    fragment_name: "wc_fragments_6915161f49948399f91c6d7efb168b53",
    request_timeout: "5000",
  };
  /* ]]> */
</script>
<script type="text/javascript" src="wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.minbb49.js?ver=5.2.2" id="wc-cart-fragments-js"></script>
<script type="text/javascript" id="rocket-browser-checker-js-after">
  "use strict";
  var _createClass = (function() {
    function defineProperties(target, props) {
      for (var i = 0; i < props.length; i++) {
        var descriptor = props[i];
        (descriptor.enumerable = descriptor.enumerable || !1),
        (descriptor.configurable = !0),
        "value" in descriptor && (descriptor.writable = !0),
          Object.defineProperty(target, descriptor.key, descriptor);
      }
    }
    return function(Constructor, protoProps, staticProps) {
      return (
        protoProps && defineProperties(Constructor.prototype, protoProps),
        staticProps && defineProperties(Constructor, staticProps),
        Constructor
      );
    };
  })();

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor))
      throw new TypeError("Cannot call a class as a function");
  }
  var RocketBrowserCompatibilityChecker = (function() {
    function RocketBrowserCompatibilityChecker(options) {
      _classCallCheck(this, RocketBrowserCompatibilityChecker),
        (this.passiveSupported = !1),
        this._checkPassiveOption(this),
        (this.options = !!this.passiveSupported && options);
    }
    return (
      _createClass(RocketBrowserCompatibilityChecker, [{
          key: "_checkPassiveOption",
          value: function(self) {
            try {
              var options = {
                get passive() {
                  return !(self.passiveSupported = !0);
                },
              };
              window.addEventListener("test", null, options),
                window.removeEventListener("test", null, options);
            } catch (err) {
              self.passiveSupported = !1;
            }
          },
        },
        {
          key: "initRequestIdleCallback",
          value: function() {
            !1 in window &&
              (window.requestIdleCallback = function(cb) {
                var start = Date.now();
                return setTimeout(function() {
                  cb({
                    didTimeout: !1,
                    timeRemaining: function() {
                      return Math.max(0, 50 - (Date.now() - start));
                    },
                  });
                }, 1);
              }),
              !1 in window &&
              (window.cancelIdleCallback = function(id) {
                return clearTimeout(id);
              });
          },
        },
        {
          key: "isDataSaverModeOn",
          value: function() {
            return (
              "connection" in navigator &&
              !0 === navigator.connection.saveData
            );
          },
        },
        {
          key: "supportsLinkPrefetch",
          value: function() {
            var elem = document.createElement("link");
            return (
              elem.relList &&
              elem.relList.supports &&
              elem.relList.supports("prefetch") &&
              window.IntersectionObserver &&
              "isIntersecting" in IntersectionObserverEntry.prototype
            );
          },
        },
        {
          key: "isSlowConnection",
          value: function() {
            return (
              "connection" in navigator &&
              "effectiveType" in navigator.connection &&
              ("2g" === navigator.connection.effectiveType ||
                "slow-2g" === navigator.connection.effectiveType)
            );
          },
        },
      ]),
      RocketBrowserCompatibilityChecker
    );
  })();
</script>
<script type="text/javascript" id="rocket-delay-js-js-after">
  (function() {
    "use strict";
    var e = (function() {
      function n(e, t) {
        for (var r = 0; r < t.length; r++) {
          var n = t[r];
          (n.enumerable = n.enumerable || !1),
          (n.configurable = !0),
          "value" in n && (n.writable = !0),
            Object.defineProperty(e, n.key, n);
        }
      }
      return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
      };
    })();

    function n(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    var t = (function() {
      function r(e, t) {
        n(this, r),
          (this.attrName = "data-rocketlazyloadscript"),
          (this.browser = t),
          (this.options = this.browser.options),
          (this.triggerEvents = e),
          (this.userEventListener = this.triggerListener.bind(this));
      }
      return (
        e(
          r,
          [{
              key: "init",
              value: function() {
                this._addEventListener(this);
              },
            },
            {
              key: "reset",
              value: function() {
                this._removeEventListener(this);
              },
            },
            {
              key: "_addEventListener",
              value: function(t) {
                this.triggerEvents.forEach(function(e) {
                  return window.addEventListener(
                    e,
                    t.userEventListener,
                    t.options
                  );
                });
              },
            },
            {
              key: "_removeEventListener",
              value: function(t) {
                this.triggerEvents.forEach(function(e) {
                  return window.removeEventListener(
                    e,
                    t.userEventListener,
                    t.options
                  );
                });
              },
            },
            {
              key: "_loadScriptSrc",
              value: function() {
                var r = this,
                  e = document.querySelectorAll(
                    "script[" + this.attrName + "]"
                  );
                0 !== e.length &&
                  Array.prototype.slice.call(e).forEach(function(e) {
                    var t = e.getAttribute(r.attrName);
                    e.setAttribute("src", t), e.removeAttribute(r.attrName);
                  }),
                  this.reset();
              },
            },
            {
              key: "triggerListener",
              value: function() {
                this._loadScriptSrc(), this._removeEventListener(this);
              },
            },
          ],
          [{
            key: "run",
            value: function() {
              RocketBrowserCompatibilityChecker &&
                new r(
                  [
                    "keydown",
                    "mouseover",
                    "touchmove",
                    "touchstart",
                    "wheel",
                  ],
                  new RocketBrowserCompatibilityChecker({
                    passive: !0
                  })
                ).init();
            },
          }, ]
        ),
        r
      );
    })();
    t.run();
  })();
</script>
<script type="text/javascript" id="rocket-preload-links-js-extra">
  /* <![CDATA[ */
  var RocketPreloadLinksConfig = {
    excludeUris: "\/wp\/courselog(\/(.+\/)?feed\/?.+\/?|\/(?:.+\/)?embed\/|\/cart\/|\/my-account\/|\/wc-api\/v(.*)|(\/[^\/]+)?\/(index\\.php\/)?wp\\-json(\/.*|$))|\/wp-admin\/|\/logout\/|\/wp-login.php",
    usesTrailingSlash: "1",
    imageExt: "jpg|jpeg|gif|png|tiff|bmp|webp|avif",
    fileExt: "jpg|jpeg|gif|png|tiff|bmp|webp|avif|php|pdf|html|htm",
    siteUrl: "https:\/\/demo.themewinter.com\/wp\/courselog",
    onHoverDelay: "100",
    rateThrottle: "3",
  };
  /* ]]> */
</script>
<script type="text/javascript" id="rocket-preload-links-js-after">
  (function() {
    "use strict";
    var r =
      "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
      function(e) {
        return typeof e;
      } :
      function(e) {
        return e &&
          "function" == typeof Symbol &&
          e.constructor === Symbol &&
          e !== Symbol.prototype ?
          "symbol" :
          typeof e;
      },
      e = (function() {
        function i(e, t) {
          for (var n = 0; n < t.length; n++) {
            var i = t[n];
            (i.enumerable = i.enumerable || !1),
            (i.configurable = !0),
            "value" in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        return function(e, t, n) {
          return t && i(e.prototype, t), n && i(e, n), e;
        };
      })();

    function i(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    var t = (function() {
      function n(e, t) {
        i(this, n),
          (this.browser = e),
          (this.config = t),
          (this.options = this.browser.options),
          (this.prefetched = new Set()),
          (this.eventTime = null),
          (this.threshold = 1111),
          (this.numOnHover = 0);
      }
      return (
        e(
          n,
          [{
              key: "init",
              value: function() {
                !this.browser.supportsLinkPrefetch() ||
                  this.browser.isDataSaverModeOn() ||
                  this.browser.isSlowConnection() ||
                  ((this.regex = {
                      excludeUris: RegExp(this.config.excludeUris, "i"),
                      images: RegExp(".(" + this.config.imageExt + ")$", "i"),
                      fileExt: RegExp(".(" + this.config.fileExt + ")$", "i"),
                    }),
                    this._initListeners(this));
              },
            },
            {
              key: "_initListeners",
              value: function(e) {
                -1 < this.config.onHoverDelay &&
                  document.addEventListener(
                    "mouseover",
                    e.listener.bind(e),
                    e.listenerOptions
                  ),
                  document.addEventListener(
                    "mousedown",
                    e.listener.bind(e),
                    e.listenerOptions
                  ),
                  document.addEventListener(
                    "touchstart",
                    e.listener.bind(e),
                    e.listenerOptions
                  );
              },
            },
            {
              key: "listener",
              value: function(e) {
                var t = e.target.closest("a"),
                  n = this._prepareUrl(t);
                if (null !== n)
                  switch (e.type) {
                    case "mousedown":
                    case "touchstart":
                      this._addPrefetchLink(n);
                      break;
                    case "mouseover":
                      this._earlyPrefetch(t, n, "mouseout");
                  }
              },
            },
            {
              key: "_earlyPrefetch",
              value: function(t, e, n) {
                var i = this,
                  r = setTimeout(function() {
                    if (((r = null), 0 === i.numOnHover))
                      setTimeout(function() {
                        return (i.numOnHover = 0);
                      }, 1e3);
                    else if (i.numOnHover > i.config.rateThrottle) return;
                    i.numOnHover++, i._addPrefetchLink(e);
                  }, this.config.onHoverDelay);
                t.addEventListener(
                  n,
                  function e() {
                    t.removeEventListener(n, e, {
                        passive: !0
                      }),
                      null !== r && (clearTimeout(r), (r = null));
                  }, {
                    passive: !0
                  }
                );
              },
            },
            {
              key: "_addPrefetchLink",
              value: function(i) {
                return (
                  this.prefetched.add(i.href),
                  new Promise(function(e, t) {
                    var n = document.createElement("link");
                    (n.rel = "prefetch"),
                    (n.href = i.href),
                    (n.onload = e),
                    (n.onerror = t),
                    document.head.appendChild(n);
                  }).catch(function() {})
                );
              },
            },
            {
              key: "_prepareUrl",
              value: function(e) {
                if (
                  null === e ||
                  "object" !== (void 0 === e ? "undefined" : r(e)) ||
                  !1 in e ||
                  -1 === ["http:", "https:"].indexOf(e.protocol)
                )
                  return null;
                var t = e.href.substring(0, this.config.siteUrl.length),
                  n = this._getPathname(e.href, t),
                  i = {
                    original: e.href,
                    protocol: e.protocol,
                    origin: t,
                    pathname: n,
                    href: t + n,
                  };
                return this._isLinkOk(i) ? i : null;
              },
            },
            {
              key: "_getPathname",
              value: function(e, t) {
                var n = t ? e.substring(this.config.siteUrl.length) : e;
                return (
                  n.startsWith("https://demo.themewinter.com/") ||
                  (n = "/" + n),
                  this._shouldAddTrailingSlash(n) ? n + "/" : n
                );
              },
            },
            {
              key: "_shouldAddTrailingSlash",
              value: function(e) {
                return (
                  this.config.usesTrailingSlash &&
                  !e.endsWith("https://demo.themewinter.com/") &&
                  !this.regex.fileExt.test(e)
                );
              },
            },
            {
              key: "_isLinkOk",
              value: function(e) {
                return (
                  null !== e &&
                  "object" === (void 0 === e ? "undefined" : r(e)) &&
                  !this.prefetched.has(e.href) &&
                  e.origin === this.config.siteUrl &&
                  -1 === e.href.indexOf("?") &&
                  -1 === e.href.indexOf("#") &&
                  !this.regex.excludeUris.test(e.href) &&
                  !this.regex.images.test(e.href)
                );
              },
            },
          ],
          [{
            key: "run",
            value: function() {
              "undefined" != typeof RocketPreloadLinksConfig &&
                new n(
                  new RocketBrowserCompatibilityChecker({
                    capture: !0,
                    passive: !0,
                  }),
                  RocketPreloadLinksConfig
                ).init();
            },
          }, ]
        ),
        n
      );
    })();
    t.run();
  })();
</script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/metform/public/assets/js/htm32f0.js?ver=1619375310" id="htm-js"></script>
<script type="text/javascript" src="wp-includes/js/dist/vendor/lodash.minf492.js?ver=4.17.19" id="lodash-js"></script>
<script type="text/javascript" id="lodash-js-after">
  window.lodash = _.noConflict();
</script>
<script type="text/javascript" src="wp-includes/js/dist/vendor/wp-polyfill.min89b1.js?ver=7.4.4" id="wp-polyfill-js"></script>
<script type="text/javascript" id="wp-polyfill-js-after">
  "fetch" in window ||
    document.write(
      '<script src="wp-includes/js/dist/vendor/wp-polyfill-fetch.min6e0e.js?ver=3.0.0"></scr' +
      "ipt>"
    );
  document.contains ||
    document.write(
      '<script src="wp-includes/js/dist/vendor/wp-polyfill-node-contains.min2e00.js?ver=3.42.0"></scr' +
      "ipt>"
    );
  window.DOMRect ||
    document.write(
      '<script src="wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min2e00.js?ver=3.42.0"></scr' +
      "ipt>"
    );
  (window.URL && window.URL.prototype && window.URLSearchParams) ||
  document.write(
    '<script src="wp-includes/js/dist/vendor/wp-polyfill-url.min5aed.js?ver=3.6.4"></scr' +
    "ipt>"
  );
  (window.FormData && window.FormData.prototype.keys) ||
  document.write(
    '<script src="wp-includes/js/dist/vendor/wp-polyfill-formdata.mine9bd.js?ver=3.0.12"></scr' +
    "ipt>"
  );
  (Element.prototype.matches && Element.prototype.closest) ||
  document.write(
    '<script src="wp-includes/js/dist/vendor/wp-polyfill-element-closest.min4c56.js?ver=2.0.2"></scr' +
    "ipt>"
  );
  "objectFit" in document.documentElement.style ||
    document.write(
      '<script src="wp-includes/js/dist/vendor/wp-polyfill-object-fit.min531b.js?ver=2.3.4"></scr' +
      "ipt>"
    );
</script>
<script type="text/javascript" src="wp-includes/js/dist/vendor/react.mincd00.js?ver=16.13.1" id="react-js"></script>
<script type="text/javascript" src="wp-includes/js/dist/vendor/react-dom.mincd00.js?ver=16.13.1" id="react-dom-js"></script>
<script type="text/javascript" src="wp-includes/js/dist/escape-html.minff4e.js?ver=318abfb97a58ba13225ff74699ad73d4" id="wp-escape-html-js"></script>
<script type="text/javascript" src="wp-includes/js/dist/element.mina1b5.js?ver=ade78933fc78fc95c1988dda7ccc9fb3" id="wp-element-js"></script>
<script type="text/javascript" id="metform-app-js-extra">
  /* <![CDATA[ */
  var mf = {
    postType: "page",
    restURI: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-json\/metform\/v1\/forms\/views\/",
  };
  /* ]]> */
</script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/metform/public/assets/js/app32f0.js?ver=1619375310" id="metform-app-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-event-solution/assets/js/event-manager-public32f0.js?ver=1619375310" id="etn-public-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script32f0.js?ver=1619375310" id="elementskit-framework-js-frontend-js"></script>
<script type="text/javascript" id="elementskit-framework-js-frontend-js-after">
  var elementskit = {
    resturl: "https://demo.themewinter.com/wp/courselog/wp-json/elementskit/v1/",
  };
</script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts32f0.js?ver=1619375310" id="ekit-widget-scripts-js"></script>
<script type="text/javascript" src="wp-content/plugins/courselog-essential/modules/parallax/assets/js/TweenMax.min7fb9.js?ver=1.5.9" id="tweenmax-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/jquery.easing.1.332f0.js?ver=1619375310" id="jquery-easing-js"></script>
<script type="text/javascript" src="wp-content/plugins/courselog-essential/modules/parallax/assets/js/tilt.jquery.min7fb9.js?ver=1.5.9" id="tilt-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/anime32f0.js?ver=1619375310" id="animejs-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/magician32f0.js?ver=1619375310" id="magicianjs-js"></script>
<script type="text/javascript" src="wp-content/themes/courselog/assets/js/bootstrap.minefb0.js?ver=%201.2.9" id="bootstrap-js"></script>
<script type="text/javascript" src="wp-content/themes/courselog/assets/js/jquery.magnific-popup.minefb0.js?ver=%201.2.9" id="magnific-popup-js"></script>
<script type="text/javascript" src="wp-content/themes/courselog/assets/js/jquery.filterizr.minefb0.js?ver=%201.2.9" id="jquery-filterizr-js"></script>
<script type="text/javascript" src="wp-content/themes/courselog/assets/js/owl.carousel.minefb0.js?ver=%201.2.9" id="owl-carousel-js"></script>
<script type="text/javascript" src="wp-content/themes/courselog/assets/js/jquery.countdown.minefb0.js?ver=%201.2.9" id="jquery-countdown-js"></script>
<script type="text/javascript" id="courselog-script-js-extra">
  /* <![CDATA[ */
  var courselog_obj = {
    ajax_url: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-admin\/admin-ajax.php",
    nonce: "fda00f0198",
    security: "767db86dd5",
    blog_sticky_sidebar: "no",
    logged_in: "",
    message_login: "You are not logged in",
  };
  /* ]]> */
</script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/themes/courselog/assets/js/script32f0.js?ver=1619375310" id="courselog-script-js"></script>
<script type="text/javascript" src="wp-content/plugins/learnpress/assets/js/frontend/course.min4e1b.js?ver=3.2.8.8" id="course-js"></script>
<script type="text/javascript" src="wp-includes/js/wp-embed.mina78f.js?ver=5.7.1" id="wp-embed-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/lib/jquery-numerator/jquery-numerator.min3958.js?ver=0.2.1" id="jquery-numerator-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/js/webpack.runtime.minaeb9.js?ver=3.1.4" id="elementor-webpack-runtime-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/js/frontend-modules.minaeb9.js?ver=3.1.4" id="elementor-frontend-modules-js"></script>
<script type="text/javascript" src="wp-includes/js/jquery/ui/core.min35d0.js?ver=1.12.1" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/lib/dialog/dialog.mina288.js?ver=4.8.1" id="elementor-dialog-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min05da.js?ver=4.0.2" id="elementor-waypoints-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/lib/share-link/share-link.minaeb9.js?ver=3.1.4" id="share-link-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/lib/swiper/swiper.min48f5.js?ver=5.3.6" id="swiper-js"></script>
<script type="text/javascript" id="elementor-frontend-js-before">
  var elementorFrontendConfig = {
    environmentMode: {
      edit: false,
      wpPreview: false,
      isScriptDebug: false,
      isImprovedAssetsLoading: false,
    },
    i18n: {
      shareOnFacebook: "Share on Facebook",
      shareOnTwitter: "Share on Twitter",
      pinIt: "Pin it",
      download: "Download",
      downloadImage: "Download image",
      fullscreen: "Fullscreen",
      zoom: "Zoom",
      share: "Share",
      playVideo: "Play Video",
      previous: "Previous",
      next: "Next",
      close: "Close",
    },
    is_rtl: false,
    breakpoints: {
      xs: 0,
      sm: 480,
      md: 768,
      lg: 1025,
      xl: 1440,
      xxl: 1600
    },
    version: "3.1.4",
    is_static: false,
    experimentalFeatures: [],
    urls: {
      assets: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-content\/plugins\/elementor\/assets\/",
    },
    settings: {
      page: [],
      editorPreferences: []
    },
    kit: {
      global_image_lightbox: "yes",
      lightbox_enable_counter: "yes",
      lightbox_enable_fullscreen: "yes",
      lightbox_enable_zoom: "yes",
      lightbox_enable_share: "yes",
      lightbox_title_src: "title",
      lightbox_description_src: "description",
    },
    post: {
      id: 163,
      title: "Courselog%20%E2%80%93%20LMS%20%26%20Education%20WordPress%20Theme",
      excerpt: "The most impressive is collection of share me online college courses",
      featuredImage: "https:\/\/demo.themewinter.com\/wp\/courselog\/wp-content\/uploads\/2020\/02\/course_image2.jpg",
    },
  };
</script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/js/frontend.minaeb9.js?ver=3.1.4" id="elementor-frontend-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/wp-event-solution/assets/js/elementor32f0.js?ver=1619375310" id="etn-elementor-inputs-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/themes/courselog/assets/js/elementor32f0.js?ver=1619375310" id="courselog-main-elementor-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/themes/courselog/assets/js/widget-scripts-pro32f0.js?ver=1619375310" id="courselog-widget-scripts-pro-js"></script>
<script type="text/javascript" src="https://unpkg.com/popper.js@1?ver=2.2.2" id="ekit-popover-js"></script>
<script type="text/javascript" src="https://unpkg.com/tippy.js@5?ver=2.2.2" id="ekit-typpy-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementskit-lite/widgets/init/assets/js/slick.min605a.js?ver=2.2.2" id="ekit-slick-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor32f0.js?ver=1619375310" id="elementskit-elementor-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/sticky-content/assets/js/jquery.sticky32f0.js?ver=1619375310" id="elementskit-sticky-content-script-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/sticky-content/assets/js/main32f0.js?ver=1619375310" id="elementskit-sticky-content-script-core-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/widget-init32f0.js?ver=1619375310" id="elementskit-parallax-widget-init-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/courselog-essential/modules/parallax/assets/js/section-init32f0.js?ver=1619375310" id="elementskit-parallax-section-init-js"></script>
<script type="text/javascript" src="wp-content/plugins/elementor/assets/js/preloaded-elements-handlers.minaeb9.js?ver=3.1.4" id="preloaded-elements-handlers-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/metform/controls/assets/js/form-picker-editor32f0.js?ver=1619375310" id="metform-js-formpicker-control-editor-js"></script>
<script data-minify="1" type="text/javascript" src="wp-content/cache/min/1/wp/courselog/wp-content/plugins/elementskit-lite/modules/controls/assets/js/widgetarea-editor32f0.js?ver=1619375310" id="elementskit-js-widgetarea-control-editor-js"></script>
<script>
  window.lazyLoadOptions = {
    elements_selector: "img[data-lazy-src],.rocket-lazyload,iframe[data-lazy-src]",
    data_src: "lazy-src",
    data_srcset: "lazy-srcset",
    data_sizes: "lazy-sizes",
    class_loading: "lazyloading",
    class_loaded: "lazyloaded",
    threshold: 300,
    callback_loaded: function(element) {
      if (
        element.tagName === "IFRAME" &&
        element.dataset.rocketLazyload == "fitvidscompatible"
      ) {
        if (element.classList.contains("lazyloaded")) {
          if (typeof window.jQuery != "undefined") {
            if (jQuery.fn.fitVids) {
              jQuery(element).parent().fitVids();
            }
          }
        }
      }
    },
  };
  window.addEventListener(
    "LazyLoad::Initialized",
    function(e) {
      var lazyLoadInstance = e.detail.instance;
      if (window.MutationObserver) {
        var observer = new MutationObserver(function(mutations) {
          var image_count = 0;
          var iframe_count = 0;
          var rocketlazy_count = 0;
          mutations.forEach(function(mutation) {
            for (i = 0; i < mutation.addedNodes.length; i++) {
              if (
                typeof mutation.addedNodes[i].getElementsByTagName !==
                "function"
              ) {
                continue;
              }
              if (
                typeof mutation.addedNodes[i].getElementsByClassName !==
                "function"
              ) {
                continue;
              }
              images = mutation.addedNodes[i].getElementsByTagName("img");
              is_image = mutation.addedNodes[i].tagName == "IMG";
              iframes =
                mutation.addedNodes[i].getElementsByTagName("iframe");
              is_iframe = mutation.addedNodes[i].tagName == "IFRAME";
              rocket_lazy =
                mutation.addedNodes[i].getElementsByClassName(
                  "rocket-lazyload"
                );
              image_count += images.length;
              iframe_count += iframes.length;
              rocketlazy_count += rocket_lazy.length;
              if (is_image) {
                image_count += 1;
              }
              if (is_iframe) {
                iframe_count += 1;
              }
            }
          });
          if (image_count > 0 || iframe_count > 0 || rocketlazy_count > 0) {
            lazyLoadInstance.update();
          }
        });
        var b = document.getElementsByTagName("body")[0];
        var config = {
          childList: !0,
          subtree: !0
        };
        observer.observe(b, config);
      }
    },
    !1
  );
</script>
<script data-no-minify="1" async src="wp-content/plugins/wp-rocket/assets/js/lazyload/16.1/lazyload.min.js"></script>
<script>
  function lazyLoadThumb(e) {
    var t =
      '<img loading="lazy" data-lazy-src="https://i.ytimg.com/vi/ID/hqdefault.jpg" alt="" width="480" height="360"><noscript><img src="https://i.ytimg.com/vi/ID/hqdefault.jpg" alt="" width="480" height="360"></noscript>',
      a = '<div class="play"></div>';
    return t.replace("ID", e) + a;
  }

  function lazyLoadYoutubeIframe() {
    var e = document.createElement("iframe"),
      t = "ID?autoplay=1";
    t += 0 === this.dataset.query.length ? "" : "&" + this.dataset.query;
    e.setAttribute("src", t.replace("ID", this.dataset.src)),
      e.setAttribute("frameborder", "0"),
      e.setAttribute("allowfullscreen", "1"),
      e.setAttribute(
        "allow",
        "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
      ),
      this.parentNode.replaceChild(e, this);
  }
  document.addEventListener("DOMContentLoaded", function() {
    var e,
      t,
      a = document.getElementsByClassName("rll-youtube-player");
    for (t = 0; t < a.length; t++)
      (e = document.createElement("div")),
      e.setAttribute("data-id", a[t].dataset.id),
      e.setAttribute("data-query", a[t].dataset.query),
      e.setAttribute("data-src", a[t].dataset.src),
      (e.innerHTML = lazyLoadThumb(a[t].dataset.id)),
      (e.onclick = lazyLoadYoutubeIframe),
      a[t].appendChild(e);
  });
</script>
<script>
  "use strict";
  var wprRemoveCPCSS = function wprRemoveCPCSS() {
    var elem;
    document.querySelector('link[data-rocket-async="style"][rel="preload"]') ?
      setTimeout(wprRemoveCPCSS, 200) :
      (elem = document.getElementById("rocket-critical-css")) &&
      "remove" in elem &&
      elem.remove();
  };
  window.addEventListener ?
    window.addEventListener("load", wprRemoveCPCSS) :
    window.attachEvent && window.attachEvent("onload", wprRemoveCPCSS);
</script>
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Manrope%3Aregular%2C700%2C400%2C900%7CRoboto%3A300%2C300i%2C400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CRubik%3A400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i%7CManrope%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;display=swap" />
  <link rel="stylesheet" href="wp-content/cache/min/1/48674de4d79417baaca3cb45b8aaf4fe.css" media="all" data-minify="1" />
  <link rel="stylesheet" id="woocommerce-smallscreen-css" href="wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreenbb49.css?ver=5.2.2" type="text/css" media="only screen and (max-width: 768px)" />
</noscript>



</body>

</html>